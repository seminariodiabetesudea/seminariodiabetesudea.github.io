"""Plots ArviZ version."""

__version__ = "1.3.2"
