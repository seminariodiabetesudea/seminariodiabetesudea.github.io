from pytensor import tensor as pt
from pytensor.assumptions import DIAGONAL, ORTHOGONAL, check_assumption
from pytensor.graph import Apply, FunctionGraph
from pytensor.graph.rewriting.basic import (
    node_rewriter,
)
from pytensor.graph.rewriting.unify import OpPattern
from pytensor.tensor.basic import alloc_diag, atleast_Nd
from pytensor.tensor.blockwise import Blockwise
from pytensor.tensor.elemwise import DimShuffle
from pytensor.tensor.linalg.constructors import BlockDiagonal, block_diag
from pytensor.tensor.linalg.decomposition.cholesky import Cholesky
from pytensor.tensor.linalg.inverse import MatrixInverse, MatrixPinv
from pytensor.tensor.linalg.products import KroneckerProduct, kron
from pytensor.tensor.linalg.solvers.general import solve
from pytensor.tensor.math import Dot
from pytensor.tensor.rewriting.basic import (
    register_canonicalize,
    register_specialize,
    register_stabilize,
)
from pytensor.tensor.rewriting.blockwise import blockwise_of
from pytensor.tensor.rewriting.linalg.utils import (
    ASSUME_A_OF_TRANSPOSE,
    MATRIX_INVERSE_OPS,
    get_assume_a,
    strip_left_expand_dims_and_transpose,
)


@register_canonicalize
@node_rewriter([OpPattern(DimShuffle, is_left_expanded_matrix_transpose=True)])
def transpose_of_inv(fgraph, node):
    # TODO: Transpose is much more frequent that MatrixInverse, flip the rewrite pattern matching.
    [A] = node.inputs
    core, transposed = strip_left_expand_dims_and_transpose(A)
    match core.owner_op_and_inputs:
        case (Blockwise(MatrixInverse()) as inv_op, X):
            # The node itself transposes once more on top of any peeled transposes
            X_T = X if transposed else X.mT
            return [atleast_Nd(inv_op(X_T), n=node.outputs[0].type.ndim)]


@register_stabilize
@node_rewriter([Dot, blockwise_of(Dot)])
def inv_to_solve(fgraph, node):
    """Replace inv(X) @ b with solve(X, b) and b @ inv(X) with solve(X.T, b.T).T."""
    l, r = node.inputs
    [out] = node.outputs

    l_core, l_transposed = strip_left_expand_dims_and_transpose(l)
    match l_core.owner_op_and_inputs:
        case (Blockwise(MatrixInverse()), X):
            if l_transposed:
                X = X.mT
            new_out = solve(X, r, assume_a=get_assume_a(fgraph, X))
            return [atleast_Nd(new_out, n=out.type.ndim)]

    r_core, r_transposed = strip_left_expand_dims_and_transpose(r)
    match r_core.owner_op_and_inputs:
        case (Blockwise(MatrixInverse()), X):
            if r_transposed:
                X = X.mT
            assume_a = get_assume_a(fgraph, X)
            # X.mT == X for sym/pos, so reuse X and skip an unnecessary transpose.
            if assume_a in ("sym", "pos"):
                new_out = solve(X, l.mT, assume_a=assume_a).mT
            else:
                new_out = solve(X.mT, l.mT, assume_a=ASSUME_A_OF_TRANSPOSE[assume_a]).mT
            return [atleast_Nd(new_out, n=out.type.ndim)]

    return None


@register_canonicalize
@register_stabilize
@node_rewriter([blockwise_of(MATRIX_INVERSE_OPS)])
def inv_of_inv(fgraph, node):
    """
    This rewrite takes advantage of the fact that if there are two consecutive inverse operations (inv(inv(input))),
    we get back our original input without having to compute inverse once.

    Here, we check for direct inverse operations (inv/pinv)  and allows for any combination of these "inverse" nodes to
    be simply rewritten.

    Parameters
    ----------
    fgraph: FunctionGraph
        Function graph being optimized
    node: Apply
        Node of the function graph to be optimized

    Returns
    -------
    list of Variable, optional
        List of optimized variables, or None if no optimization was performed
    """
    inner, transposed = strip_left_expand_dims_and_transpose(node.inputs[0])
    match inner.owner_op_and_inputs:
        case (Blockwise(MatrixInverse() | MatrixPinv()), X):
            # inv(inv(X).mT) == inv(inv(X.mT)) == X.mT
            if transposed:
                X = X.mT
            [out] = node.outputs
            return [atleast_Nd(X, n=out.type.ndim).astype(out.type.dtype)]


@register_canonicalize
@register_stabilize
@node_rewriter([blockwise_of(MATRIX_INVERSE_OPS)])
def inv_of_orthogonal_to_transpose(fgraph, node):
    """inv(Q) -> Q.conj().T when Q is orthogonal (unitary, for complex Q)."""
    [X] = node.inputs
    if not check_assumption(fgraph, X, ORTHOGONAL):
        return None
    return [X.conj().mT]


@register_canonicalize
@register_stabilize
@node_rewriter([blockwise_of(MATRIX_INVERSE_OPS)])
def inv_of_diag_to_diag_reciprocal(fgraph, node):
    """inv(D) -> AllocDiag(1 / diagonal(D)) for diagonal D."""
    inp = node.inputs[0]

    if not check_assumption(fgraph, inp, DIAGONAL):
        return None

    diag_vals = pt.diagonal(inp, axis1=-2, axis2=-1)
    return [alloc_diag(1 / diag_vals, axis1=-2, axis2=-1)]


@register_specialize
@node_rewriter([blockwise_of(MatrixInverse | Cholesky | MatrixPinv)])
def lift_linalg_of_expanded_matrices(fgraph: FunctionGraph, node: Apply):
    """
    Rewrite compositions of linear algebra operations by lifting expensive operations (Cholesky, Inverse) through Ops
    that join matrices (KroneckerProduct, BlockDiagonal).

    This rewrite takes advantage of commutation between certain linear algebra operations to do several smaller matrix
    operations on component matrices instead of one large one. For example, when taking the inverse of Kronecker
    product, we can take the inverse of each component matrix and then take the Kronecker product of the inverses. This
    reduces the cost of the inverse from O((n*m)^3) to O(n^3 + m^3) where n and m are the dimensions of the component
    matrices.

    Parameters
    ----------
    fgraph: FunctionGraph
        Function graph being optimized
    node: Apply
        Node of the function graph to be optimized

    Returns
    -------
    list of Variable, optional
        List of optimized variables, or None if no optimization was performed
    """

    # TODO: Simplify this if we end up Blockwising KroneckerProduct
    outer_op = node.op
    [y] = node.inputs
    [out] = node.outputs
    # block_diag(...).mT == block_diag(*m.mT) and kron(a, b).mT == kron(a.mT, b.mT),
    # so a peeled transpose moves onto the component matrices
    y_core, transposed = strip_left_expand_dims_and_transpose(y)  # type: ignore[arg-type]

    match y_core.owner_op_and_inputs:
        case (Blockwise(BlockDiagonal()), *inner_matrices):
            if transposed:
                inner_matrices = [m.mT for m in inner_matrices]  # type: ignore[attr-defined]
            new_out = block_diag(*(outer_op(m) for m in inner_matrices))
            return [atleast_Nd(new_out, n=out.type.ndim).astype(out.type.dtype)]
        case (KroneckerProduct(), *inner_matrices):  # type: ignore[unreachable, unused-ignore]
            if transposed:  # type: ignore[unreachable, unused-ignore]
                inner_matrices = [m.mT for m in inner_matrices]  # type: ignore[attr-defined]
            new_out = kron(*(outer_op(m) for m in inner_matrices))
            return [atleast_Nd(new_out, n=out.type.ndim).astype(out.type.dtype)]
