from collections import deque
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from enum import IntFlag, auto
from typing import Any

from pytensor.graph import Apply, FunctionGraph, Op
from pytensor.graph.basic import Variable
from pytensor.graph.features import AlreadyThere, Feature
from pytensor.graph.traversal import walk_toposort
from pytensor.tensor import TensorLike
from pytensor.tensor.variable import TensorConstant


class FactState(IntFlag):
    """Three-valued logic for assumption inference.

    The three fact states are TRUE, FALSE and UNKNOWN.

    UNKNOWN is the default condition, in which we cannot confirm or deny the fact.  TRUE and FALSE are definitive
    states.  If we have evidence that a fact is both TRUE and FALSE, we get CONFLICT. In general, a CONFLICT state
    should not be possible.
    """

    UNKNOWN = 0
    TRUE = auto()
    FALSE = auto()
    CONFLICT = TRUE | FALSE

    def __bool__(self) -> bool:
        raise TypeError(
            "FactState has no boolean value; compare against FactState.TRUE, "
            "FactState.UNKNOWN, etc. explicitly, or use AssumptionFeature.check()."
        )

    @classmethod
    def join(cls, left: "FactState", right: "FactState") -> "FactState":
        """Combine two pieces of evidence about the *same* (variable, key)."""
        return cls(left | right)


@dataclass(frozen=True)
class AssumptionKey:
    """Identifies a named structural property (e.g. "diagonal" or "triangular").

    Constructing a key registers it in :data:`KEY_REGISTRY` and installs every rule
    declared with :func:`register_universal_assumption` for it, which is all a
    downstream library must do to add a property of its own.

    ``name`` is the key's identity: it is what :func:`assume` accepts as a keyword and
    what two keys may not share unless they are identical in every field.

    Parameters
    ----------
    name : str
        Unique identifier for the property, also the keyword :func:`assume` accepts.
    short_name : str, optional
        Abbreviated label used by ``debugprint(print_assumptions=True)``. Falls back
        to ``name`` when empty.

    Examples
    --------
    .. code-block:: python

        import pytensor.tensor as pt
        from pytensor.assumptions import AssumptionKey, FactState, register_assumption
        from pytensor.tensor.elemwise import Elemwise

        TOEPLITZ = AssumptionKey("toeplitz", short_name="toep")

        x = TOEPLITZ.assume(pt.matrix("x"))
        TOEPLITZ.holds(x)  # True
        TOEPLITZ.holds(pt.exp(x))  # False -- no rule teaches it about Elemwise yet

    A key answers only what its rules can derive, so teach it the Ops it should see
    through. Constant diagonals survive an entrywise op, unless an input broadcasts
    along one of the last two axes while varying along the other:

    .. code-block:: python

        @register_assumption(TOEPLITZ, Elemwise)
        def _elemwise_is_toeplitz(key, op, feature, fgraph, node, input_states):
            entrywise = all(
                feature.check(inp, key)  # the operand is itself Toeplitz
                or all(inp.type.broadcastable[-2:])  # or broadcasts a single value
                for inp in node.inputs
            )
            return [FactState.TRUE if entrywise else FactState.UNKNOWN]


        TOEPLITZ.holds(pt.exp(x))  # True
        TOEPLITZ.holds(x + x)  # True
        TOEPLITZ.holds(x + pt.vector("v"))  # False -- the row varies along one axis

    See :func:`register_matrix_property_rules` for the rules a property of the
    trailing two axes needs to survive transposes, reshapes, and indexing.
    """

    name: str
    short_name: str = ""

    def __post_init__(self) -> None:
        registered = KEY_REGISTRY.get(self.name)
        if registered is not None:
            if registered != self:
                raise ValueError(
                    f"An assumption named {self.name!r} is already registered as "
                    f"{registered!r} with different metadata. Assumption names are "
                    f"global identifiers; pick a distinct one."
                )
            # Re-creating an identical key (a module imported twice) is a no-op:
            # equal keys hash alike, so the installed rules already apply to it.
            return

        KEY_REGISTRY[self.name] = self
        for op_types, fn in UNIVERSAL_RULES:
            _install_rule(self, op_types, fn)

    def __reduce__(self):
        # Unpickle through the constructor: the default dataclass path skips __init__,
        # leaving a key that is in no registry and has no rules installed -- not even
        # the one that reads declarations back off SpecifyAssumptions.
        return type(self), (self.name, self.short_name)

    def __repr__(self) -> str:
        return self.name

    def assume(self, x: TensorLike, *, state: bool = True):
        """Return a view of *x* declaring this assumption.

        Parameters
        ----------
        x : tensor-like
            The input to annotate.
        state : bool, optional
            Whether to assert the property holds or that it does not. Default True.

        Returns
        -------
        out : TensorVariable
            A view of *x* with the assumption attached.
        """
        from pytensor.assumptions.specify import SpecifyAssumptions

        fact = FactState.TRUE if state else FactState.FALSE
        return SpecifyAssumptions({self: fact})(x)

    def holds(self, var: Variable, fgraph: FunctionGraph | None = None) -> bool:
        """Return True iff this assumption is provably TRUE for *var*.

        Parameters
        ----------
        var : Variable
            The variable to ask about.
        fgraph : FunctionGraph, optional
            Graph to resolve the question in. Pass one when asking about several
            variables of the same graph: without it a throwaway ``FunctionGraph`` is
            built per call, which walks the ancestors of *var* and discards the
            inference cache afterwards.

        Returns
        -------
        holds : bool
            True when the property is known to hold, False when it is known not to
            hold or is simply unknown.
        """
        if fgraph is None:
            fgraph = FunctionGraph(outputs=[var], clone=False)
        return check_assumption(fgraph, var, self)


class ConflictingAssumptionsError(ValueError):
    """Raised when joining evidence about a (variable, key) produces ``FactState.CONFLICT``.

    Surfaces contradictions between user-asserted facts and inferred facts (or between
    multiple sources of inferred facts) before they can silently corrupt downstream rewrites.
    """


# An inference function takes the active AssumptionKey, the Op, the current AssumptionFeature, the FunctionGraph,
# the Apply node being analyzed, and the states of the input variables for the current key. It returns a list of
# FactState with one entry per node output.
InferFactFn = Callable[
    [AssumptionKey, Op, "AssumptionFeature", FunctionGraph, Apply, list[FactState]],
    list[FactState],
]

# The global inference registry maps (AssumptionKey, Op type) pairs to lists of inference functions.
# Rules are tried in registration order; the first to return TRUE wins.
ASSUMPTION_INFER_REGISTRY: dict[tuple[AssumptionKey, type], list[InferFactFn]] = {}

# Every AssumptionKey ever constructed, by name. Downstream libraries join the system
# by constructing a key; nothing else is required of them. This resolves the names
# :func:`assume` takes as keywords -- graphs themselves carry keys, not names, so
# nothing downstream of graph construction needs to look anything up here.
KEY_REGISTRY: dict[str, AssumptionKey] = {}

# Rules that hold for every key regardless of what the key means, as (op_types, fn)
# pairs. Kept separately from ASSUMPTION_INFER_REGISTRY so that keys created *after*
# the rule is declared still receive it -- see AssumptionKey.__post_init__.
UNIVERSAL_RULES: list[tuple[tuple[type, ...], InferFactFn]] = []


def _install_rule(
    key: AssumptionKey, op_types: tuple[type, ...], fn: InferFactFn
) -> None:
    for op_type in op_types:
        ASSUMPTION_INFER_REGISTRY.setdefault((key, op_type), []).append(fn)


def register_universal_assumption(
    *op_types: type,
) -> Callable[[InferFactFn], InferFactFn]:
    """Decorator registering an inference rule that applies to *every* assumption key.

    Use this for rules that are indifferent to what the property means -- an Op that
    forwards its input unchanged, or one that delegates to another Op. The rule is
    installed for keys that already exist and for every key created later.

    Parameters
    ----------
    *op_types : type
        Op classes the rule applies to.
    """

    def decorator(fn: InferFactFn) -> InferFactFn:
        UNIVERSAL_RULES.append((op_types, fn))
        for key in KEY_REGISTRY.values():
            _install_rule(key, op_types, fn)
        return fn

    return decorator


class KeyRegistryView:
    """Live, read-only view of every registered :class:`AssumptionKey`."""

    __slots__ = ()

    def __iter__(self) -> Iterator[AssumptionKey]:
        # Snapshot: a rule that constructs a key would otherwise resize the registry
        # mid-iteration.
        return iter(tuple(KEY_REGISTRY.values()))

    def __contains__(self, value: object) -> bool:
        # Only a key can be registered, so the isinstance both guards the ``name``
        # access and lets the lookup be a hit rather than a scan.
        return (
            isinstance(value, AssumptionKey) and KEY_REGISTRY.get(value.name) == value
        )

    def __len__(self) -> int:
        return len(KEY_REGISTRY)

    def __repr__(self) -> str:
        return f"({', '.join(KEY_REGISTRY)})"


# Registry mapping assumptions to other assumptions they imply.  For example, a "diagonal" matrix is also "symmetric"
# and "triangular".  This is consulted after all other inference rules to derive additional facts.
IMPLIES: dict[AssumptionKey, list[AssumptionKey]] = {}


def register_implies(stronger: AssumptionKey, *weaker: AssumptionKey) -> None:
    """Declare that *stronger* being TRUE implies each *weaker* key is also TRUE."""
    IMPLIES.setdefault(stronger, []).extend(weaker)


# Maps a key to a function that infers it directly from a literal TensorConstant's data.
# AssumptionFeature consults this for variables with no owner, letting a property be
# derived from raw values (e.g. recognising a constant diagonal matrix).
ConstantInferFn = Callable[[TensorConstant], FactState]
CONSTANT_INFER_REGISTRY: dict[AssumptionKey, ConstantInferFn] = {}


def register_constant_inference(key: AssumptionKey, fn: ConstantInferFn) -> None:
    """Register *fn* as the literal-constant inference for *key*."""
    CONSTANT_INFER_REGISTRY[key] = fn


# Maps (key, Op type) to rules that read a fact about a variable off a node consuming it,
# such as ``solve(a, b, assume_a="pos")`` promising that ``a`` is positive definite. A rule
# is called as ``fn(key, op, node, input_index)`` and returns the state of that input.
ClientInferFn = Callable[[AssumptionKey, Op, Apply, int], FactState]
CLIENT_INFER_REGISTRY: dict[tuple[AssumptionKey, type], ClientInferFn] = {}
# Keys with at least one client rule. Inference skips the client scan for every other key.
CLIENT_INFER_KEYS: set[AssumptionKey] = set()


def register_client_inference(
    key: AssumptionKey, *op_types: type
) -> Callable[[ClientInferFn], ClientInferFn]:
    """Decorator that registers a client inference rule for ``(key, op_type)`` pairs."""

    def decorator(fn: ClientInferFn) -> ClientInferFn:
        for op_type in op_types:
            CLIENT_INFER_REGISTRY[(key, op_type)] = fn
        CLIENT_INFER_KEYS.add(key)
        return fn

    return decorator


def infer_assumption_from_client(
    key: AssumptionKey, op: Op, node: Apply, input_index: int
) -> FactState:
    """Return what *node* promises about its input at *input_index* for *key*."""
    # Imported here because pytensor.tensor.rewriting loads this module before tensor.basic,
    # and importing blockwise first trips the compile.builders <-> tensor.basic cycle.
    from pytensor.tensor.blockwise import Blockwise

    if isinstance(op, Blockwise):
        op = op.core_op
    for cls in type(op).__mro__:
        fn = CLIENT_INFER_REGISTRY.get((key, cls))
        if fn is not None:
            return fn(key, op, node, input_index)
    return FactState.UNKNOWN


# The canonical structural-property keys
DIAGONAL = AssumptionKey("diagonal", short_name="diag")
LOWER_TRIANGULAR = AssumptionKey("lower_triangular", short_name="tril")
UPPER_TRIANGULAR = AssumptionKey("upper_triangular", short_name="triu")
SYMMETRIC = AssumptionKey("symmetric", short_name="sym")
TRIDIAGONAL = AssumptionKey("tridiagonal", short_name="tridiag")
POSITIVE_DEFINITE = AssumptionKey("positive_definite", short_name="pd")
ORTHOGONAL = AssumptionKey("orthogonal", short_name="orth")
SELECTION = AssumptionKey("selection", short_name="sel")
PERMUTATION = AssumptionKey("permutation", short_name="perm")
UNIQUE_INDICES = AssumptionKey("unique_indices", short_name="uniq")
UNIT_MAGNITUDE = AssumptionKey("unit_magnitude", short_name="unit")

MATRIX_KEYS = (
    DIAGONAL,
    LOWER_TRIANGULAR,
    UPPER_TRIANGULAR,
    SYMMETRIC,
    TRIDIAGONAL,
    POSITIVE_DEFINITE,
    ORTHOGONAL,
    SELECTION,
    PERMUTATION,
)

# Live view rather than a tuple: a key registered by a downstream library shows up here
# too, so anything that iterates the keys at call time (debugprint, the drain rewrite)
# covers it without further registration.
ALL_KEYS = KeyRegistryView()

# Implications about structural properties derivably from other structural properties
register_implies(DIAGONAL, LOWER_TRIANGULAR, UPPER_TRIANGULAR, SYMMETRIC, TRIDIAGONAL)
register_implies(POSITIVE_DEFINITE, SYMMETRIC)
register_implies(PERMUTATION, SELECTION, ORTHOGONAL)


def register_assumption(
    key: AssumptionKey, *op_types: type, prepend: bool = False
) -> Callable[[InferFactFn], InferFactFn]:
    """Decorator that registers an inference rule for ``(key, op_type)`` pairs.

    The decorated function is called as ``fn(key, op, feature, fgraph, node, input_states)``
    and must return a list of :class:`FactState` with one entry per node output.

    Parameters
    ----------
    key : AssumptionKey
        The property the rule infers.
    *op_types : type
        Op classes the rule applies to.
    prepend : bool, optional
        Run this rule ahead of those already registered for the same pair rather than
        after them. Rules are tried in order until one returns a non-UNKNOWN state, so
        this is how a key overrides a rule it inherited from a bundle. Default False.
    """

    def decorator(fn: InferFactFn) -> InferFactFn:
        for op_type in op_types:
            rules = ASSUMPTION_INFER_REGISTRY.setdefault((key, op_type), [])
            if prepend:
                rules.insert(0, fn)
            else:
                rules.append(fn)
        return fn

    return decorator


def infer_assumption_for_node(
    key: AssumptionKey,
    op: Op,
    feature: "AssumptionFeature",
    fgraph: FunctionGraph,
    node: Apply,
    input_states: list[FactState],
) -> list[FactState]:
    """Determine the *key* fact for every output of *node*.

    Walks the Op's MRO for the most specific :func:`register_assumption` rule and
    returns the first non-UNKNOWN result. Falls back to ``UNKNOWN`` per output.
    """
    rules: list[InferFactFn] = []
    for cls in type(op).__mro__:
        fns = ASSUMPTION_INFER_REGISTRY.get((key, cls))
        if fns is not None:
            rules = fns
            break

    n_outputs = len(node.outputs)
    for fn in rules:
        output_states = fn(key, op, feature, fgraph, node, input_states)
        if len(output_states) != n_outputs:
            raise ValueError(
                f"an assumption rule returned {len(output_states)} states for "
                f"{n_outputs} outputs on node {node!r}"
            )
        if any(s is not FactState.UNKNOWN for s in output_states):
            return output_states

    return [FactState.UNKNOWN] * n_outputs


class AssumptionFeature(Feature):
    """``FunctionGraph`` feature that tracks symbolic assumptions about variables.

    Assumptions (e.g. "this matrix is diagonal") are represented as ``(variable,
    AssumptionKey) -> FactState`` mappings. Facts are inferred lazily via per-Op
    rules registered with :func:`register_assumption`.

    Attached lazily by :func:`check_assumption` on first use.
    Results are cached and automatically refreshed when the graph changes.
    """

    __slots__ = ("_stale_vars", "_var_to_keys", "cache", "fgraph")

    def on_attach(self, fgraph: Any) -> None:
        if hasattr(fgraph, "assumption_feature"):
            raise AlreadyThere("AssumptionFeature is already attached")
        self.fgraph = fgraph
        self.cache: dict[tuple[Any, AssumptionKey], FactState] = {}
        self._var_to_keys: dict[Any, set[AssumptionKey]] = {}
        self._stale_vars: set = set()
        fgraph.assumption_feature = self

    def on_detach(self, fgraph: Any) -> None:
        self.cache = {}
        self._var_to_keys = {}
        self._stale_vars = set()
        self.fgraph = None
        del fgraph.assumption_feature

    def on_change_input(self, fgraph, node, i, old_var, new_var, reason=None) -> None:
        # Carry non-UNKNOWN facts from old_var to new_var, then defer downstream
        # UNKNOWN invalidation to the next get()/check() call.
        # CONFLICT is cached, not raised: the graph mutation has already landed,
        # so raising here corrupts the caller's view.
        for key in self._var_to_keys.get(old_var, ()):
            old_state = self.cache.get((old_var, key))
            if old_state is None or old_state is FactState.UNKNOWN:
                continue
            new_state = self.cache.get((new_var, key))
            if new_state is None or new_state is FactState.UNKNOWN:
                self.cache[(new_var, key)] = old_state
            else:
                self.cache[(new_var, key)] = FactState.join(old_state, new_state)
            self._var_to_keys.setdefault(new_var, set()).add(key)
            # new_var gained a fact whose implications were cached UNKNOWN before it was
            # known; flag it so the next get() sweep re-derives those stale entries.
            self._stale_vars.add(new_var)

        self._stale_vars.update(node.outputs)

    def on_prune(self, fgraph, node, reason=None) -> None:
        self._stale_vars.difference_update(node.outputs)

    def clone(self) -> "AssumptionFeature":
        # Cache entries are keyed on variable identity, so the cloned feature starts empty
        # and re-derives facts from the cloned graph (assumptions attached via ``assume()``
        # follow their variables through the clone since they live as graph nodes).
        return AssumptionFeature()

    def get(self, var: Any, key: AssumptionKey) -> FactState:
        """Return the inferred :class:`FactState` for ``(var, key)``.

        Raise :class:`ConflictingAssumptionsError` when the cached state is
        :attr:`FactState.CONFLICT` — surfaces conflicts from substitutions or
        owner-inferred rules at the point of query, where the graph is stable
        and the caller can react.
        """
        cache_key = (var, key)
        state = self.cache.get(cache_key)
        if state is None or state is FactState.UNKNOWN:
            if self._stale_vars:
                self._drop_unknown_downstream(self._stale_vars)
                self._stale_vars.clear()
                # Re-check: the UNKNOWN will still be valid
                # if the stale vars were not ancestors of var.
                state = self.cache.get(cache_key)
            if state is None:
                state = self._compute(var, key)
        if state is FactState.CONFLICT:
            raise ConflictingAssumptionsError(
                f"Conflicting evidence for key {key!r} on {var!r}."
            )
        return state

    def check(self, var: Any, key: AssumptionKey) -> bool:
        """Return ``True`` iff the assumption is definitively TRUE for ``var``."""
        return self.get(var, key) is FactState.TRUE

    def _compute(self, var: Any, key: AssumptionKey) -> FactState:
        """Infer the fact state for ``(var, key)``, caching ancestors inputs-first.

        When the owner says nothing, asks the clients of ``var`` what they promise about it.
        Then walks the ``IMPLIES`` graph in both directions:
          - Forward: a stronger key being TRUE makes this (weaker) key TRUE.
          - Contrapositive: a weaker key being FALSE makes this (stronger) key FALSE.

        Raise :class:`ConflictingAssumptionsError` if owner-inferred rules produce
        ``FactState.CONFLICT``.
        """

        def deps(v: Any) -> tuple:
            # Stop descending at cached variables — their facts (and their ancestors')
            # are already settled for this key.
            if (v, key) in self.cache:
                return ()
            owner = getattr(v, "owner", None)
            return tuple(owner.inputs) if owner is not None else ()

        for v in walk_toposort([var], deps):
            if (v, key) in self.cache:
                continue

            # Cache UNKNOWN up front so any recursive ``self.get(v, other_key)`` triggered
            # by the IMPLIES checks sees a placeholder instead of recursing back here.
            self.cache[(v, key)] = FactState.UNKNOWN
            self._var_to_keys.setdefault(v, set()).add(key)

            owner = getattr(v, "owner", None)
            if owner is not None:
                input_states = [self.get(inp, key) for inp in owner.inputs]
                output_states = infer_assumption_for_node(
                    key, owner.op, self, self.fgraph, owner, input_states
                )
                state = output_states[owner.outputs.index(v)]
            elif isinstance(v, TensorConstant) and key in CONSTANT_INFER_REGISTRY:
                state = CONSTANT_INFER_REGISTRY[key](v)
            else:
                state = FactState.UNKNOWN

            if state is FactState.UNKNOWN and key in CLIENT_INFER_KEYS:
                for client, input_index in self.fgraph.clients.get(v, ()):
                    state = infer_assumption_from_client(
                        key, client.op, client, input_index
                    )
                    if state is not FactState.UNKNOWN:
                        break

            if state is FactState.UNKNOWN:
                for stronger, weaker_list in IMPLIES.items():
                    if key in weaker_list and self.get(v, stronger) is FactState.TRUE:
                        state = FactState.TRUE
                        break

            if state is FactState.UNKNOWN:
                for weaker in IMPLIES.get(key, ()):
                    if self.get(v, weaker) is FactState.FALSE:
                        state = FactState.FALSE
                        break

            if state is FactState.CONFLICT:
                raise ConflictingAssumptionsError(
                    f"Conflicting evidence for {key} on {v!r} from owner-inferred rules."
                )

            self.cache[(v, key)] = state

        return self.cache[(var, key)]

    def _drop_unknown_downstream(self, start_vars) -> None:
        """Drop UNKNOWN entries for *start_vars* and downstream so they re-probe."""
        cache = self.cache
        var_to_keys = self._var_to_keys
        clients = self.fgraph.clients
        queue = deque(start_vars)
        seen = set(start_vars)
        while queue:
            var = queue.popleft()
            keys = var_to_keys.get(var)
            if keys:
                for key in [
                    k for k in keys if cache.get((var, k)) is FactState.UNKNOWN
                ]:
                    cache.pop((var, key), None)
                    keys.discard(key)
                if not keys:
                    var_to_keys.pop(var, None)
            for client_node, _ in clients.get(var, ()):
                for out in client_node.outputs:
                    if out not in seen:
                        seen.add(out)
                        queue.append(out)


def true_if(cond: bool, else_false: bool = False) -> list[FactState]:
    """``[TRUE]`` when *cond* holds, ``[UNKNOWN]`` (or ``[FALSE]``) otherwise."""
    if cond:
        return [FactState.TRUE]
    return [FactState.FALSE] if else_false else [FactState.UNKNOWN]


def propagate_first(key, op, feature, fgraph, node, input_states) -> list[FactState]:
    """Output inherits the assumption iff the first input has it."""
    return true_if(input_states[0] is FactState.TRUE)


def all_inputs_have_key(
    key, op, feature, fgraph, node, input_states
) -> list[FactState]:
    """Output inherits the assumption iff *every* input has it."""
    return true_if(all(s is FactState.TRUE for s in input_states))


def check_assumption(
    fgraph: FunctionGraph | None, var: Any, key: AssumptionKey
) -> bool:
    """Return True iff *key* is definitively TRUE for *var* in *fgraph*.

    Lazily attaches :class:`AssumptionFeature` to *fgraph* if it is not already present.
    """
    if fgraph is None:
        return False
    feature = getattr(fgraph, "assumption_feature", None)
    if feature is None:
        feature = AssumptionFeature()
        fgraph.attach_feature(feature)
    return feature.check(var, key)
