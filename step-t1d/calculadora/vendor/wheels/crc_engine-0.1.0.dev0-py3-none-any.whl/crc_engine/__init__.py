"""crc-engine: the STEP-T1D capture-recapture engine.

Pure Python (numpy, scipy, pandas, xarray, pytensor, pymc, arviz), so the same
code runs in the study pipeline and, through Pyodide, in the public calculator.
"""

__version__ = "0.1.0.dev0"
