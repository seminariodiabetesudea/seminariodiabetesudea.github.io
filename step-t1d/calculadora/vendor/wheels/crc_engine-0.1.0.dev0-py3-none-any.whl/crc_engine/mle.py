"""Maximum-likelihood fits of log-linear models (Poisson GLM, Newton-IRLS).

Used for the frequentist cross-check (Phase 4, check 3) and for quick
measurements during the audit.  Pure numpy.  (The browser calculator's Laplace
step works on each model's own PyMC log density instead; Phase 6 spike,
decision 85.)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .modelspace import Design


@dataclass(frozen=True)
class MLEFit:
    beta: np.ndarray
    cov: np.ndarray
    loglik: float
    converged: bool
    boundary: bool            # some fitted values went to zero / estimates diverged
    n_iter: int
    n_observed: int
    hidden_by_stratum: np.ndarray
    hidden_var: float         # delta-method variance of the total hidden count

    @property
    def hidden(self) -> float:
        return float(self.hidden_by_stratum.sum())

    @property
    def N(self) -> float:
        return self.n_observed + self.hidden

    def N_interval(self, level: float = 0.95) -> tuple[float, float]:
        """Log-normal interval for N (Chao 1987 form), bounded below by n.

        Uses the delta-method variance of the hidden count plus its Poisson
        variance, so it is a prediction interval for the realised total.
        """
        from scipy.stats import norm

        z = norm.ppf(0.5 + level / 2)
        M = self.hidden
        if M <= 0:
            return (float(self.n_observed), float(self.n_observed))
        var = self.hidden_var + M
        C = np.exp(z * np.sqrt(np.log1p(var / M**2)))
        return (self.n_observed + M / C, self.n_observed + M * C)


def poisson_loglik(y: np.ndarray, eta: np.ndarray) -> float:
    from scipy.special import gammaln

    return float(np.sum(y * eta - np.exp(eta) - gammaln(y + 1)))


def fit_poisson(X: np.ndarray, y: np.ndarray, *, max_iter: int = 200, tol: float = 1e-10,
                ridge: float = 0.0) -> tuple[np.ndarray, np.ndarray, float, bool, bool, int]:
    """Newton-Raphson for a Poisson log-link GLM. Returns (beta, cov, loglik, converged, boundary, iters)."""
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    P = X.shape[1]
    # start from a least-squares fit to log(y + 0.5)
    beta = np.linalg.lstsq(X, np.log(y + 0.5), rcond=None)[0]
    converged = False
    it = 0
    for it in range(1, max_iter + 1):
        eta = np.clip(X @ beta, -50, 50)
        mu = np.exp(eta)
        grad = X.T @ (y - mu) - ridge * beta
        Hm = (X * mu[:, None]).T @ X + ridge * np.eye(P)
        try:
            step = np.linalg.solve(Hm, grad)
        except np.linalg.LinAlgError:
            step = np.linalg.lstsq(Hm, grad, rcond=None)[0]
        beta = beta + step
        if np.max(np.abs(step)) < tol * (1 + np.max(np.abs(beta))):
            converged = True
            break
    eta = X @ beta
    mu = np.exp(np.clip(eta, -50, 50))
    Hm = (X * mu[:, None]).T @ X + ridge * np.eye(P)
    cond = np.linalg.cond(Hm)
    boundary = bool((np.abs(beta) > 25).any() or cond > 1e12 or (mu < 1e-8).any())
    cov = np.linalg.pinv(Hm)
    return beta, cov, poisson_loglik(y, eta), converged, boundary, it


@dataclass(frozen=True)
class LaplaceFit:
    mode: np.ndarray          # MAP estimate
    cov: np.ndarray           # inverse Hessian of the negative log posterior at the mode
    log_evidence: float       # Laplace approximation to log p(y | model)


def laplace_fit(X: np.ndarray, y: np.ndarray, prior_mean: np.ndarray, prior_sd: np.ndarray,
                *, max_iter: int = 200, tol: float = 1e-10) -> LaplaceFit:
    """MAP and Gaussian (Laplace) approximation of a Poisson log-linear posterior
    under independent Normal priors.

    Only for designs whose coefficients have independent priors (the Phase 1
    builder ``models.build_model``).  The structured models' zero-sum effects
    are correlated a priori, and treating them as independent puts the log
    evidence off by up to half a log unit (Phase 4 pilot); nothing in the
    pipeline uses Laplace evidence for model weights (analysis plan, model
    averaging)."""
    X = np.asarray(X, float)
    y = np.asarray(y, float)
    m0 = np.asarray(prior_mean, float)
    s0 = np.asarray(prior_sd, float)
    prec = 1.0 / s0**2
    beta = m0.copy()
    for _ in range(max_iter):
        mu = np.exp(np.clip(X @ beta, -50, 50))
        grad = X.T @ (y - mu) - prec * (beta - m0)
        Hm = (X * mu[:, None]).T @ X + np.diag(prec)
        step = np.linalg.solve(Hm, grad)
        beta = beta + step
        if np.max(np.abs(step)) < tol * (1 + np.max(np.abs(beta))):
            break
    eta = X @ beta
    mu = np.exp(np.clip(eta, -50, 50))
    Hm = (X * mu[:, None]).T @ X + np.diag(prec)
    log_prior = float(np.sum(-0.5 * np.log(2 * np.pi * s0**2) - 0.5 * prec * (beta - m0) ** 2))
    _, logdet = np.linalg.slogdet(Hm)
    P = X.shape[1]
    ev = poisson_loglik(y, eta) + log_prior + 0.5 * P * np.log(2 * np.pi) - 0.5 * logdet
    return LaplaceFit(beta, np.linalg.inv(Hm), float(ev))


def laplace_log_evidence(X: np.ndarray, y: np.ndarray, prior_mean: np.ndarray, prior_sd: np.ndarray,
                         **kw) -> tuple[float, np.ndarray]:
    """Laplace approximation to log p(y | model); returns (log evidence, MAP)."""
    f = laplace_fit(X, y, prior_mean, prior_sd, **kw)
    return f.log_evidence, f.mode


def fit_design(design: Design, **kw) -> MLEFit:
    """Fit a log-linear model to the observed cells and predict the hidden ones."""
    Xo, yo, Xh = design.X_obs, design.y_obs, design.X_hidden
    rank = np.linalg.matrix_rank(Xo)
    if rank < Xo.shape[1]:
        raise ValueError(
            f"design is not identified on the observed cells (rank {rank} < {Xo.shape[1]} columns)"
        )
    beta, cov, ll, conv, boundary, it = fit_poisson(Xo, yo, **kw)
    mu0 = np.exp(np.clip(Xh @ beta, -50, 50))
    g = (Xh * mu0[:, None]).sum(axis=0)
    var = float(g @ cov @ g)
    return MLEFit(beta, cov, ll, conv, boundary, it, int(yo.sum()), mu0, var)
