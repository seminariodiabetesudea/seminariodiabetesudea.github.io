"""Amendments of the E1 model space (decision 122; ``docs/amendments/decision-122/``).

An amendment is applied to a model of the frozen space through its spec, ``ModelSpec(..., amendment=<id>)``.  The
amended model keeps everything the frozen plan gives the model (its terms, its priors from the plan's prior set, and
in the refit its index, seed and prior probability) and gains what the amendment adds.  The frozen prior sets
(``priors``), the analysis plan rendered from them and the model space are unchanged: an amendment's own prior lives
here.

**AM1, a partially pooled list x year term.**  Each list l and year y get a deviation u[l, y], added to the capture
part of every cell whose history includes l (the hidden cell gains nothing).  The deviations are non-centred:
u[l, years of g] = sigma_l sqrt(n / (n - 1)) z[l, g], with z[l, g] ~ ZeroSumNormal(1) over the n years of group g.
The groups are the periods when the model has list x period (so the term has no component along it), otherwise all
the years in one group.  Given sigma_l every u[l, y] has standard deviation sigma_l, and sigma_l ~ HalfNormal(0.75)
for each list.  In the design the term is the list x year columns in effects coding, with coefficients
u[l, year 1 .. T-1] (``modelspace.design_matrix``); ``models.build_structured_model`` gives them their prior.

**AM2, NB1 counts.**  The model keeps its design and its cell means mu, and its observed counts become NB1(mu, kappa),
the negative binomial with size mu / kappa: mean mu and variance mu (1 + kappa), and Poisson(mu) in the limit
kappa -> 0.  One dispersion kappa ~ HalfNormal(1) serves the whole table.  ``models.build_structured_model`` gives
the counts that likelihood.  The hidden count behind N (``models.posterior_N``) and the replicates of the predictive
checks (``ppc``, ``fit.posterior_check``) are NB1 with each draw's kappa, and so are the simulated tables given kappa
(``models.simulate_counts``).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

from .priors import HalfNormal

#: The decision-log row that pre-registers the amendments.
DECISION = 122


@dataclass(frozen=True)
class Amendment:
    """One amendment of the model space: its id, its decision row, what it does, and the prior of its new parameter."""

    id: str
    decision: int
    description: str
    parameter: str              # the new free parameter (AM1's scales, AM2's dispersion), as the PyMC model names it
    prior: HalfNormal

    def prior_dict(self) -> dict:
        return {"parameter": self.parameter, "distribution": type(self.prior).__name__, **asdict(self.prior)}

    def as_dict(self) -> dict:
        return {"id": self.id, "decision": self.decision, "description": self.description, "prior": self.prior_dict()}


#: AM1's block of capture columns, and its PyMC variables: the scales sigma_l, the zero-sum draws z and the
#: deviations u (a deterministic, lists x years).
AM1_BLOCK = "pooled list×year"
AM1_SIGMA, AM1_Z, AM1_EFFECTS = "list_x_year_sigma", "list_x_year_z", "list_x_year"

AM1 = Amendment("AM1", DECISION, "a partially pooled list x year term in the capture part: deviations that sum to "
                "zero over each period's years (over all the years without list x period), with standard deviation "
                "sigma_l per list", AM1_SIGMA, HalfNormal(0.75))

#: AM2's PyMC variable: the dispersion kappa of the NB1 counts.
AM2_KAPPA = "nb1_kappa"

AM2 = Amendment("AM2", DECISION, "NB1 counts: every observed count is negative binomial with mean mu and variance "
                "mu (1 + kappa), with one dispersion kappa for the whole table; the hidden count and the predictive "
                "replicates are NB1 too", AM2_KAPPA, HalfNormal(1.0))

#: Every amendment, by id.
AMENDMENTS: dict[str, Amendment] = {a.id: a for a in (AM1, AM2)}
