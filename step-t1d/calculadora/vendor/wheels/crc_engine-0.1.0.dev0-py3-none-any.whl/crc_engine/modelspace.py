"""Log-linear capture-recapture model space and design matrices.

For stratum s and history h = (h_1, ..., h_K) the expected count is

    log mu[h, s] = alpha[s]                                    (count part)
                 + sum_j h_j (beta_j + sum_c beta_{j,c}[level_c(s)])   (capture part)
                 + sum_{j<k} h_j h_k lambda_{jk}                 (list dependence)

The hidden cell (h = 0) has log mu = alpha[s]: everything the models say about
the people nobody recorded flows through the count part.

Design rules enforced here (audit items M1, M2, M3, M9):

* The K-way interaction is never in the model space.  When every lower-order
  interaction is present (for three lists, all three pairs) it is aliased with
  the hidden cell: shifting the intercept by +c, every list effect by -c, every
  pair by +c and the K-way term by -c leaves every observed cell unchanged and
  multiplies the hidden cell by e^c, so the data cannot see it and N would rest
  on the priors along that direction.  Without all the pairs it is identified
  only by the full-history cell and breaks the hierarchy of terms.  The builder
  refuses it unless ``allow_kway=True`` (kept to study the aliasing, audit M2);
  sensitivity S9 is applied after the fit instead (``models.s9_hidden``).
* Every model has list main effects.  The classical M0 (equal capture
  probability in every list, independence) is available as
  ``ModelSpec.classical_m0``; a model without list effects is not offered.
* Stratum covariates may modify the capture part (list x age band, list x
  period, list x sex), coded sum-to-zero so a prior means the same thing in
  every model.
* The parameter count of a model is the number of design-matrix columns.
* An amendment of the E1 space (``ModelSpec.amendment``, decision 122; ``crc_engine.amendments``) adds to a model
  and removes nothing.  AM1 adds the list x year columns in effects coding, the coefficients of a partially pooled
  term whose prior ``models.build_structured_model`` sets.  AM2 leaves the design as it is: it changes the counts'
  distribution, which ``models.build_structured_model`` sets.  A model without an amendment is built as before.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field, replace
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from .amendments import AM1, AM1_BLOCK, AMENDMENTS
from .tables import CaptureTable, histories


class NonIdentifiableModelError(ValueError):
    """Raised when a requested model cannot identify the hidden cell."""


def sum_to_zero(levels: Sequence) -> np.ndarray:
    """Sum-to-zero (effects) coding matrix, shape (L, L-1).

    Level l < L-1 gets the unit vector e_l; the last level gets -1 in every
    column, so the effects of all L levels sum to zero.
    """
    L = len(levels)
    if L < 2:
        return np.zeros((L, 0))
    C = np.vstack([np.eye(L - 1), -np.ones((1, L - 1))])
    return C


def _pair(a: str, b: str, lists: Sequence[str]) -> tuple[str, str]:
    ia, ib = lists.index(a), lists.index(b)
    if ia == ib:
        raise ValueError("a dependence term needs two different lists")
    return (a, b) if ia < ib else (b, a)


@dataclass(frozen=True)
class ModelSpec:
    """One log-linear model.

    Parameters
    ----------
    lists : list names in table order.
    pairs : pairwise dependence terms, e.g. {("A", "B")}.
    list_covariates : stratum variables that modify every list's capture
        probability (list x covariate terms).
    count_part : "saturated" (one free intercept per stratum), "additive"
        (intercept + sum-to-zero main effects of ``count_terms``) or
        "intercept" (one intercept for all strata).
    count_terms : stratum variables for the additive count part.
    equal_capture : classical M0, one capture effect shared by all lists.
    kway : include the K-way interaction (never identified, see module doc).
    allow_kway : must be True to build a model with ``kway``; reserved for the
        prior sensitivity S9, where a proper prior on the K-way term is given.
    amendment : an amendment of the E1 space (``crc_engine.amendments``,
        decision 122), "AM1" or "AM2"; None is the model as the frozen plan
        defines it.  An amended model's name ends in "|<amendment>".
    """

    lists: tuple[str, ...]
    pairs: frozenset = frozenset()
    list_covariates: tuple[str, ...] = ()
    count_part: str = "saturated"
    count_terms: tuple[str, ...] = ()
    equal_capture: bool = False
    kway: bool = False
    allow_kway: bool = False
    label: str | None = field(default=None, compare=False)
    amendment: str | None = None

    def __post_init__(self):
        lists = tuple(self.lists)
        object.__setattr__(self, "lists", lists)
        if len(lists) < 2:
            raise ValueError("at least two lists are needed")
        pairs = frozenset(_pair(a, b, lists) for a, b in self.pairs)
        object.__setattr__(self, "pairs", pairs)
        object.__setattr__(self, "list_covariates", tuple(self.list_covariates))
        object.__setattr__(self, "count_terms", tuple(self.count_terms))
        if self.count_part not in ("saturated", "additive", "intercept"):
            raise ValueError(f"unknown count_part {self.count_part!r}")
        if self.count_part != "additive" and self.count_terms:
            raise ValueError("count_terms only apply to the additive count part")
        if self.kway and not self.allow_kway:
            raise NonIdentifiableModelError(
                f"the {len(lists)}-way interaction is excluded from the model space: with every "
                "lower-order interaction present (all pairs, for three lists) it is aliased with the "
                "hidden cell, so N would rest on the priors along that direction; without them it breaks "
                "the hierarchy of terms. Sensitivity S9 is applied after the fit (models.s9_hidden); "
                "pass allow_kway=True only to study the aliasing (audit M2)."
            )
        if self.kway and len(lists) == 2:
            raise NonIdentifiableModelError("with two lists the A:B term is the K-way term")
        if self.equal_capture and (self.pairs or self.list_covariates or self.kway):
            raise ValueError("equal_capture is the classical M0: independence, no covariate terms")
        if self.amendment is not None and self.amendment not in AMENDMENTS:
            raise ValueError(f"unknown amendment {self.amendment!r}; the amendments are {sorted(AMENDMENTS)}")
        if self.amendment == AM1.id and (self.equal_capture or "year" in self.list_covariates):
            raise ValueError("AM1 adds a list x year term to list-specific capture effects: it does not amend a "
                             "model with equal capture or with a list x year term of its own")

    # ----------------------------------------------------------- descriptions
    @classmethod
    def classical_m0(cls, lists: Sequence[str], **kw) -> "ModelSpec":
        """Classical M0: equal capture probability in every list, independence."""
        return cls(tuple(lists), equal_capture=True, label="M0 (equal capture)", **kw)

    @classmethod
    def independence(cls, lists: Sequence[str], **kw) -> "ModelSpec":
        """Mt in Rcapture's notation: list-specific capture, independence."""
        return cls(tuple(lists), label=kw.pop("label", "independence"), **kw)

    @property
    def K(self) -> int:
        return len(self.lists)

    @property
    def name(self) -> str:
        if self.amendment:
            return f"{replace(self, amendment=None).name}|{self.amendment}"
        if self.label:
            return self.label
        dep = "+".join(a + b for a, b in sorted(self.pairs, key=lambda p: (self.lists.index(p[0]), self.lists.index(p[1])))) or "indep"
        cov = "".join(f"|L×{c}" for c in self.list_covariates)
        kw = "+" + "".join(self.lists) if self.kway else ""
        return f"{dep}{kw}{cov}"

    def terms(self) -> list[str]:
        out = ["capture:equal"] if self.equal_capture else [f"list:{l}" for l in self.lists]
        out += [f"list×{c}" for c in self.list_covariates]
        out += [f"pair:{a}{b}" for a, b in sorted(self.pairs)]
        if self.kway:
            out.append("kway:" + "".join(self.lists))
        return out


@dataclass(frozen=True)
class Design:
    """Design matrix over every cell (S strata x 2^K histories, hidden included)."""

    X: np.ndarray                 # (S * 2^K, P)
    columns: tuple[str, ...]
    blocks: dict                  # column-name prefix -> slice into columns
    hidden: np.ndarray            # bool (S * 2^K,)
    stratum: np.ndarray           # int  (S * 2^K,)
    history: np.ndarray           # int  (S * 2^K,), index into histories(K, include_unobserved=True)
    y: np.ndarray                 # float (S * 2^K,), NaN in hidden rows

    @property
    def n_params(self) -> int:
        """Parameter count = number of design-matrix columns (audit M9)."""
        return self.X.shape[1]

    @property
    def X_obs(self) -> np.ndarray:
        return self.X[~self.hidden]

    @property
    def y_obs(self) -> np.ndarray:
        return self.y[~self.hidden]

    @property
    def X_hidden(self) -> np.ndarray:
        return self.X[self.hidden]


def design_matrix(spec: ModelSpec, table: CaptureTable) -> Design:
    """Build the design matrix of ``spec`` for ``table``."""
    if tuple(spec.lists) != tuple(table.lists):
        raise ValueError(f"model lists {spec.lists} differ from table lists {table.lists}")
    for v in spec.list_covariates + spec.count_terms:
        if v not in table.strata_vars:
            raise KeyError(f"stratum variable {v!r} not in table (has {table.strata_vars})")
    K, S = table.K, table.S
    H = histories(K, include_unobserved=True).astype(float)       # (2^K, K)
    nH = H.shape[0]
    stratum = np.repeat(np.arange(S), nH)
    history = np.tile(np.arange(nH), S)
    Hc = H[history]                                               # (S*2^K, K)

    cols: list[np.ndarray] = []
    names: list[str] = []
    blocks: dict[str, slice] = {}

    def add(block: str, mats: list[np.ndarray], labels: list[str]):
        start = len(names)
        cols.extend(mats)
        names.extend(labels)
        blocks[block] = slice(start, len(names))

    # ---- count part -------------------------------------------------------
    if spec.count_part == "saturated":
        mats, labels = [], []
        for s in range(S):
            mats.append((stratum == s).astype(float))
            desc = ",".join(f"{v}={table.strata.iloc[s][v]}" for v in table.strata_vars) or "all"
            labels.append(f"count[{desc}]")
        add("count", mats, labels)
    else:
        mats, labels = [np.ones(S * nH)], ["count:intercept"]
        if spec.count_part == "additive":
            for v in spec.count_terms:
                lv = table.levels[v]
                C = sum_to_zero(lv)
                idx = np.array([lv.index(x) for x in table.strata[v]])[stratum]
                for k in range(C.shape[1]):
                    mats.append(C[idx, k])
                    labels.append(f"count:{v}[{lv[k]}]")
        add("count", mats, labels)

    # ---- capture part -----------------------------------------------------
    if spec.equal_capture:
        add("capture", [Hc.sum(axis=1)], ["capture:equal"])
    else:
        add("capture", [Hc[:, j] for j in range(K)], [f"list:{l}" for l in spec.lists])
    for v in spec.list_covariates:
        lv = table.levels[v]
        C = sum_to_zero(lv)
        idx = np.array([lv.index(x) for x in table.strata[v]])[stratum]
        mats, labels = [], []
        for j, l in enumerate(spec.lists):
            for k in range(C.shape[1]):
                mats.append(Hc[:, j] * C[idx, k])
                labels.append(f"list:{l}×{v}[{lv[k]}]")
        add(f"list×{v}", mats, labels)
    if spec.pairs:
        order = sorted(spec.pairs, key=lambda p: (spec.lists.index(p[0]), spec.lists.index(p[1])))
        add("pairs", [Hc[:, spec.lists.index(a)] * Hc[:, spec.lists.index(b)] for a, b in order],
            [f"pair:{a}{b}" for a, b in order])
    if spec.kway:
        add("kway", [np.prod(Hc, axis=1)], ["kway:" + "".join(spec.lists)])
    if spec.amendment == AM1.id:
        # AM1 (decision 122): the list x year columns in effects coding, whose coefficients are the pooled deviations
        if "year" not in table.strata_vars:
            raise KeyError(f"AM1's list x year term needs the stratum variable 'year' (table has {table.strata_vars})")
        lv = table.levels["year"]
        C = sum_to_zero(lv)
        idx = np.array([lv.index(x) for x in table.strata["year"]])[stratum]
        add(AM1_BLOCK, [Hc[:, j] * C[idx, k] for j in range(K) for k in range(C.shape[1])],
            [f"list:{l}×year[{lv[k]}]" for l in spec.lists for k in range(C.shape[1])])

    X = np.column_stack(cols)
    hidden = history == 0
    y = np.full(S * nH, np.nan)
    y[~hidden] = table.counts[stratum[~hidden], history[~hidden] - 1]
    return Design(X, tuple(names), blocks, hidden, stratum, history, y)


def model_space(
    lists: Sequence[str],
    covariates: Iterable[str] = (),
    *,
    max_pairs: int | None = None,
    count_part: str = "saturated",
) -> list[ModelSpec]:
    """Enumerate dependence structures x on/off list-covariate terms.

    Three lists with covariates (age band, period, sex): 8 dependence
    structures x 2^3 = 64 models.  Four or five lists with ``max_pairs=2``:
    22 or 56 dependence structures.  The K-way term is never included.
    """
    lists = tuple(lists)
    covariates = tuple(covariates)
    all_pairs = list(itertools.combinations(lists, 2))
    top = len(all_pairs) if max_pairs is None else max_pairs
    specs = []
    for k in range(0, top + 1):
        for pairs in itertools.combinations(all_pairs, k):
            for mask in itertools.product((False, True), repeat=len(covariates)):
                cov = tuple(c for c, on in zip(covariates, mask) if on)
                specs.append(ModelSpec(lists, frozenset(pairs), cov, count_part=count_part))
    return specs
