"""Convergence gates for every NUTS fit (audit items M5, M6).

All rules are required; a model that fails them leaves the model average.
A NaN diagnostic is a failure and is reported as such (v0.2.0 replaced a NaN
R-hat by 1.0 and a NaN ESS by 100).
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

#: Sampler settings from the analysis plan (Phase 3): 4 chains x 2000 draws,
#: 2000 tuning steps, target_accept 0.9 (raised to 0.95-0.99 on divergences).
DEFAULT_SAMPLER = {"chains": 4, "draws": 2000, "tune": 2000, "target_accept": 0.9}
#: target_accept values tried, in order, when a fit has divergent transitions.
RETRY_TARGET_ACCEPT = (0.95, 0.99)
#: A model that fails the gates this many times leaves the model average.
#: Every attempt uses the non-centred form (``models.build_structured_model``'s
#: default, decision 77); the second multiplies the draws and the tuning steps
#: by ``SECOND_ATTEMPT_SCALE``.
MAX_FIT_ATTEMPTS = 2
SECOND_ATTEMPT_SCALE = 2
#: Tail ESS is the smaller ESS of the 5% and 95% quantiles (Vehtari et al. 2021).  It is passed explicitly: without
#: it, arviz-stats 1.x takes its credible-interval probability (rcParams "stats.ci_prob", 0.89) (decision 119).
TAIL_ESS_PROB = (0.05, 0.95)


@dataclass(frozen=True)
class Gates:
    rhat_max: float = 1.01
    ess_bulk_min: float = 400.0
    ess_tail_min: float = 400.0
    ess_N_min: float = 1000.0          # bulk and tail ESS for N itself
    max_divergences: int = 0
    ebfmi_min: float = 0.3
    max_treedepth_frac: float = 0.01


@dataclass
class GateResult:
    passed: bool
    failures: list[str] = field(default_factory=list)
    metrics: dict = field(default_factory=dict)


def _worst(values: np.ndarray, kind: str) -> tuple[float, bool]:
    """Return (worst value, any_nan) for an array of diagnostics."""
    v = np.asarray(values, float).ravel()
    if v.size == 0:
        return (float("nan"), True)
    any_nan = bool(np.isnan(v).any())
    finite = v[~np.isnan(v)]
    if finite.size == 0:
        return (float("nan"), True)
    return (float(finite.max() if kind == "max" else finite.min()), any_nan)


def _draws_tree(name: str, draws: np.ndarray):
    from arviz_base import from_dict

    d = np.asarray(draws, float)
    if d.ndim != 2:
        raise ValueError("draws must have shape (chains, draws)")
    return from_dict({"posterior": {name: d}})


def check_gates(idata, *, N_draws: np.ndarray | None = None, gates: Gates = Gates(),
                var_names: list[str] | None = None) -> GateResult:
    """Apply every pass rule to a fitted model.

    Parameters
    ----------
    idata : xarray.DataTree with ``posterior`` and ``sample_stats`` groups.
    N_draws : posterior draws of N, shape (chains, draws); checked with the
        stricter ESS rule.  If omitted, the N rules are reported as failing,
        because a fit whose estimand was never checked must not pass.
    """
    import arviz_stats as azs

    failures: list[str] = []
    metrics: dict = {}
    post = idata["posterior"]
    names = var_names or [v for v in post.data_vars]

    def collect(stat, kind, label):
        worst_val, worst_name, nan_vars = None, None, []
        for v in names:
            arr = np.asarray(stat[v].values) if v in stat else np.array([np.nan])
            w, has_nan = _worst(arr, kind)
            if has_nan:
                nan_vars.append(v)
            if not np.isnan(w) and (worst_val is None or (w > worst_val if kind == "max" else w < worst_val)):
                worst_val, worst_name = w, v
        metrics[label] = worst_val
        metrics[label + "_var"] = worst_name
        if nan_vars:
            failures.append(f"{label} is NaN for {', '.join(nan_vars)}")
        return worst_val

    rhat = azs.rhat(idata, var_names=names)
    ess_b = azs.ess(idata, var_names=names, method="bulk")
    ess_t = azs.ess(idata, var_names=names, method="tail", prob=TAIL_ESS_PROB)
    r = collect(rhat, "max", "rhat_max")
    eb = collect(ess_b, "min", "ess_bulk_min")
    et = collect(ess_t, "min", "ess_tail_min")
    if r is not None and r > gates.rhat_max:
        failures.append(f"R-hat {r:.4f} > {gates.rhat_max} ({metrics['rhat_max_var']})")
    if eb is not None and eb < gates.ess_bulk_min:
        failures.append(f"bulk ESS {eb:.0f} < {gates.ess_bulk_min:.0f} ({metrics['ess_bulk_min_var']})")
    if et is not None and et < gates.ess_tail_min:
        failures.append(f"tail ESS {et:.0f} < {gates.ess_tail_min:.0f} ({metrics['ess_tail_min_var']})")

    # ---- the estimand itself ---------------------------------------------
    if N_draws is None:
        failures.append("N was not checked (no draws of N supplied)")
    else:
        t = _draws_tree("N", N_draws)
        rN, nan_r = _worst(azs.rhat(t)["N"].values, "max")
        ebN, nan_b = _worst(azs.ess(t, method="bulk")["N"].values, "min")
        etN, nan_t = _worst(azs.ess(t, method="tail", prob=TAIL_ESS_PROB)["N"].values, "min")
        metrics.update(rhat_N=rN, ess_bulk_N=ebN, ess_tail_N=etN)
        if nan_r or np.isnan(rN):
            failures.append("R-hat of N is NaN")
        elif rN > gates.rhat_max:
            failures.append(f"R-hat of N {rN:.4f} > {gates.rhat_max}")
        if nan_b or np.isnan(ebN) or ebN < gates.ess_N_min:
            failures.append(f"bulk ESS of N {ebN:.0f} < {gates.ess_N_min:.0f}")
        if nan_t or np.isnan(etN) or etN < gates.ess_N_min:
            failures.append(f"tail ESS of N {etN:.0f} < {gates.ess_N_min:.0f}")

    # ---- sampler health --------------------------------------------------
    ss = idata["sample_stats"] if "sample_stats" in idata.children else None
    if ss is None:
        failures.append("no sample_stats: divergences, E-BFMI and tree depth cannot be checked")
    else:
        if "diverging" in ss:
            nd = int(np.asarray(ss["diverging"].values).sum())
            metrics["divergences"] = nd
            if nd > gates.max_divergences:
                failures.append(f"{nd} divergent transitions")
        else:
            failures.append("divergences not recorded")
        if "energy" in ss:
            bf = np.asarray(azs.bfmi(idata)["energy"].values, float)   # one value per chain
            w, has_nan = _worst(bf, "min")
            metrics["ebfmi_min"] = w
            if has_nan or np.isnan(w) or w < gates.ebfmi_min:
                failures.append(f"E-BFMI {w:.3f} < {gates.ebfmi_min}")
        else:
            failures.append("energy not recorded: E-BFMI cannot be checked")
        depth_key = next((k for k in ("maxdepth_reached", "reached_max_treedepth") if k in ss), None)
        if depth_key:
            frac = float(np.asarray(ss[depth_key].values, float).mean())
            metrics["treedepth_frac"] = frac
            if frac > gates.max_treedepth_frac:
                failures.append(f"{frac:.1%} of transitions hit the maximum tree depth")
        else:
            failures.append("tree depth not recorded")
    return GateResult(not failures, failures, metrics)
