"""Derived quantities, computed per posterior draw and then summarised (audit R5).

A rate, a ratio, a standardised rate or a pooled period is a function of
several uncertain quantities.  Its interval must come from the draws of that
function, never from combining the ends of other intervals.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Summary:
    median: float
    lower: float
    upper: float
    mean: float
    level: float = 0.95

    def as_dict(self) -> dict:
        return {"median": self.median, "lower": self.lower, "upper": self.upper,
                "mean": self.mean, "level": self.level}


def summarize(draws: np.ndarray, level: float = 0.95) -> Summary:
    """Median and equal-tailed interval of a set of draws (any shape)."""
    d = np.asarray(draws, float).ravel()
    if np.isnan(d).any():
        raise ValueError("draws contain NaN")
    a = (1 - level) / 2
    lo, med, hi = np.quantile(d, [a, 0.5, 1 - a])
    return Summary(float(med), float(lo), float(hi), float(d.mean()), level)


def rate(cases: np.ndarray, person_years: float | np.ndarray, per: float = 1e5) -> np.ndarray:
    """Cases per ``per`` person-years, draw by draw."""
    py = np.asarray(person_years, float)
    if np.any(py <= 0):
        raise ValueError("person-years must be positive")
    return np.asarray(cases, float) / py * per


def ratio(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return np.asarray(a, float) / np.asarray(b, float)


def prob_greater(a: np.ndarray, b: np.ndarray | float) -> float:
    """Posterior probability that a > b."""
    return float(np.mean(np.asarray(a, float) > np.asarray(b, float)))


def completeness(n_observed: float | np.ndarray, N: np.ndarray) -> np.ndarray:
    """Registered / estimated cases, per draw."""
    return np.asarray(n_observed, float) / np.asarray(N, float)


def direct_standardized_rate(cases: np.ndarray, person_years: np.ndarray, weights: np.ndarray,
                             per: float = 1e5) -> np.ndarray:
    """Directly standardised rate per draw.

    cases : draws x groups (or groups); person_years, weights : groups.
    """
    w = np.asarray(weights, float)
    w = w / w.sum()
    r = rate(cases, person_years, per)
    return r @ w
