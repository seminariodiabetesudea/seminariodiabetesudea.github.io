"""Full prior predictive simulation of the model space (analysis plan, J10).

Priors only, no data: for every model, the number of people N and the expected
completeness per stratum-year under the complete count part.

How: the richest model's PyMC prior is drawn once (``pymc.draw``, seeded).
Every other model differs only by capture terms switched off, all a priori
independent of the rest, so its prior is the same draws with those terms at
zero; each model's cell means come from ``models.linear_predictor`` on the
columns of its own design.  One set of draws therefore serves all models,
deterministically, and the PyMC model and the simulation share one code path.
With the count target "total" (``priors.PHASE3_RECALIBRATED``) the expected
total per stratum-year is the same in every model, which the summaries show.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np

from .modelspace import ModelSpec
from .models import (COUNT_PARAMS, THREE_WAY, StructuredDesign, build_structured_model, count_terms,
                     linear_predictor, per_stratum_sum, structured_design)
from .priors import PHASE3_PROPOSED, PriorSpec
from .tables import CaptureTable

#: Largest Poisson mean drawn (numpy's limit is about 9.2e18); a prior mean above it is an error, not clipped.
MAX_POISSON_MEAN = 1e18


@dataclass(frozen=True)
class PriorDraws:
    params: Mapping[str, np.ndarray]     # count-part draws and theta for every capture column of the richest model
    columns: tuple[str, ...]             # capture columns of the richest model
    draws: int
    seed: int
    priors: PriorSpec


def richest(lists: Sequence[str], covariates: Sequence[str]) -> ModelSpec:
    return ModelSpec(tuple(lists), frozenset(itertools.combinations(tuple(lists), 2)), tuple(covariates))


def draw_prior(table: CaptureTable, lists: Sequence[str], covariates: Sequence[str], *, draws: int, seed: int,
               priors: PriorSpec = PHASE3_PROPOSED, periods: Mapping[str, tuple[int, int]] | None = None,
               exposure: np.ndarray | None = None, three_way: bool = True) -> PriorDraws:
    """Draw the prior of the richest model once (seeded)."""
    import pymc as pm

    # The centred form: the prior is the same in both forms, and this one keeps the seeded draws that the
    # analysis plan's figures were rendered from (fits use the non-centred default, decision 77).
    sm = build_structured_model(table, richest(lists, covariates), priors, periods=periods, exposure=exposure,
                                three_way=three_way, noncentred=False)
    names = list(COUNT_PARAMS) + ([THREE_WAY] if three_way else []) + ["theta_capture"]
    vals = pm.draw([sm.model[n] for n in names], draws=draws, random_seed=seed)
    return PriorDraws(dict(zip(names, (np.asarray(v) for v in vals))), sm.design.capture_columns, draws, seed, priors)


@dataclass(frozen=True)
class Simulation:
    """Prior predictive draws for one model, each of shape (draws, strata)."""

    completeness: np.ndarray     # expected completeness: expected recorded / expected total
    hidden: np.ndarray           # expected people on no list
    expected_total: np.ndarray   # expected people, recorded or not
    N: np.ndarray                # simulated people, N ~ Poisson(expected total)

    @property
    def completeness_total(self) -> np.ndarray:
        """Expected recorded / expected people over every stratum-year, per draw."""
        return 1.0 - self.hidden.sum(axis=1) / self.expected_total.sum(axis=1)

    @property
    def N_total(self) -> np.ndarray:
        return self.N.sum(axis=1)


def _params_for(prior: PriorDraws, design: StructuredDesign) -> dict:
    try:
        idx = [prior.columns.index(c) for c in design.capture_columns]
    except ValueError as e:
        raise ValueError("the model has a capture column the prior draws lack") from e
    p = {k: v for k, v in prior.params.items() if k != "theta_capture"}
    p["theta_capture"] = prior.params["theta_capture"][:, idx]
    return p


def simulate(prior: PriorDraws, design: StructuredDesign, rng: np.random.Generator) -> Simulation:
    """The prior predictive of one model, from the shared draws."""
    if design.target != prior.priors.count_target:
        raise ValueError("the design and the prior draws model different count targets")
    mu = np.exp(linear_predictor(_params_for(prior, design), design))     # (draws, cells)
    hidden = mu[:, design.hidden]                                        # (draws, strata)
    total = per_stratum_sum(mu[:, ~design.hidden], design) + hidden
    if total.max() > MAX_POISSON_MEAN:
        raise OverflowError("a prior mean exceeds the Poisson limit")
    return Simulation(1.0 - hidden / total, hidden, total, rng.poisson(total))


def year_changes(prior: PriorDraws, design: StructuredDesign) -> tuple[np.ndarray, np.ndarray]:
    """Year-to-year change, as a fraction, of the common year effect alone and of each stratum-year's expected count.

    The expected count is the one the count part models: the hidden count
    (target "hidden") or the expected total, person-years included (target
    "total").  The random walk smooths only gamma_t, shared by every stratum;
    the sex x year, age band x year and sex x age band x year deviations are
    independent from one year to the next.  Both arrays pool draws and pairs
    of consecutive years (and strata, for the second).
    """
    c = count_terms(_params_for(prior, design), design)                # (draws, strata)
    if design.target == "total":
        c = c + design.log_exposure
    i_t = design.index["year"]
    key = list(zip(design.index["sex"], design.index["age_band"]))
    order = np.lexsort((i_t, [k[1] for k in key], [k[0] for k in key]))
    T = len(design.levels["year"])
    by = c[:, order].reshape(c.shape[0], -1, T)                          # (draws, sex x age, years)
    stratum = np.expm1(np.abs(np.diff(by, axis=-1))).ravel()
    common = np.expm1(np.abs(np.diff(prior.params["gamma"], axis=-1))).ravel()
    return common, stratum


@dataclass(frozen=True)
class ModelSummary:
    spec: ModelSpec
    completeness: tuple[float, float, float]       # 2.5%, 50%, 97.5% over draws and stratum-years
    completeness_total: tuple[float, float, float]
    hidden: tuple[float, float, float]
    expected_total: tuple[float, float, float]
    N: tuple[float, float, float]
    N_total: tuple[float, float, float]
    below_half: float                              # share of stratum-years with expected completeness < 1/2
    total_vs_first: float                          # largest |expected total / the first model's - 1|, draw by draw


def _q(x: np.ndarray, level: float) -> tuple[float, float, float]:
    a = (1 - level) / 2
    lo, med, hi = np.quantile(np.asarray(x, float).ravel(), [a, 0.5, 1 - a])
    return float(lo), float(med), float(hi)


def summarize_space(table: CaptureTable, specs: Sequence[ModelSpec], *, draws: int, seed: int, level: float = 0.95,
                    priors: PriorSpec = PHASE3_PROPOSED, periods: Mapping[str, tuple[int, int]] | None = None,
                    exposure: np.ndarray | None = None, three_way: bool = True,
                    prior: PriorDraws | None = None) -> list[ModelSummary]:
    """Prior predictive summaries for every model in ``specs`` (same draws for all, seeded).

    Every model's Poisson draws of N use the same random stream (common random
    numbers), so models that share their expected totals, as all do under the
    recalibrated set, also share their simulated N exactly.
    """
    specs = list(specs)
    lists = specs[0].lists
    covs = tuple(dict.fromkeys(c for s in specs for c in s.list_covariates))
    if prior is None:
        prior = draw_prior(table, lists, covs, draws=draws, seed=seed, priors=priors, periods=periods,
                           exposure=exposure, three_way=three_way)
    out, first = [], None
    for spec in specs:
        d = structured_design(table, spec, periods=periods, target=priors.count_target, exposure=exposure)
        sim = simulate(prior, d, np.random.default_rng([seed, 0]))
        first = sim.expected_total if first is None else first
        out.append(ModelSummary(spec, _q(sim.completeness, level), _q(sim.completeness_total, level),
                                _q(sim.hidden, level), _q(sim.expected_total, level), _q(sim.N, level),
                                _q(sim.N_total, level), float(np.mean(sim.completeness < 0.5)),
                                float(np.max(np.abs(sim.expected_total / first - 1.0)))))
    return out
