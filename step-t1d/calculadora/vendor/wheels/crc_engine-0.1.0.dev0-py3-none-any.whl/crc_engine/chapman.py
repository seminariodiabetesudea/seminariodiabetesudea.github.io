"""Two-list estimators.

Chapman's (1951) nearly unbiased form of the Lincoln-Petersen estimator, its
variance (Seber 1970), and Chao's (1987) log-normal interval, which is bounded
below by the number of people actually observed (audit item T2: a Wald
interval N +/- 1.96 SE can fall below that count).

Two lists cannot test their own independence; callers must say so.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import norm


@dataclass(frozen=True)
class ChapmanResult:
    n1: int
    n2: int
    m: int
    N: float
    var: float
    lower: float
    upper: float

    @property
    def observed(self) -> int:
        return self.n1 + self.n2 - self.m

    @property
    def se(self) -> float:
        return float(np.sqrt(self.var))


def chapman(n1: int, n2: int, m: int, level: float = 0.95) -> ChapmanResult:
    """Chapman estimate with Chao's log-normal interval.

    n1, n2 : people on list 1 and list 2; m : people on both.
    """
    if min(n1, n2, m) < 0 or m > min(n1, n2):
        raise ValueError("need 0 <= m <= min(n1, n2)")
    N = (n1 + 1) * (n2 + 1) / (m + 1) - 1
    var = (n1 + 1) * (n2 + 1) * (n1 - m) * (n2 - m) / ((m + 1) ** 2 * (m + 2))
    n = n1 + n2 - m
    f0 = N - n
    if f0 <= 0 or var <= 0:
        return ChapmanResult(n1, n2, m, N, var, float(n), float(n))
    z = norm.ppf(0.5 + level / 2)
    C = np.exp(z * np.sqrt(np.log1p(var / f0**2)))
    return ChapmanResult(n1, n2, m, float(N), float(var), n + f0 / C, n + f0 * C)


def wald_interval(N: float, se: float, level: float = 0.95) -> tuple[float, float]:
    """The symmetric Wald interval the old calculator used (for comparison only)."""
    z = norm.ppf(0.5 + level / 2)
    return (N - z * se, N + z * se)
