"""One model, one repeat, fitted the analysis plan's way (Phase 5 refit; analysis plan, "Inference for each model").

``fit_model`` runs the plan's procedure for one model on one table:

1. Build the model with ``models.build_structured_model``, in the non-centred form it uses on every attempt
   (decision 77, J26).
2. NUTS with ``diagnostics.DEFAULT_SAMPLER``.  A run with divergent transitions is run again at each
   ``diagnostics.RETRY_TARGET_ACCEPT`` value in turn (0.95, then 0.99); the last run of this ladder is the
   attempt's result.
3. ``diagnostics.check_gates`` on that run, with the draws of N from ``models.posterior_N`` and every free
   random variable.  If the gates fail, a second attempt runs the same ladder with the draws and the tuning
   steps multiplied by ``diagnostics.SECOND_ATTEMPT_SCALE`` (``diagnostics.MAX_FIT_ATTEMPTS`` attempts in all).
   A fit that fails on its last attempt leaves the model average, and its reasons are kept.
4. On the final attempt's draws: bridge sampling, which sets the weights, and importance sampling, its second
   opinion (``marginal``; decision 78); and the Freeman-Tukey posterior predictive check of the observed cells.
   ``ppc.ppc_freeman_tukey_means`` takes the cell means of any model, so it serves the structured models as is.
   An AM2 model (decision 122) has NB1 counts: its replicates, like the hidden counts behind N, are NB1 with each
   draw's dispersion kappa.

Seeds (J14): ``fit_seed`` derives one integer per model, repeat and stage from the run's root seed through numpy's
``SeedSequence``; inside a fit every random step (each NUTS run of the ladder, the draws of N, the two proposals,
the predictive check) draws its own child stream of that integer.  So any single fit can be repeated alone with
``fit_model(..., seed=fit_seed(root, model_index, repeat, stage))``.  Bit for bit, that holds once PyTensor's
compile cache holds the model's functions: fits repeated in fresh processes from a warm cache agreed in every
draw (whatever ``PYTHONHASHSEED``), while a run that compiled them first (a cold cache, two processes compiling
the same model at once) gave other draws from the same seeds.

The sampler is injectable (``sample_fn``) so the attempt logic can be tested without NUTS.
"""

from __future__ import annotations

import importlib.util
import math
import time
from dataclasses import asdict, dataclass, field
from typing import Callable, Mapping

import numpy as np

from . import ppc
from .diagnostics import (DEFAULT_SAMPLER, MAX_FIT_ATTEMPTS, RETRY_TARGET_ACCEPT, SECOND_ATTEMPT_SCALE, GateResult,
                          Gates, check_gates)
from .marginal import bridge_log_marginal_likelihood, importance_log_marginal_likelihood
from .models import (StructuredModel, build_structured_model, cell_means, nb1_kappa_draws, parameter_draws,
                     posterior_N)
from .modelspace import ModelSpec
from .priors import PHASE3_PROPOSED, PriorSpec
from .tables import CaptureTable

#: Stages of a fit: the main run, and the J15 refit with twice the draws.
STAGE_MAIN, STAGE_J15 = 0, 1
#: Errors an evidence estimate may raise on a poor sample; they are recorded, never hidden (anything else is a bug).
EVIDENCE_ERRORS = (ValueError, FloatingPointError, RuntimeError, np.linalg.LinAlgError)


def default_nuts_sampler() -> str:
    """'nutpie' where it is installed, otherwise PyMC's own NUTS (the plan: "NUTS in PyMC (nutpie where available)")."""
    return "nutpie" if importlib.util.find_spec("nutpie") is not None else "pymc"


# =========================================================================== seeds (J14)
def fit_seed(root_seed: int, model_index: int, repeat: int, stage: int = STAGE_MAIN) -> int:
    """The seed of one fit: the child (model_index, repeat, stage) of the run's root ``SeedSequence``.

    ``model_index`` is the model's position in ``models.structured_space()``, so a run over a subset of the
    models gives each of them the seed it has in the full run.
    """
    ss = np.random.SeedSequence(int(root_seed), spawn_key=(0, int(model_index), int(repeat), int(stage)))
    return int(ss.generate_state(1)[0])


def _child(ss: np.random.SeedSequence, *key: int) -> np.random.SeedSequence:
    """A named child stream of ``ss`` (the same as spawning, without depending on how many were spawned before)."""
    return np.random.SeedSequence(ss.entropy, spawn_key=tuple(ss.spawn_key) + tuple(int(k) for k in key))


def _int_seed(ss: np.random.SeedSequence) -> int:
    return int(ss.generate_state(1)[0])


# =========================================================================== settings
@dataclass(frozen=True)
class SamplerSettings:
    """NUTS settings and the attempt rules; the defaults are the plan's (``diagnostics``)."""

    chains: int = DEFAULT_SAMPLER["chains"]
    draws: int = DEFAULT_SAMPLER["draws"]
    tune: int = DEFAULT_SAMPLER["tune"]
    target_accept: float = DEFAULT_SAMPLER["target_accept"]
    retry_target_accept: tuple[float, ...] = RETRY_TARGET_ACCEPT
    max_attempts: int = MAX_FIT_ATTEMPTS
    second_attempt_scale: int = SECOND_ATTEMPT_SCALE
    nuts_sampler: str = field(default_factory=default_nuts_sampler)
    cores: int = 1                      # chains run in parallel; an execution detail, not part of a fit's identity

    def __post_init__(self):
        if self.chains < 2:
            raise ValueError("the gates need at least two chains (R-hat)")
        if self.draws < 4 or self.tune < 0 or self.max_attempts < 1 or self.second_attempt_scale < 1:
            raise ValueError("draws >= 4, tune >= 0, max_attempts >= 1 and second_attempt_scale >= 1")
        if self.nuts_sampler not in ("pymc", "nutpie"):
            raise ValueError("nuts_sampler is 'pymc' or 'nutpie'")
        object.__setattr__(self, "retry_target_accept", tuple(float(t) for t in self.retry_target_accept))

    def ladder(self) -> tuple[float, ...]:
        """target_accept of the runs within one attempt: the base value, then each higher retry value in turn."""
        return (float(self.target_accept),) + tuple(t for t in self.retry_target_accept if t > self.target_accept)

    def for_attempt(self, attempt: int) -> tuple[int, int]:
        """(draws, tune) of attempt 1, 2, ...: each attempt after the first multiplies both by the scale."""
        f = self.second_attempt_scale ** (attempt - 1)
        return self.draws * f, self.tune * f

    def with_draws_factor(self, factor: int) -> "SamplerSettings":
        """The same settings with ``factor`` times the draws (J15: the draws doubled, tuning unchanged)."""
        from dataclasses import replace

        return replace(self, draws=self.draws * int(factor))

    def as_dict(self, *, identity_only: bool = False) -> dict:
        d = asdict(self)
        d["retry_target_accept"] = list(self.retry_target_accept)
        if identity_only:
            d.pop("cores")
        return d


#: (model, *, draws, tune, chains, target_accept, cores, random_seed, nuts_sampler) -> DataTree with posterior and
#: sample_stats groups.
SampleFn = Callable[..., object]


def nuts(model, *, draws: int, tune: int, chains: int, target_accept: float, cores: int, random_seed: int,
         nuts_sampler: str):
    """``pm.sample`` with the given settings, quietly; returns the DataTree."""
    import warnings

    import pymc as pm

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return pm.sample(draws=draws, tune=tune, chains=chains, cores=cores, target_accept=target_accept,
                         random_seed=random_seed, progressbar=False, compute_convergence_checks=False,
                         nuts_sampler=nuts_sampler, model=model)


def divergences(idata) -> int | None:
    """Divergent transitions in a fit, or None when the sampler did not record them."""
    if "sample_stats" not in idata.children or "diverging" not in idata["sample_stats"]:
        return None
    return int(np.asarray(idata["sample_stats"]["diverging"].values).sum())


# =========================================================================== attempts
@dataclass(frozen=True)
class Attempt:
    """One NUTS run: attempt 1 or 2, one rung of the target_accept ladder."""

    attempt: int
    target_accept: float
    chains: int
    draws: int
    tune: int
    divergences: int | None
    seed: int
    seconds: float


@dataclass
class Sampled:
    """The final NUTS run of a fit, after the ladder and the attempts, with its gate result."""

    idata: object
    runs: list[Attempt]
    gates: GateResult
    N: np.ndarray                 # (chains, draws)
    hidden: np.ndarray            # (chains, draws, strata)

    @property
    def passed(self) -> bool:
        return self.gates.passed


def sample_attempts(sm: StructuredModel, sampler: SamplerSettings, *, seed_nuts: np.random.SeedSequence,
                    seed_N: np.random.SeedSequence, gates: Gates = Gates(),
                    sample_fn: SampleFn | None = None) -> Sampled:
    """NUTS with the retry ladder, gates after each attempt, at most ``sampler.max_attempts`` attempts.

    A run is repeated at the next target_accept when its divergent transitions exceed ``gates.max_divergences``
    (none, under the plan's gates).  Each run's seed is the child (attempt, rung) of ``seed_nuts``; the draws of
    N after attempt a use the child (a,) of ``seed_N``.
    """
    sample_fn = sample_fn or nuts
    free = [rv.name for rv in sm.model.free_RVs]
    runs: list[Attempt] = []
    for a in range(1, sampler.max_attempts + 1):
        draws, tune = sampler.for_attempt(a)
        for k, ta in enumerate(sampler.ladder()):
            s = _int_seed(_child(seed_nuts, a, k))
            t0 = time.perf_counter()
            idata = sample_fn(sm.model, draws=draws, tune=tune, chains=sampler.chains, target_accept=ta,
                              cores=sampler.cores, random_seed=s, nuts_sampler=sampler.nuts_sampler)
            div = divergences(idata)
            runs.append(Attempt(a, ta, sampler.chains, draws, tune, div, s, time.perf_counter() - t0))
            if div is None or div <= gates.max_divergences:
                break
        hidden, N = posterior_N(sm, idata, np.random.default_rng(_child(seed_N, a)))
        g = check_gates(idata, N_draws=N, gates=gates, var_names=free)
        if g.passed:
            break
    return Sampled(idata, runs, g, np.asarray(N), np.asarray(hidden))


# =========================================================================== evidence and checks
def bridge_estimate(model, idata, seed: np.random.SeedSequence) -> dict:
    """Bridge sampling (the weights), as plain data; an estimator error is recorded with log_ml NaN."""
    t0 = time.perf_counter()
    try:
        b = bridge_log_marginal_likelihood(model, idata, random_seed=_int_seed(seed))
        out = {"log_ml": b.log_ml, "cv": b.cv, "converged": b.converged, "iterations": b.iterations,
               "n_posterior": b.n_posterior, "n_proposal": b.n_proposal, "n_eff": b.n_eff, "dim": b.dim,
               "n_nonfinite": b.n_nonfinite, "error": None}
    except EVIDENCE_ERRORS as e:
        out = {"log_ml": math.nan, "cv": math.nan, "converged": False, "error": f"{type(e).__name__}: {e}"}
    out["seconds"] = time.perf_counter() - t0
    return out


def importance_estimate(model, idata, seed: np.random.SeedSequence, draws: int | None = None) -> dict:
    """Importance sampling (the second opinion), as plain data; an estimator error is recorded with log_ml NaN."""
    t0 = time.perf_counter()
    try:
        r = importance_log_marginal_likelihood(model, idata, random_seed=_int_seed(seed), draws=draws)
        out = {"log_ml": r.log_ml, "log_ml_raw": r.log_ml_raw, "se": r.se, "khat": r.khat, "khat_max": r.khat_max,
               "reliable": r.reliable, "ess": r.ess, "draws": r.draws, "dim": r.dim, "n_nonfinite": r.n_nonfinite,
               "error": None}
    except EVIDENCE_ERRORS as e:
        out = {"log_ml": math.nan, "se": math.nan, "khat": math.nan, "reliable": False,
               "error": f"{type(e).__name__}: {e}"}
    out["seconds"] = time.perf_counter() - t0
    return out


def margin_groups(d, periods: Mapping[str, tuple[int, int]] | None) -> tuple[np.ndarray, list[str]]:
    """Each stratum's group for the margins check, period x age band, and the groups' labels.  Without periods
    the years form one period ("all years")."""
    years = [d.levels["year"][i] for i in d.index["year"]]
    plabels = list(periods) if periods else ["all years"]

    def period_of(y) -> int:
        if not periods:
            return 0
        for k, (lo, hi) in enumerate(periods.values()):
            if lo <= int(y) <= hi:
                return k
        raise ValueError(f"year {y} falls in no period")

    ages = list(d.levels["age_band"])
    groups = np.array([period_of(y) * len(ages) + a for y, a in zip(years, d.index["age_band"])])
    return groups, [f"{p} | {a}" for p in plabels for a in ages]


def posterior_check(sm: StructuredModel, idata, rng: np.random.Generator,
                    periods: Mapping[str, tuple[int, int]] | None = None) -> dict:
    """The plan's fit checks: the Freeman-Tukey posterior predictive check of the observed cells
    (``ppc.ppc_freeman_tukey_means``), which sets the flag (J13), and the list totals and pairwise overlaps by period
    and age band (``ppc.ppc_margins``), reported beside it with their p-values (decision 86).  An AM2 model's
    replicates are NB1 with each draw's kappa (``models.nb1_kappa_draws``; decision 122)."""
    t0 = time.perf_counter()
    d = sm.design
    mu = cell_means(parameter_draws(idata, sm), d)[:, ~d.hidden]
    kappa = nb1_kappa_draws(idata, sm)                  # None for Poisson counts
    r = ppc.ppc_freeman_tukey_means(d.y_obs, mu, rng, kappa_draws=kappa)
    W, stats = ppc.margin_weights(len(d.spec.lists))
    groups, glabels = margin_groups(d, periods)
    m = ppc.ppc_margins(d.y_obs, mu, W, groups, len(glabels), rng, kappa_draws=kappa)
    rows = [{"group": g, "statistic": st, "observed": float(m["T_obs"][i, j]),
             "replicated_mean": float(m["T_rep_mean"][i, j]), "p_value": float(m["p_value"][i, j]),
             "extreme": bool(m["extreme"][i, j])} for i, g in enumerate(glabels) for j, st in enumerate(stats)]
    return {"statistic": "Freeman-Tukey", "cells": int(mu.shape[1]), "p_value": r.p_value, "flagged": r.flagged,
            "flag_low": ppc.FLAG_LOW, "flag_high": ppc.FLAG_HIGH, "T_obs_mean": float(np.mean(r.T_obs)),
            "T_rep_mean": float(np.mean(r.T_rep)),
            "margins": {"statistics": len(rows), "extreme": int(sum(x["extreme"] for x in rows)),
                        "expected_extreme_by_chance": len(rows) * (ppc.FLAG_LOW + 1 - ppc.FLAG_HIGH), "rows": rows},
            "seconds": time.perf_counter() - t0}


def with_draws_of_N(idata, N: np.ndarray, hidden: np.ndarray):
    """The fit's DataTree with the draws of N and of the hidden count per stratum added to its posterior."""
    import xarray as xr

    post = idata["posterior"].to_dataset()
    post["N"] = xr.DataArray(np.asarray(N), dims=("chain", "draw"))
    post["hidden"] = xr.DataArray(np.asarray(hidden), dims=("chain", "draw", "stratum"))
    out = idata.copy()
    out["posterior"] = post
    return out


# =========================================================================== one fit
def _finite_or_none(x):
    if isinstance(x, (float, np.floating)):
        return float(x) if math.isfinite(float(x)) else None
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, dict):
        return {k: _finite_or_none(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_finite_or_none(v) for v in x]
    return x


@dataclass
class FitResult:
    """Everything one fit produced.  ``summary()`` is the JSON-safe part; the draws stay arrays."""

    spec_name: str
    repeat: int
    seed: int
    stage: int
    priors_name: str
    sampler: SamplerSettings
    attempts: list[Attempt]            # every NUTS run, in order (attempt, rung)
    gates: GateResult                  # of the final attempt
    left_average: bool                 # failed the gates on the last attempt
    leave_reasons: list[str]
    bridge: dict                       # log_ml, cv, converged, ... (error when the estimator failed)
    importance: dict                   # log_ml, se, khat, reliable, ...
    ppc: dict                          # Freeman-Tukey p-value and flag
    N_draws: np.ndarray                # (chains, draws) of the final attempt
    hidden_draws: np.ndarray           # (chains, draws, strata)
    n_observed: int
    timings: dict
    idata: object | None = field(default=None, repr=False)   # the final attempt, with N and hidden added

    @property
    def passed(self) -> bool:
        return self.gates.passed

    @property
    def bridge_log_ml(self) -> float:
        return float(self.bridge["log_ml"])

    @property
    def importance_log_ml(self) -> float:
        return float(self.importance["log_ml"])

    def N_summary(self, level: float = 0.95) -> dict:
        a = (1.0 - level) / 2.0
        n = np.asarray(self.N_draws, float).ravel()
        lo, med, hi = np.quantile(n, [a, 0.5, 1.0 - a])
        return {"median": float(med), "lower": float(lo), "upper": float(hi), "level": level, "draws": int(n.size)}

    def summary(self) -> dict:
        """JSON-safe description of the fit (no draws; non-finite numbers become null)."""
        final = self.attempts[-1]
        return _finite_or_none({
            "model": self.spec_name, "repeat": self.repeat, "stage": self.stage, "seed": self.seed,
            "priors": self.priors_name, "sampler": self.sampler.as_dict(),
            "attempts": [asdict(a) for a in self.attempts], "n_attempts": max(a.attempt for a in self.attempts),
            "final": {"target_accept": final.target_accept, "draws": final.draws, "tune": final.tune,
                      "chains": final.chains, "divergences": final.divergences},
            "gates": {"passed": self.gates.passed, "failures": list(self.gates.failures),
                      "metrics": {k: (v if isinstance(v, (str, type(None))) else float(v))
                                  for k, v in self.gates.metrics.items()}},
            "left_average": self.left_average, "leave_reasons": list(self.leave_reasons),
            "bridge": dict(self.bridge), "importance": dict(self.importance), "ppc": dict(self.ppc),
            "n_observed": self.n_observed, "N": self.N_summary(), "timings": dict(self.timings),
        })


def fit_model(table: CaptureTable, spec: ModelSpec, priors: PriorSpec = PHASE3_PROPOSED, *, seed: int,
              repeat: int = 0, stage: int = STAGE_MAIN, periods: Mapping[str, tuple[int, int]] | None = None,
              exposure: np.ndarray | None = None, sampler: SamplerSettings | None = None, gates: Gates = Gates(),
              importance_draws: int | None = None, sample_fn: SampleFn | None = None,
              keep_idata: bool = True) -> FitResult:
    """Fit ``spec`` on ``table`` the plan's way (module docstring) and return a ``FitResult``.

    ``seed`` is the fit's own integer (``fit_seed``).  ``exposure`` (person-years per stratum) is used by the
    recalibrated priors only.  ``importance_draws`` defaults to ``BMA_SETTINGS.importance_draws``.  The J15 refit
    passes ``sampler.with_draws_factor(2)`` and ``stage=STAGE_J15``.
    """
    t_all = time.perf_counter()
    sampler = sampler or SamplerSettings()
    ss = np.random.SeedSequence(int(seed))
    s_nuts, s_N, s_bridge, s_imp, s_ppc = ss.spawn(5)
    t0 = time.perf_counter()
    sm = build_structured_model(table, spec, priors, periods=periods,
                                exposure=exposure if priors.count_target == "total" else None)
    t_build = time.perf_counter() - t0
    t0 = time.perf_counter()
    sampled = sample_attempts(sm, sampler, seed_nuts=s_nuts, seed_N=s_N, gates=gates, sample_fn=sample_fn)
    t_sample = time.perf_counter() - t0
    bridge = bridge_estimate(sm.model, sampled.idata, s_bridge)
    importance = importance_estimate(sm.model, sampled.idata, s_imp, importance_draws)
    check = posterior_check(sm, sampled.idata, np.random.default_rng(s_ppc), periods=periods)
    timings = {"build": t_build, "sampling_and_gates": t_sample, "nuts_runs": sum(a.seconds for a in sampled.runs),
               "bridge": bridge["seconds"], "importance": importance["seconds"], "ppc": check["seconds"]}
    timings["total"] = time.perf_counter() - t_all
    return FitResult(spec_name=spec.name, repeat=int(repeat), seed=int(seed), stage=int(stage),
                     priors_name=priors.name, sampler=sampler, attempts=list(sampled.runs), gates=sampled.gates,
                     left_average=not sampled.passed,
                     leave_reasons=[] if sampled.passed else list(sampled.gates.failures),
                     bridge=bridge, importance=importance, ppc=check, N_draws=sampled.N,
                     hidden_draws=sampled.hidden, n_observed=int(sm.design.n_observed), timings=timings,
                     idata=with_draws_of_N(sampled.idata, sampled.N, sampled.hidden) if keep_idata else None)
