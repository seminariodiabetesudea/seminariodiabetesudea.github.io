"""PyMC log-linear capture-recapture models built from a ModelSpec.

Two builders:

* ``build_model`` is the Phase 1 builder (audit): every design block gets an
  independent Normal prior from a PriorSpec.
* ``build_structured_model`` is the Phase 3 builder of the analysis plan
  (``docs/analysis-plan.md``): the capture part comes from
  ``modelspace.design_matrix`` and the count part is structured, for stratum
  s = sex x age band and year t,

      c[s, t] = alpha + delta[sex] + eta[age] + gamma[t] + (delta eta)[sex, age]
                + (delta gamma)[sex, t] + (eta gamma)[age, t] + (delta eta gamma)[sex, age, t]

  with a centred random walk for gamma (J9), the sex x year and age band x
  year terms partially pooled with one scale tau, and the sex x age band x year
  term pooled with its own scale tau3 (J24), so every stratum-year total is
  partially pooled.  Sum-to-zero effects (count part and list x covariate
  terms) get exchangeable zero-sum Normal priors whose every level has the
  standard deviation the priors state (J23).

  With ``PHASE3_PROPOSED`` (count target "hidden") c[s, t] is alpha[s, t],
  the log hidden count.  With ``PHASE3_RECALIBRATED`` (target "total") c[s, t]
  plus log person-years is the log expected total, and the hidden cell gets
  alpha[s, t] = log total - log F(theta), F = 1 / (1 - expected completeness),
  so the prior on N is the same in every model.

``linear_predictor`` computes log mu for every cell from a parameter dict.  It
runs unchanged on pytensor tensors (inside the PyMC model) and on numpy draws
with a leading draws axis (prior predictive simulation, posterior checks), so
the model and the simulations cannot drift apart.  Sensitivity S9 is applied
after the fit (``s9_hidden``), never by fitting the A:B:C term.

**An extra stratum variable** (sensitivity runs S13 and S19, J19 and J30;
decision 110).  When the table has one stratum variable x besides sex, age
band, year (and period), it enters the count part with the interactions of sex
and age band: a main effect xi[x] and the interactions (delta xi)[sex, x] and
(eta xi)[age, x] (the count-effects prior), the pooled x x year term
(xi gamma)[x, t] (scale tau), and the pooled higher-order terms
(delta eta xi)[sex, age, x], (delta xi gamma)[sex, x, t], (eta xi gamma)[age, x, t]
and (delta eta xi gamma)[sex, age, x, t] (scale tau3, present with the three-way
term), so every stratum-year total stays partially pooled.  A list x x term
comes from the spec's list covariates, as for any other stratum variable.  A
table without such a variable builds exactly the model above.

**An amended model** (decision 122; ``crc_engine.amendments``).  A spec with
``amendment="AM1"`` gains a partially pooled list x year term in its capture
part.  ``modelspace.design_matrix`` adds the list x year columns in effects
coding, and their coefficients are the deviations u[l, y] (the deterministic
``list_x_year``): u[l, years of g] = sigma_l sqrt(n / (n - 1)) z[l, g], with
z[l, g] ~ ZeroSumNormal(1) over the n years of group g (``list_x_year_z``) and
sigma_l ~ HalfNormal(0.75) per list (``list_x_year_sigma``).  The groups are the
periods when the model has list x period, otherwise all the years
(``am1_year_groups``).  The term enters ``theta_capture``, so ``capture_part``,
``log_F``, the hidden cell, ``parameter_draws``, ``cell_means``,
``simulate_counts`` and the hidden means behind ``posterior_N`` all carry it.

A spec with ``amendment="AM2"`` keeps the design and the cell means, and its
observed counts are NB1(mu, kappa) instead of Poisson(mu): the negative binomial
with size mu / kappa, mean mu and variance mu (1 + kappa) (``nb1_parameters``),
with one dispersion kappa ~ HalfNormal(1) for the whole table (``nb1_kappa``).
The hidden count behind ``posterior_N`` is NB1 with each draw's kappa, and so
are the replicates of the predictive checks (``nb1_kappa_draws``,
``fit.posterior_check``) and, given kappa, the counts of ``simulate_counts``.

A model without an amendment builds exactly the model above.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace
from typing import Mapping, Sequence

import numpy as np
import pandas as pd

from . import bma
from .amendments import AM1, AM1_BLOCK, AM1_EFFECTS, AM1_SIGMA, AM1_Z, AM2, AM2_KAPPA
from .modelspace import Design, ModelSpec, design_matrix, model_space
from .priors import PHASE3_PROPOSED, Normal, PriorSpec
from .tables import CaptureTable


def _block_prior(block: str, spec: ModelSpec, priors: PriorSpec) -> Normal:
    if block == "count":
        return priors.count_intercept if spec.count_part == "saturated" else priors.count_effects
    if block == "capture":
        return priors.list_effects
    if block == "pairs":
        return priors.pairs
    if block == "kway":
        if priors.kway is None:
            raise ValueError("the K-way term needs an explicit proper prior (sensitivity S9)")
        return priors.kway
    if block.startswith("list×"):
        return priors.list_covariates
    raise KeyError(block)


def build_model(table: CaptureTable, spec: ModelSpec, priors: PriorSpec = PHASE3_PROPOSED):
    """Return (pymc.Model, Design) for ``spec`` on ``table`` (Phase 1 form)."""
    import pymc as pm
    import pytensor.tensor as pt

    if spec.amendment is not None:
        raise ValueError(f"the Phase 1 builder takes no amendment ({spec.amendment}); use build_structured_model")
    d = design_matrix(spec, table)
    Xo = d.X_obs
    with pm.Model() as model:
        parts = []
        for block, sl in d.blocks.items():
            size = sl.stop - sl.start
            pr = _block_prior(block, spec, priors)
            mu = np.full(size, pr.mu)
            if block == "count" and spec.count_part != "saturated":
                mu[0] = priors.count_intercept.mu          # the intercept
                sig = np.full(size, priors.count_effects.sigma)
                sig[0] = priors.count_intercept.sigma
            else:
                sig = np.full(size, pr.sigma)
            if block == "pairs" and priors.legacy_halfcauchy_pairs:
                s = pm.HalfCauchy("pairs_scale", beta=1.0)
                parts.append(pm.Normal(block, mu=0.0, sigma=s, shape=size))
            else:
                parts.append(pm.Normal(block.replace("×", "_x_"), mu=mu, sigma=sig, shape=size))
        theta = pt.concatenate(parts)
        pm.Poisson("y", mu=pt.exp(pt.dot(Xo, theta)), observed=d.y_obs.astype(int))
        pm.Deterministic("theta", theta)
    return model, d


def theta_draws(idata) -> np.ndarray:
    """Posterior draws of the stacked coefficient vector, shape (chains, draws, P)."""
    return np.asarray(idata["posterior"]["theta"].values)


# =========================================================================== Phase 3
#: Stratum variables of the structured count part, in the plan's order.
COUNT_VARS = ("sex", "age_band", "year")
#: Count-part parameters, as named in the PyMC model, the prior draws and ``linear_predictor``.
COUNT_PARAMS = ("alpha", "delta_sex", "eta_age", "delta_eta", "gamma", "delta_gamma", "eta_gamma")
THREE_WAY = "delta_eta_gamma"
#: Stratum variables that are not an extra stratum variable (``period`` derives from ``year``).
BASE_STRATA = COUNT_VARS + ("period",)
#: Count-part terms of an extra stratum variable x: (name, the stratum axes it spans, its prior kind).
#: "fixed": zero-sum Normal with the count-effects SD; "tau": pooled with the stratum-year scale; "tau3": pooled
#: with the three-way scale (present only with the three-way term).
EXTRA_TERMS = (
    ("xi", ("x",), "fixed"),
    ("delta_xi", ("sex", "x"), "fixed"),
    ("eta_xi", ("age_band", "x"), "fixed"),
    ("xi_gamma", ("x", "year"), "tau"),
    ("delta_eta_xi", ("sex", "age_band", "x"), "tau3"),
    ("delta_xi_gamma", ("sex", "x", "year"), "tau3"),
    ("eta_xi_gamma", ("age_band", "x", "year"), "tau3"),
    ("delta_eta_xi_gamma", ("sex", "age_band", "x", "year"), "tau3"),
)
EXTRA_PARAMS = tuple(t[0] for t in EXTRA_TERMS)


def extra_stratum(table: CaptureTable) -> str | None:
    """The table's extra stratum variable (any besides sex, age band, year and period), or None; at most one."""
    extra = [v for v in table.strata_vars if v not in BASE_STRATA]
    if len(extra) > 1:
        raise ValueError(f"the structured count part takes at most one extra stratum variable; got {extra}")
    return extra[0] if extra else None


def zero_sum_sigma(levels: Sequence[int], sd: float) -> float:
    """The ZeroSumNormal ``sigma`` that gives every cell the marginal standard deviation ``sd``.

    A zero-sum Normal over axes of sizes L1, L2, ... has cell variance
    sigma^2 (1 - 1/L1)(1 - 1/L2)...; this inverts that factor.
    """
    f = math.prod(1.0 - 1.0 / L for L in levels)
    if f <= 0:
        raise ValueError("every zero-sum axis needs at least two levels")
    return sd / math.sqrt(f)


def zero_sum_contrast_sd(L: int, sd: float) -> float:
    """SD of the difference between two levels of a zero-sum effect whose L levels each have SD ``sd``.

    The levels are negatively correlated (covariance -sd^2 / (L - 1)), so the
    contrast has SD sd * sqrt(2 L / (L - 1)): wider than two independent levels.
    """
    return sd * math.sqrt(2.0 * L / (L - 1.0))


def random_walk(steps, xp=np):
    """Random walk from its steps, starting at zero and centred to sum to zero (J9).

    ``steps`` has the T - 1 steps on its last axis; returns T values.  ``xp`` is
    numpy or pytensor.tensor.
    """
    g = xp.concatenate([steps[..., :1] * 0, xp.cumsum(steps, axis=-1)], axis=-1)
    return g - g.mean(axis=-1, keepdims=True)


def _xp(x):
    if isinstance(x, (np.ndarray, np.generic, float, int)):
        return np
    import pytensor.tensor as pt
    return pt


@dataclass(frozen=True)
class StructuredDesign:
    """Everything a structured model needs from a table, computed once."""

    spec: ModelSpec
    levels: Mapping[str, tuple]           # sex, age_band, year, and each list covariate
    index: Mapping[str, np.ndarray]       # per stratum: level index of sex, age_band, year
    X_capture: np.ndarray                 # (cells, P) capture-part columns, hidden rows all zero
    capture_columns: tuple[str, ...]
    capture_blocks: Mapping[str, slice]
    stratum: np.ndarray                   # (cells,) stratum of each cell
    hidden: np.ndarray                    # (cells,) True for the cell nobody saw
    y: np.ndarray                         # (cells,) counts, NaN in hidden rows
    n_hist: int                           # observable histories per stratum
    target: str = "hidden"                # what the count part models: the hidden count or the expected total
    log_exposure: np.ndarray | None = None   # (strata,) log person-years, for target "total"
    extra: str | None = None              # the extra stratum variable (S13, S19), or None
    year_groups: tuple[tuple[int, ...], ...] | None = None   # AM1: its zero-sum groups of year levels, or None

    @property
    def S(self) -> int:
        return len(self.index["sex"])

    @property
    def y_obs(self) -> np.ndarray:
        return self.y[~self.hidden]

    @property
    def n_observed(self) -> int:
        return int(np.nansum(self.y))


def with_period(table: CaptureTable, periods: Mapping[str, tuple[int, int]], year: str = "year") -> CaptureTable:
    """Add a ``period`` stratum column derived from ``year`` (periods: label -> (first, last) year)."""
    def label(y):
        for p, (lo, hi) in periods.items():
            if lo <= int(y) <= hi:
                return p
        raise ValueError(f"year {y} falls in no period")
    strata = table.strata.copy()
    strata["period"] = [label(y) for y in strata[year]]
    used = set(strata["period"])
    levels = {**table.levels, "period": tuple(p for p in periods if p in used)}
    return CaptureTable(table.lists, strata, table.counts, levels)


def am1_year_groups(table: CaptureTable, by_period: bool) -> tuple[tuple[int, ...], ...]:
    """AM1's zero-sum groups of year levels, as indices into the table's years (decision 122).

    With ``by_period`` (the model has list x period) one group per period, in the table's period order, holding the
    period's years; otherwise one group of all the years.  Every group needs at least two years, and all of them the
    same number (the zero-sum draws form one lists x periods x years-of-a-period array).
    """
    years = tuple(table.levels["year"])
    if by_period:
        period_of = dict(zip(table.strata["year"], table.strata["period"]))
        groups = tuple(tuple(t for t, y in enumerate(years) if period_of[y] == p) for p in table.levels["period"])
    else:
        groups = (tuple(range(len(years))),)
    sizes = sorted({len(g) for g in groups})
    if sizes[0] < 2:
        raise ValueError("AM1's deviations sum to zero over the years of each period (over all the years without "
                         "list x period), so each period needs at least two years")
    if len(sizes) > 1:
        raise ValueError(f"AM1 with list x period needs periods with the same number of years; they have {sizes}")
    return groups


def structured_design(table: CaptureTable, spec: ModelSpec, *,
                      periods: Mapping[str, tuple[int, int]] | None = None, target: str = "hidden",
                      exposure: np.ndarray | None = None) -> StructuredDesign:
    """The capture design of ``spec`` (from ``modelspace``) plus the count-part indices.

    ``target`` "total" needs ``exposure``: person-years per stratum, in the
    table's row order (the pipeline takes them from the DANE population).
    """
    missing = [v for v in COUNT_VARS if v not in table.strata_vars]
    if missing:
        raise KeyError(f"the structured count part needs stratum variables {missing}")
    extra = extra_stratum(table)
    strata_vars = COUNT_VARS + ((extra,) if extra else ())
    keys = list(table.strata[list(strata_vars)].itertuples(index=False, name=None))
    if len(set(keys)) != len(keys):
        raise ValueError("each sex x age band x year stratum must appear once" if extra is None else
                         f"each sex x age band x year x {extra} stratum must appear once")
    if spec.count_part != "saturated" or spec.count_terms:
        raise ValueError("the structured builder replaces the count part; pass a spec with the default count part")
    if target not in ("hidden", "total"):
        raise ValueError("target must be 'hidden' or 'total'")
    log_exposure = None
    if target == "total":
        e = None if exposure is None else np.asarray(exposure, float)
        if e is None or e.shape != (table.S,) or not np.all(e > 0):
            raise ValueError("target 'total' needs positive person-years for every stratum, in the table's order")
        log_exposure = np.log(e)
    tab = table
    if "period" in spec.list_covariates and "period" not in table.strata_vars:
        if periods is None:
            raise ValueError("list x period needs the periods (label -> first and last year)")
        tab = with_period(table, periods)
    d: Design = design_matrix(replace(spec, count_part="intercept"), tab)
    cols = [i for i, c in enumerate(d.columns) if c != "count:intercept"]
    blocks, start = {}, 0
    for b, sl in d.blocks.items():
        if b == "count":
            continue
        n = sl.stop - sl.start
        blocks[b] = slice(start, start + n)
        start += n
    levels = {v: tuple(tab.levels[v]) for v in strata_vars + tuple(spec.list_covariates)}
    if extra is not None and len(levels[extra]) < 2:
        raise ValueError(f"the extra stratum variable {extra!r} needs at least two levels")
    index = {v: np.array([levels[v].index(x) for x in tab.strata[v]]) for v in strata_vars}
    groups = am1_year_groups(tab, "period" in spec.list_covariates) if spec.amendment == AM1.id else None
    return StructuredDesign(spec, levels, index, d.X[:, cols], tuple(d.columns[i] for i in cols), blocks,
                            d.stratum, d.hidden, d.y, 2 ** table.K - 1, target, log_exposure, extra, groups)


def _extra_axes(d: StructuredDesign, axes: Sequence[str]) -> tuple[str, ...]:
    """The design's stratum variable names for an ``EXTRA_TERMS`` axis tuple ("x" is the extra variable)."""
    return tuple(d.extra if a == "x" else a for a in axes)


def count_terms(p: Mapping, d: StructuredDesign):
    """Sum of the count-part terms per stratum: the log hidden count (target "hidden") or the log
    expected total less log person-years (target "total").  numpy draws (leading axis) or pytensor."""
    i_s, i_a, i_t = d.index["sex"], d.index["age_band"], d.index["year"]
    a = (p["alpha"][..., None] + p["delta_sex"][..., i_s] + p["eta_age"][..., i_a] + p["gamma"][..., i_t]
         + p["delta_eta"][..., i_s, i_a] + p["delta_gamma"][..., i_s, i_t] + p["eta_gamma"][..., i_a, i_t])
    if p.get(THREE_WAY) is not None:
        a = a + p[THREE_WAY][..., i_s, i_a, i_t]
    if d.extra is not None:
        for name, axes, _ in EXTRA_TERMS:
            if p.get(name) is not None:
                a = a + p[name][(...,) + tuple(d.index[v] for v in _extra_axes(d, axes))]
    return a


def capture_part(p: Mapping, d: StructuredDesign):
    """The capture part of log mu for every cell; zero in the hidden cells."""
    return p["theta_capture"] @ d.X_capture.T


def _stratum_cells(x, d: StructuredDesign, n: int):
    if x.ndim == 1:
        return x.reshape((d.S, n))
    return x.reshape((x.shape[0], d.S, n))


def log_F(cap, d: StructuredDesign):
    """log F per stratum, F = sum over a stratum's cells of exp(capture part) = 1 / (1 - expected completeness)."""
    xp = _xp(cap)
    c = _stratum_cells(cap, d, d.n_hist + 1)
    m = c.max(axis=-1, keepdims=True)
    return (m + xp.log(xp.exp(c - m).sum(axis=-1, keepdims=True)))[..., 0]


def hidden_log_mean(p: Mapping, d: StructuredDesign, cap=None):
    """alpha[s, t], the log of the hidden cell's expected count.

    Target "hidden": the count-part terms themselves.  Target "total":
    log person-years + count-part terms - log F(theta), so the count part is
    the log expected total and the prior on N is the same in every model.
    """
    a = count_terms(p, d)
    if d.target == "total":
        cap = capture_part(p, d) if cap is None else cap
        a = a + d.log_exposure - log_F(cap, d)
    return a


def linear_predictor(p: Mapping, d: StructuredDesign):
    """log mu for every cell (hidden cells included)."""
    cap = capture_part(p, d)
    return hidden_log_mean(p, d, cap)[..., d.stratum] + cap


def per_stratum_sum(x, d: StructuredDesign):
    """Sum observed-cell values within each stratum (cells are stratum-major)."""
    return _stratum_cells(x, d, d.n_hist).sum(axis=-1)


@dataclass
class StructuredModel:
    model: object                 # pymc.Model
    design: StructuredDesign
    priors: PriorSpec
    noncentred: bool
    three_way: bool
    log_mu: object                # pytensor tensor, every cell (not stored in traces)

    @property
    def spec(self) -> ModelSpec:
        return self.design.spec


def _am1_deviations(d: StructuredDesign):
    """AM1's deviations u (lists x years), built inside the open PyMC model (decision 122).

    u[l, years of g] = sigma_l sqrt(n / (n - 1)) z[l, g], with z[l, g] ~ ZeroSumNormal(1) over the n years of group g
    (``d.year_groups``) and sigma_l ~ ``AM1.prior``.  A zero-sum draw over n levels has variance 1 - 1/n, so given
    sigma_l every u[l, y] has standard deviation sigma_l.
    """
    import pymc as pm

    groups = d.year_groups
    n = len(groups[0])
    scale = pm.HalfNormal(AM1_SIGMA, AM1.prior.sigma, dims="list") * math.sqrt(n / (n - 1.0))
    if len(groups) == 1:
        u = scale[:, None] * pm.ZeroSumNormal(AM1_Z, sigma=1.0, dims=("list", "year"))
    else:
        z = pm.ZeroSumNormal(AM1_Z, sigma=1.0, dims=("list", "period", "year_in_period"))
        flat = (scale[:, None, None] * z).reshape((len(d.spec.lists), len(groups) * n))
        u = flat[:, np.argsort(np.concatenate(groups))]               # back to the years' order
    return pm.Deterministic(AM1_EFFECTS, u, dims=("list", "year"))


#: log of the smallest normal float64: NB1's size mu / kappa is floored there (``nb1_parameters``).
_LOG_TINY = math.log(np.finfo(float).tiny)


def nb1_parameters(mu, kappa) -> dict:
    """PyMC's ``NegativeBinomial`` parameters of NB1(mu, kappa), AM2's count distribution (decision 122): the mean mu
    and the size alpha = mu / kappa.  PyMC's negative binomial has variance mu + mu^2 / alpha, so NB1's is
    mu (1 + kappa), and its log density keeps every constant.  numpy or pytensor.

    alpha is computed in logs, exp(log mu - log kappa), and floored at the smallest normal float (2.2e-308).  So it
    is mu / kappa wherever that is a normal float, and it never underflows to zero at the extreme parameter values an
    importance proposal's tails reach.  There PyMC's check alpha > 0 would raise in a log density compiled without
    PyMC's rewrites (``marginal.batched_log_density``), where PyMC's own compiler gives -inf; with the floor the
    density there is finite and vanishingly small.
    """
    xp = _xp(mu)
    return {"mu": mu, "alpha": xp.exp(xp.maximum(xp.log(mu) - xp.log(kappa), _LOG_TINY))}


def build_structured_model(table: CaptureTable, spec: ModelSpec, priors: PriorSpec = PHASE3_PROPOSED, *,
                           periods: Mapping[str, tuple[int, int]] | None = None,
                           exposure: np.ndarray | None = None, noncentred: bool = True, three_way: bool = True,
                           design: StructuredDesign | None = None) -> StructuredModel:
    """The Phase 3 PyMC model of ``spec`` on ``table``.

    ``table`` has stratum variables sex, age_band and year (one row per
    stratum-year); list x period terms derive the period from the year with
    ``periods``.  ``priors.count_target`` "total" (``PHASE3_RECALIBRATED``)
    needs ``exposure``, the person-years per stratum.  ``noncentred`` (the
    default, used on every attempt; decision 77) writes the random walk and
    the pooled sex x year and age band x year terms as a scale times standard
    draws; ``noncentred=False`` gives the centred form, the same prior.  The
    sex x age band x year term is in by default (``three_way``), with its own
    scale and always non-centred.

    Deterministics: ``hidden_mu`` (expected hidden count), ``expected_total``
    and ``expected_completeness`` per stratum.  ``expected_completeness`` is
    the expected number recorded divided by the expected total, a function of
    the parameters; the published completeness is registered / N per draw
    (``summaries.completeness``).

    A spec with ``amendment="AM1"`` adds the partially pooled list x year term
    (module docstring; decision 122): free variables ``list_x_year_sigma`` and
    ``list_x_year_z``, deterministic ``list_x_year``.  A spec with
    ``amendment="AM2"`` makes the observed counts ``y`` NB1 (``nb1_parameters``),
    with the free dispersion ``nb1_kappa``, the last free variable.
    """
    import pymc as pm
    import pytensor.tensor as pt

    if spec.kway:
        raise ValueError("the A:B:C term is not fitted: sensitivity S9 is applied after the fit "
                         "(posterior_N(..., s9_sd=...)), because in the all-pairs models the term is aliased "
                         "with the hidden cell and its posterior would be set by every prior on that direction")
    if priors.year_rw_scale is None or priors.stratum_year_scale is None:
        raise ValueError("the structured count part needs year_rw_scale and stratum_year_scale (PHASE3_PROPOSED)")
    if three_way and priors.three_way_scale is None:
        raise ValueError("the sex x age band x year term needs three_way_scale")
    for eff in (priors.sex, priors.age, priors.sex_age):
        if eff.mu != 0:
            raise ValueError("zero-sum effects are centred on zero")
    d = design or structured_design(table, spec, periods=periods, target=priors.count_target, exposure=exposure)
    if d.target != priors.count_target:
        raise ValueError(f"the design models the {d.target!r} count, the priors the {priors.count_target!r} one")
    lv = d.levels
    if d.extra is not None and priors.count_effects.mu != 0:
        raise ValueError("zero-sum effects are centred on zero")
    Ls, La, T = len(lv["sex"]), len(lv["age_band"]), len(lv["year"])
    if T < 2:
        raise ValueError("the year random walk needs at least two years")
    coords = {"sex": lv["sex"], "age_band": lv["age_band"], "year": lv["year"], "year_step": lv["year"][1:],
              "list": spec.lists, "capture_column": d.capture_columns, "stratum": np.arange(d.S)}
    for c in spec.list_covariates:
        coords[c] = lv[c]
    if d.extra is not None:
        coords[d.extra] = lv[d.extra]
    if "pairs" in d.capture_blocks:
        coords["pair"] = [c.split(":", 1)[1] for c in d.capture_columns[d.capture_blocks["pairs"]]]
    if d.year_groups is not None and len(d.year_groups) > 1:         # AM1 with list x period: z per period
        coords["year_in_period"] = tuple(range(1, len(d.year_groups[0]) + 1))
    with pm.Model(coords=coords) as model:
        alpha = pm.Normal("alpha", priors.count_intercept.mu, priors.count_intercept.sigma)
        delta = pm.ZeroSumNormal("delta_sex", sigma=zero_sum_sigma([Ls], priors.sex.sigma), dims="sex")
        eta = pm.ZeroSumNormal("eta_age", sigma=zero_sum_sigma([La], priors.age.sigma), dims="age_band")
        delta_eta = pm.ZeroSumNormal("delta_eta", sigma=zero_sum_sigma([Ls, La], priors.sex_age.sigma),
                                     n_zerosum_axes=2, dims=("sex", "age_band"))
        sigma = pm.HalfNormal("gamma_sigma", priors.year_rw_scale.sigma)
        if noncentred:
            steps = sigma * pm.Normal("gamma_z", 0.0, 1.0, dims="year_step")
        else:
            steps = pm.Normal("gamma_steps", 0.0, sigma, dims="year_step")
        gamma = pm.Deterministic("gamma", random_walk(steps, pt), dims="year")
        tau = pm.HalfNormal("tau", priors.stratum_year_scale.sigma)

        def pooled(name: str, dims: tuple[str, ...], scale, noncentred_form: bool):
            f = zero_sum_sigma([len(coords[x]) for x in dims], 1.0)
            if noncentred_form:
                z = pm.ZeroSumNormal(name + "_z", sigma=f, n_zerosum_axes=len(dims), dims=dims)
                return pm.Deterministic(name, scale * z, dims=dims)
            return pm.ZeroSumNormal(name, sigma=scale * f, n_zerosum_axes=len(dims), dims=dims)

        params = {"alpha": alpha, "delta_sex": delta, "eta_age": eta, "delta_eta": delta_eta, "gamma": gamma,
                  "delta_gamma": pooled("delta_gamma", ("sex", "year"), tau, noncentred),
                  "eta_gamma": pooled("eta_gamma", ("age_band", "year"), tau, noncentred)}
        if three_way:
            tau3 = pm.HalfNormal("tau3", priors.three_way_scale.sigma)
            params[THREE_WAY] = pooled(THREE_WAY, ("sex", "age_band", "year"), tau3, True)
        if d.extra is not None:
            for name, axes, kind in EXTRA_TERMS:
                dims = _extra_axes(d, axes)
                if kind == "fixed":
                    params[name] = pm.ZeroSumNormal(
                        name, sigma=zero_sum_sigma([len(coords[x]) for x in dims], priors.count_effects.sigma),
                        n_zerosum_axes=len(dims), dims=dims)
                elif kind == "tau":
                    params[name] = pooled(name, dims, tau, noncentred)
                elif three_way:
                    params[name] = pooled(name, dims, tau3, True)

        parts = []
        for block in d.capture_blocks:
            if block == "capture":
                parts.append(pm.Normal("beta", priors.list_effects.mu, priors.list_effects.sigma, dims="list"))
            elif block.startswith("list×"):
                c = block[len("list×"):]
                L = len(lv[c])
                z = pm.ZeroSumNormal(f"list_x_{c}", sigma=zero_sum_sigma([L], priors.list_covariates.sigma),
                                     dims=("list", c))
                parts.append(z[:, : L - 1].flatten())   # effects coding: the last level is minus the sum
            elif block == "pairs":
                parts.append(pm.Normal("lambda", priors.pairs.mu, priors.pairs.sigma, dims="pair"))
            elif block == AM1_BLOCK:
                parts.append(_am1_deviations(d)[:, : T - 1].flatten())   # effects coding, as for list x covariate
            else:
                raise KeyError(block)
        params["theta_capture"] = pm.Deterministic("theta_capture", pt.concatenate(parts), dims="capture_column")

        log_mu = linear_predictor(params, d)
        mu_obs = pt.exp(log_mu[~d.hidden])
        if spec.amendment == AM2.id:         # AM2 (decision 122): NB1 counts, one dispersion for the whole table
            kappa = pm.HalfNormal(AM2_KAPPA, AM2.prior.sigma)
            pm.NegativeBinomial("y", **nb1_parameters(mu_obs, kappa), observed=np.nan_to_num(d.y_obs).astype(int))
        else:
            pm.Poisson("y", mu=mu_obs, observed=np.nan_to_num(d.y_obs).astype(int))
        hidden_mu = pm.Deterministic("hidden_mu", pt.exp(log_mu[d.hidden]), dims="stratum")
        obs_mu = per_stratum_sum(mu_obs, d)
        pm.Deterministic("expected_total", obs_mu + hidden_mu, dims="stratum")
        pm.Deterministic("expected_completeness", obs_mu / (obs_mu + hidden_mu), dims="stratum")
    return StructuredModel(model, d, priors, noncentred, three_way, log_mu)


#: Names of the count part's free random variables (centred and non-centred forms); scales excluded.
COUNT_FREE = ("alpha", "delta_sex", "eta_age", "delta_eta", "gamma_steps", "gamma_z", "delta_gamma", "delta_gamma_z",
              "eta_gamma", "eta_gamma_z", THREE_WAY, THREE_WAY + "_z") + tuple(
                  n for p in EXTRA_PARAMS for n in (p, p + "_z"))


def count_part_parameters(sm: StructuredModel) -> int:
    """Free parameters of the count part (its scales aside), counted from the model's value variables."""
    point = sm.model.initial_point()
    return int(sum(point[sm.model.rvs_to_values[rv].name].size for rv in sm.model.free_RVs if rv.name in COUNT_FREE))


def structured_space(lists: Sequence[str] = ("A", "B", "C"), covariates: Sequence[str] = ("age_band", "period", "sex"),
                     *, penalty: float | None = None) -> list[tuple[ModelSpec, float]]:
    """The plan's model space with each model's prior probability (uniform, or S2's penalty)."""
    specs = model_space(tuple(lists), tuple(covariates))
    return list(zip(specs, bma.model_prior(specs, penalty).tolist()))


def parameter_draws(source, sm_or_design) -> dict[str, np.ndarray]:
    """Count-part and capture draws as a dict with one leading draws axis.

    ``source`` is a fitted DataTree / InferenceData (its posterior group) or a
    dict of arrays already shaped (draws, ...).
    """
    d = sm_or_design.design if isinstance(sm_or_design, StructuredModel) else sm_or_design
    names = COUNT_PARAMS + ("theta_capture", THREE_WAY) + (EXTRA_PARAMS if d.extra is not None else ())
    fitted = hasattr(source, "children") and "posterior" in source.children     # a DataTree from pm.sample
    if not fitted and isinstance(source, Mapping):
        out = {k: np.asarray(source[k]) for k in names if k in source}
    else:
        post = source["posterior"]
        have = set(post.data_vars)
        out = {}
        for k in names:
            if k in have:
                a = np.asarray(post[k].values)
                out[k] = a.reshape((-1,) + a.shape[2:])
    if out["theta_capture"].shape[-1] != len(d.capture_columns):
        raise ValueError("the capture draws do not match the design's columns")
    return out


def nb1_kappa_draws(source, sm_or_design) -> np.ndarray | None:
    """The draws of an AM2 model's dispersion kappa (decision 122), one per draw of ``parameter_draws`` and in its
    order; None for a model whose counts are Poisson.  ``source`` as for ``parameter_draws``."""
    d = sm_or_design.design if isinstance(sm_or_design, StructuredModel) else sm_or_design
    if d.spec.amendment != AM2.id:
        return None
    fitted = hasattr(source, "children") and "posterior" in source.children     # a DataTree from pm.sample
    if not fitted and isinstance(source, Mapping):
        return np.asarray(source[AM2_KAPPA], float)
    return np.asarray(source["posterior"][AM2_KAPPA].values, float).reshape(-1)


def cell_means(params: Mapping, d: StructuredDesign) -> np.ndarray:
    """Expected count of every cell per draw, shape (draws, cells)."""
    return np.exp(linear_predictor(params, d))


def has_all_pairs(spec: ModelSpec) -> bool:
    return len(spec.pairs) == len(spec.lists) * (len(spec.lists) - 1) // 2


def s9_hidden(hidden_mu: np.ndarray, sd: float, rng: np.random.Generator) -> np.ndarray:
    """Sensitivity S9, applied after the fit: each draw's hidden means times exp(-kappa), kappa ~ Normal(0, sd).

    In a model with every pairwise term, shifting alpha by +c, every beta by -c,
    every lambda by +c and the A:B:C term by -c leaves every observed cell
    unchanged and multiplies the hidden cell by e^c: the data cannot see the
    A:B:C term.  Fitting it would let every prior on that direction set its
    posterior; instead its Normal(0, sd) prior is applied directly, one kappa
    per draw, independent of the posterior.  Observed cells, the fit and the
    model weights are unchanged.  ``hidden_mu`` has the strata on its last axis.
    """
    h = np.asarray(hidden_mu, float)
    kappa = rng.normal(0.0, sd, size=h.shape[:-1] + (1,))
    return h * np.exp(-kappa)


def posterior_N(sm: StructuredModel, idata, rng: np.random.Generator, *,
                s9_sd: float | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Hidden counts M ~ Poisson(hidden mean) per draw and N = n + sum M.

    With ``s9_sd`` (all-pairs models only) the hidden means are first scaled
    by ``s9_hidden``.  An AM2 model (decision 122) draws M ~ NB1(hidden mean,
    kappa) instead, with each draw's kappa.  Returns M of shape (chains, draws,
    strata) and N of shape (chains, draws), ready for
    ``diagnostics.check_gates(idata, N_draws=N)``.
    """
    from .ppc import nb1_draws, poisson_draws

    hidden = np.asarray(idata["posterior"]["hidden_mu"].values)
    if s9_sd is not None:
        if not has_all_pairs(sm.spec):
            raise ValueError("S9 applies to the models with every pairwise term")
        hidden = s9_hidden(hidden, s9_sd, rng)
    if sm.spec.amendment == AM2.id:
        M = nb1_draws(hidden, np.asarray(idata["posterior"][AM2_KAPPA].values), rng)
    else:
        M = poisson_draws(hidden, rng)
    return M, sm.design.n_observed + M.sum(axis=-1)


def simulate_counts(params: Mapping, d: StructuredDesign, rng: np.random.Generator, *,
                    kappa: float | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Simulated data from known parameters (one set, no draws axis).

    Returns the observed counts, shape (strata, histories), for
    ``CaptureTable.with_counts``, and the hidden counts per stratum, so that a
    test knows the true N.  Every cell is Poisson; given ``kappa`` (AM2,
    decision 122) every cell, the hidden one included, is NB1(mu, kappa)
    instead, drawn in the same order.
    """
    from .ppc import nb1_draws

    one = {k: np.asarray(v, float)[None, ...] for k, v in params.items() if v is not None}
    mu = cell_means(one, d)[0]
    if kappa is None:
        obs = rng.poisson(mu[~d.hidden]).reshape(d.S, d.n_hist)
        hidden = rng.poisson(mu[d.hidden])
    else:
        obs = nb1_draws(mu[~d.hidden], kappa, rng).reshape(d.S, d.n_hist)
        hidden = nb1_draws(mu[d.hidden], kappa, rng)
    return obs, hidden
