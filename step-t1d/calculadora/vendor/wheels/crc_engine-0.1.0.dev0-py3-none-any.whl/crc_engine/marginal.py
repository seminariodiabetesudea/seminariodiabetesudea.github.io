"""Marginal likelihoods p(y | M) for Bayesian model averaging (analysis plan, "Bayesian model averaging").

The weights rest on **bridge sampling** from each model's NUTS fit, checked by **importance sampling** from the
same fit (decision 78).  SMC is kept as a diagnostic only: Phase 4's check 4 found it 0.37 to 2.14 log units
low on the structured models.

* **Importance sampling** (``importance_log_marginal_likelihood``).  A multivariate t proposal fitted to the
  NUTS draws on the model's unconstrained space, the unnormalised posterior evaluated in batches through
  PyMC's own log density with its Jacobian (``batched_log_density``), and Pareto-smoothed weights (PSIS;
  Vehtari et al. 2024).  The estimate is usable when Pareto k-hat is below ``BMA_SETTINGS.importance_khat_max``.

* **SMC** (``smc_log_marginal_likelihood``; diagnostic).  ``pm.sample_smc`` records
  ``sample_stats.log_marginal_likelihood`` once per tempering stage, NaN until
  the inverse temperature reaches 1.  Each chain's estimate is the *last finite*
  value of its stages, and the chains are combined by log-mean-exp (each chain
  is an unbiased estimate of p(y | M) on the natural scale).  PyMC 6.3.2 stores
  the stages in several shapes, all handled by ``smc_log_ml_from_idata``:

  - ``(chains, stages)``: the usual case (object dtype);
  - ``(chains, 1)``: SMC finished in a single stage;
  - ``(chains,)`` of per-chain sequences: chains that needed different numbers
    of stages (a ragged object array);
  - ``(stages,)`` labelled ``chain``: what PyMC writes for a single chain; it
    is recognised from the posterior group, which then has one chain.

  SMC starts from forward draws of the prior, so its estimate does not depend
  on how PyMC normalises the prior densities.

* **Bridge sampling** (``bridge_log_marginal_likelihood``; Meng & Wong 1996,
  in the form of Gronau et al. 2017 and the R package ``bridgesampling``,
  method "normal").  The posterior draws are mapped to the model's
  unconstrained value variables; the first half of each chain fits a
  multivariate normal proposal, the second halves enter the iterative scheme
  with as many proposal draws, and the unnormalised posterior is
  ``model.compile_logp(jacobian=True)`` on the value variables, so it carries
  the Jacobian of every transform.  It needs every prior density to be
  normalised in those coordinates (PyMC's are, including ``ZeroSumNormal``,
  whose transform is an isometry onto the zero-sum subspace); Phase 4 check 4
  verifies both estimates against references computed outside PyMC.

Both log marginal likelihoods include every constant of the likelihood (for
Poisson cells, the -log y! terms), so they are comparable across models fitted
to the same table and only there.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Iterator, Sequence

import numpy as np
from scipy.special import logsumexp

from .bma import BMA_SETTINGS


#: SMC is not used for the weights (decision 78).  These are the draws the first draft of the plan required,
#: kept for Phase 4's diagnostics: chains, draws per chain, and the chain spread (log units) that doubles them.
SMC_CHAINS, SMC_DRAWS, SMC_CHAIN_SPREAD_MAX = 4, 2000, 0.5


def log_mean_exp(x: Sequence[float]) -> float:
    """log(mean(exp(x))), computed stably."""
    a = np.asarray(x, float).ravel()
    if a.size == 0:
        raise ValueError("log_mean_exp of an empty sequence")
    return float(logsumexp(a) - np.log(a.size))


# =========================================================================== SMC
@dataclass(frozen=True)
class SMCMarginal:
    """SMC estimate of log p(y | M).

    Unpacks as ``log_ml, per_chain = result``.  ``spread`` is the range of the
    per-chain values; the plan doubles the draws when it exceeds
    ``SMC_CHAIN_SPREAD_MAX`` (``too_spread``).
    """

    log_ml: float                  # chains combined by log-mean-exp
    per_chain: np.ndarray          # last finite value of each chain
    stages: np.ndarray             # tempering stages per chain
    idata: object | None = field(default=None, repr=False, compare=False)   # the SMC DataTree, if kept

    def __iter__(self) -> Iterator:
        yield self.log_ml
        yield self.per_chain

    @property
    def spread(self) -> float:
        return float(np.max(self.per_chain) - np.min(self.per_chain))

    def too_spread(self, limit: float = SMC_CHAIN_SPREAD_MAX) -> bool:
        return self.spread > limit


def _last_finite(stages, chain: int) -> tuple[float, int]:
    a = np.asarray(list(np.ravel(np.asarray(stages, dtype=object))), dtype=float)
    ok = np.isfinite(a)
    if not ok.any():
        raise ValueError(f"SMC chain {chain} has no finite log marginal likelihood (it never reached beta = 1)")
    return float(a[np.flatnonzero(ok)[-1]]), int(a.size)


def per_chain_log_ml(values, n_chains: int | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Last finite stage value of every chain, and each chain's number of stages.

    ``values`` is ``sample_stats.log_marginal_likelihood`` as an array (any of
    the shapes in the module docstring).  ``n_chains`` is the number of chains
    actually run (the posterior group's ``chain`` size); it is needed to tell
    one chain's stages from one stage of several chains when the array is 1-D.
    """
    arr = np.asarray(values, dtype=object)
    if arr.ndim == 0:
        rows = [[arr.item()]]
    elif arr.ndim == 1:
        nested = [np.ndim(x) > 0 for x in arr]
        if all(nested):                                     # ragged: one sequence per chain
            rows = list(arr)
        elif any(nested):
            raise ValueError("log_marginal_likelihood mixes sequences and scalars")
        elif n_chains == 1 or n_chains is None:             # PyMC 6.3.2, chains=1: the stages labelled as chains
            rows = [list(arr)]
        elif n_chains == arr.size:                          # one stage per chain, squeezed
            rows = [[x] for x in arr]
        else:
            raise ValueError(f"a 1-D log_marginal_likelihood of length {arr.size} does not match {n_chains} chains")
    elif arr.ndim == 2:
        rows = list(arr)
    else:
        raise ValueError(f"unexpected log_marginal_likelihood shape {arr.shape}")
    if n_chains is not None and len(rows) != n_chains:
        raise ValueError(f"found {len(rows)} chains of SMC stages, the posterior has {n_chains}")
    out = [_last_finite(r, c) for c, r in enumerate(rows)]
    return np.array([v for v, _ in out]), np.array([s for _, s in out], dtype=int)


def smc_log_ml_from_idata(idata) -> SMCMarginal:
    """The SMC estimate from a finished ``pm.sample_smc`` DataTree (or InferenceData)."""
    lml = idata["sample_stats"]["log_marginal_likelihood"]
    n_chains = int(idata["posterior"].sizes["chain"]) if "posterior" in _groups(idata) else None
    per_chain, stages = per_chain_log_ml(lml.values, n_chains)
    return SMCMarginal(log_mean_exp(per_chain), per_chain, stages, idata)


def _groups(idata) -> set[str]:
    if hasattr(idata, "children"):                  # xarray.DataTree
        return set(idata.children)
    return set(getattr(idata, "groups", lambda: [])())


def smc_log_marginal_likelihood(model, *, draws: int = SMC_DRAWS, chains: int = SMC_CHAINS,
                                random_seed=None, cores: int = 1, keep_idata: bool = True,
                                **smc_kwargs) -> SMCMarginal:
    """Run ``pm.sample_smc`` on ``model`` and return its log marginal likelihood.

    Defaults are the first draft's minimum (``SMC_CHAINS`` x ``SMC_DRAWS``);
    a Phase 4 diagnostic, not used for the weights (decision 78).  ``cores`` is passed through (keep it within the machine's
    budget); ``smc_kwargs`` go to ``pm.sample_smc`` (kernel, threshold, ...).
    ``keep_idata=False`` drops the SMC posterior from the result.
    """
    import pymc as pm

    if chains < 1 or draws < 2:
        raise ValueError("SMC needs at least one chain and two draws")
    idata = pm.sample_smc(draws=draws, chains=chains, cores=cores, random_seed=random_seed, model=model,
                          progressbar=smc_kwargs.pop("progressbar", False),
                          compute_convergence_checks=smc_kwargs.pop("compute_convergence_checks", False),
                          **smc_kwargs)
    res = smc_log_ml_from_idata(idata)
    return res if keep_idata else replace(res, idata=None)


# ============================================================ bridge sampling
@dataclass(frozen=True)
class BridgeMarginal:
    """Bridge-sampling estimate of log p(y | M).

    ``cv`` is the coefficient of variation of the estimate of p(y | M) (relative
    mean-squared error of Fruhwirth-Schnatter 2004, as in ``bridgesampling``'s
    ``error_measures``, with each posterior term's autocorrelation entering
    through its effective sample size); for small values it is also the
    approximate standard error of ``log_ml``.  ``float(result)`` is ``log_ml``.
    """

    log_ml: float
    cv: float
    iterations: int
    converged: bool
    n_posterior: int               # posterior draws in the iterative scheme (second half of each chain)
    n_proposal: int                # proposal draws
    n_eff: float                   # median effective sample size of the iterative draws (s1, s2 weights)
    dim: int                       # unconstrained dimension
    n_nonfinite: int               # proposal draws whose log density was not finite (treated as zero density)

    def __float__(self) -> float:
        return self.log_ml


def _value_layout(model) -> list[tuple[str, str, tuple[int, ...]]]:
    """(random variable, value variable, value shape) for every free variable, in the model's order."""
    point = model.initial_point()
    out = []
    for rv in model.free_RVs:
        vname = model.rvs_to_values[rv].name
        out.append((rv.name, vname, tuple(np.shape(point[vname]))))
    return out


def unconstrained_draws(model, idata) -> tuple[np.ndarray, list[tuple[str, str, tuple[int, ...]]]]:
    """Posterior draws of every free variable mapped to the model's unconstrained value space.

    Returns an array of shape (chains, draws, d), the flattened value
    variables in the model's order, and the layout used to flatten them.
    """
    import pytensor

    free = list(model.free_RVs)
    if not free:
        raise ValueError("the model has no free variables")
    for rv in free:
        if not str(rv.dtype).startswith("float"):
            raise ValueError(f"bridge sampling needs continuous parameters; {rv.name} is {rv.dtype}")
    outs = []
    for rv in free:
        tr = model.rvs_to_transforms.get(rv)
        outs.append(rv if tr is None else tr.forward(rv, *rv.owner.inputs))
    fwd = pytensor.function(free, outs, on_unused_input="ignore")
    post = idata["posterior"]
    missing = [rv.name for rv in free if rv.name not in post]
    if missing:
        raise KeyError(f"the posterior has no draws of {missing}")
    C, D = int(post.sizes["chain"]), int(post.sizes["draw"])
    arrays = [np.asarray(post[rv.name].values, dtype=float) for rv in free]
    layout = _value_layout(model)
    sizes = [int(np.prod(s)) for _, _, s in layout]
    flat = np.empty((C, D, sum(sizes)))
    for c in range(C):
        for t in range(D):
            vals = fwd(*[a[c, t] for a in arrays])
            flat[c, t] = np.concatenate([np.ravel(v) for v in vals])
    return flat, layout


def compile_log_density(model):
    """log p(y, theta) on the unconstrained value space, with the Jacobian, as a function of a flat vector."""
    logp = model.compile_logp(jacobian=True)
    layout = _value_layout(model)
    sizes = [int(np.prod(s)) for _, _, s in layout]
    cuts = np.cumsum([0] + sizes)

    def f(x: np.ndarray) -> float:
        point = {v: np.reshape(x[cuts[i]:cuts[i + 1]], s) for i, (_, v, s) in enumerate(layout)}
        return float(logp(point))

    return f


def _ess(x: np.ndarray) -> float:
    """Effective sample size of draws arranged (chains, draws)."""
    from arviz_stats.base import array_stats

    v = float(array_stats.ess(np.asarray(x, float), chain_axis=0, draw_axis=1, method="mean"))
    return v if np.isfinite(v) and v > 0 else float(x.size)


def _rel_var(log_f: np.ndarray) -> float:
    """Var(f) / mean(f)^2 from log f, scale-free."""
    f = np.exp(log_f - np.max(log_f))
    m = f.mean()
    return float(f.var(ddof=1) / m**2)


def bridge_log_marginal_likelihood(model, idata, *, random_seed=None, max_iter: int = 1000, tol: float = 1e-10,
                                   use_neff: bool = True) -> BridgeMarginal:
    """Bridge-sampling estimate of log p(y | M) from posterior draws of ``model`` (e.g. a NUTS fit).

    ``idata`` holds the posterior group of ``pm.sample`` on the same model and
    data.  ``random_seed`` seeds the proposal draws.  ``use_neff`` weights the
    iterative scheme with the effective sample size of the posterior draws, as
    ``bridgesampling`` does by default; any positive weights give a consistent
    estimate, the effective size only makes it efficient.
    """
    draws, layout = unconstrained_draws(model, idata)
    C, D, d = draws.shape
    if D < 4:
        raise ValueError("bridge sampling needs at least four draws per chain")
    half = D // 2
    fit = draws[:, :half].reshape(-1, d)
    it = draws[:, half:]                                   # (C, D - half, d)
    post = it.reshape(-1, d)
    N1 = post.shape[0]
    N2 = N1
    mean = fit.mean(axis=0)
    cov = np.atleast_2d(np.cov(fit, rowvar=False))
    try:
        L = np.linalg.cholesky(cov)
    except np.linalg.LinAlgError as e:
        raise ValueError("the posterior draws have a singular covariance; bridge sampling needs a proper posterior") from e
    rng = np.random.default_rng(random_seed)
    prop = mean + rng.standard_normal((N2, d)) @ L.T
    logdet = 2.0 * np.log(np.diag(L)).sum()

    def log_g(x):
        z = np.linalg.solve(L, (x - mean).T)
        return -0.5 * (d * np.log(2 * np.pi) + logdet + (z**2).sum(axis=0))

    f = compile_log_density(model)
    q11 = np.array([f(x) for x in post])                   # log q at the posterior draws
    q21 = np.array([f(x) for x in prop])                   # log q at the proposal draws
    if not np.all(np.isfinite(q11)):
        raise ValueError("the log density is not finite at some posterior draws")
    bad = ~np.isfinite(q21)
    q21 = np.where(bad, -np.inf, q21)
    q12, q22 = log_g(post), log_g(prop)
    l1, l2 = q11 - q12, q21 - q22

    # bridgesampling's use_neff: the median over parameters of the iterative draws' effective sample size
    neff = float(np.median([_ess(it[:, :, k]) for k in range(d)])) if use_neff else float(N1)
    neff = min(neff, float(N1))
    s1, s2 = neff / (neff + N2), N2 / (neff + N2)
    lstar = float(np.median(l1))
    inv_e2 = np.exp(lstar - l2)                            # 1 / e2; inf where the density is zero
    e1 = np.exp(l1 - lstar)
    r, converged, i = 0.5, False, 0
    for i in range(1, max_iter + 1):
        r_old = r
        with np.errstate(over="ignore"):
            num = np.mean(1.0 / (s1 + s2 * r * inv_e2))     # e2 / (s1 e2 + s2 r), overflow-safe
            den = np.mean(1.0 / (s1 * e1 + s2 * r))
        r = num / den
        if not np.isfinite(r) or r <= 0:
            raise FloatingPointError("the bridge iterative scheme left the positive reals")
        if abs((r - r_old) / r) < tol:
            converged = True
            break
    log_ml = float(np.log(r) + lstar)

    # Fruhwirth-Schnatter (2004) relative mean-squared error, with the optimal-bridge weights of the scheme
    lp_g, lp_p = q21 - log_ml, q11 - log_ml                # normalised posterior at proposal / posterior draws
    log_s1, log_s2 = np.log(s1), np.log(s2)
    with np.errstate(invalid="ignore"):
        log_f1 = lp_g - np.logaddexp(log_s1 + lp_g, log_s2 + q22)          # at the proposal draws
    log_f1 = np.where(bad, -np.inf, log_f1)
    log_f2 = q12 - np.logaddexp(log_s1 + lp_p, log_s2 + q12)               # at the posterior draws
    f2 = np.exp(log_f2 - log_f2.max()).reshape(C, D - half)
    re2 = _rel_var(log_f1) / N2 + _rel_var(log_f2) / _ess(f2)
    return BridgeMarginal(log_ml, float(np.sqrt(re2)), i, converged, N1, N2, float(neff), d, int(bad.sum()))


# ================================================== importance sampling (second opinion)
@dataclass(frozen=True)
class ImportanceMarginal:
    """Importance-sampling estimate of log p(y | M) with a proposal fitted to a model's posterior draws.

    ``log_ml`` uses Pareto-smoothed weights (PSIS), ``log_ml_raw`` the raw ones.  ``se`` is the standard
    error of ``log_ml_raw`` from the raw weights; it understates the error when ``khat`` exceeds 0.5.
    ``khat`` is the Pareto k-hat of the weights' right tail; the estimate is ``reliable`` when it is below
    ``khat_max`` (``BMA_SETTINGS.importance_khat_max``).  ``float(result)`` is ``log_ml``.
    """

    log_ml: float
    log_ml_raw: float
    se: float
    khat: float
    ess: float                     # effective sample size of the raw weights
    draws: int
    dim: int
    n_nonfinite: int               # proposal draws whose log density was not finite (zero weight)
    khat_max: float

    @property
    def reliable(self) -> bool:
        return bool(np.isfinite(self.khat) and self.khat < self.khat_max)

    def __float__(self) -> float:
        return self.log_ml


def batched_log_density(model):
    """log p(y, theta) on the unconstrained value space, with the Jacobian, for a batch of flat vectors.

    The model's own log density, vectorised over a leading batch axis (``vectorize_graph``) and compiled
    once; it equals ``compile_log_density`` row by row.  Returns a function of an array (B, d).
    """
    import pytensor
    import pytensor.tensor as pt
    from pytensor.graph.replace import vectorize_graph

    layout = _value_layout(model)
    sizes = [int(np.prod(s)) for _, _, s in layout]
    cuts = np.cumsum([0] + sizes)
    X = pt.matrix("X")
    replace = {model.rvs_to_values[rv]: X[:, cuts[i]:cuts[i + 1]].reshape((X.shape[0],) + tuple(layout[i][2]))
               for i, rv in enumerate(model.free_RVs)}
    fn = pytensor.function([X], vectorize_graph(model.logp(jacobian=True), replace=replace))

    def f(x: np.ndarray) -> np.ndarray:
        return np.asarray(fn(np.atleast_2d(np.asarray(x, dtype=pytensor.config.floatX))), float)

    return f


def psis_log_mean_weight(log_w: np.ndarray) -> tuple[float, float]:
    """log of the mean importance weight with Pareto-smoothed weights, and the Pareto k-hat.

    ``arviz_stats``' ``psislw`` takes log-likelihood values, as in leave-one-out cross-validation, and smooths
    the weights exp(-value), so it is given -log w.  It returns every smoothed log weight normalised to sum to
    one, while the weights below the smoothed tail keep their raw values up to that normalisation: so
    log w - (its output) is, at any of them, the log of the smoothed weights' sum.  It is read at the median
    weight and checked at the lower quartile, both far from the smoothed tail and from the extreme low weights
    of proposal draws deep in the t's tails, whose large magnitudes would cost precision.  Weights whose log is
    not finite count as zero.
    """
    from arviz_stats.base import array_stats

    lw = np.asarray(log_w, float).ravel()
    finite = np.isfinite(lw)
    if finite.sum() < 10:
        raise ValueError("too few finite importance weights")
    x = lw[finite]
    smoothed, k = array_stats.psislw(-x, r_eff=1)
    order = np.argsort(x)
    log_sum = [float(x[i] - smoothed[i]) for i in (order[len(order) // 2], order[len(order) // 4])]
    if not np.isclose(log_sum[0], log_sum[1], rtol=0.0, atol=1e-6):
        raise RuntimeError("psislw changed weights below the tail; the normalising constant cannot be recovered")
    return log_sum[0] - np.log(lw.size), float(np.asarray(k))


def importance_log_marginal_likelihood(model, idata, *, draws: int | None = None, df: float | None = None,
                                       scale: float | None = None, random_seed=None, batch: int = 20_000,
                                       log_density=None) -> ImportanceMarginal:
    """Importance-sampling estimate of log p(y | M) from the posterior draws of ``model`` (e.g. a NUTS fit).

    The proposal is a multivariate t with ``df`` degrees of freedom, centred at the draws' mean on the
    model's unconstrained value space, with their covariance times ``scale`` squared, so that its tails are
    heavier than the posterior's.  Fresh proposal draws are weighted by the model's log density with its
    Jacobian (``batched_log_density``, or ``log_density`` if given), and the weights are Pareto-smoothed.
    Defaults come from ``BMA_SETTINGS``; ``random_seed`` seeds the proposal.
    """
    from scipy.special import gammaln

    S = BMA_SETTINGS
    draws = S.importance_draws if draws is None else int(draws)
    df = S.importance_df if df is None else float(df)
    scale = S.importance_scale if scale is None else float(scale)
    post, _ = unconstrained_draws(model, idata)
    x = post.reshape(-1, post.shape[-1])
    d = x.shape[1]
    mean = x.mean(axis=0)
    try:
        L = np.linalg.cholesky(np.atleast_2d(np.cov(x, rowvar=False))) * scale
    except np.linalg.LinAlgError as e:
        raise ValueError("the posterior draws have a singular covariance; importance sampling needs a proper "
                         "posterior") from e
    const = gammaln((df + d) / 2) - gammaln(df / 2) - 0.5 * d * np.log(df * np.pi) - np.log(np.diag(L)).sum()
    f = log_density or batched_log_density(model)
    rng = np.random.default_rng(random_seed)
    lw = np.empty(draws)
    for start in range(0, draws, batch):
        m = min(batch, draws - start)
        z = rng.standard_normal((m, d))
        u = df / rng.chisquare(df, m)                       # the t's mixing variable
        xs = mean + (z @ L.T) * np.sqrt(u)[:, None]
        log_g = const - 0.5 * (df + d) * np.log1p((z**2).sum(axis=1) * u / df)
        lq = f(xs)
        lw[start:start + m] = np.where(np.isfinite(lq), lq, -np.inf) - log_g
    finite = np.isfinite(lw)
    top = float(lw[finite].max())
    w = np.where(finite, np.exp(lw - top), 0.0)
    log_raw = top + float(np.log(w.mean()))
    se = float(np.sqrt(w.var() / draws) / w.mean())
    ess = float(w.sum() ** 2 / (w**2).sum())
    log_psis, khat = psis_log_mean_weight(lw)
    return ImportanceMarginal(float(log_psis), log_raw, se, khat, ess, draws, d, int((~finite).sum()),
                              S.importance_khat_max)
