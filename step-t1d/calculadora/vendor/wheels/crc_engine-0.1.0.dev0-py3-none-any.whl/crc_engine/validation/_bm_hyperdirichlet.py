"""Decomposable graphical models with hyper-Dirichlet priors (Madigan & York), exactly and in PyMC.

Helper of ``benchmark`` (Phase 4, check 5).

A decomposable graphical model for K lists is a chordal graph on the lists.  Its maximal cliques C_1, ..., C_m,
taken in a perfect order, factorise the cell probabilities of the full 2^K table (hidden cell included):

    theta_h = prod_i P(h[C_i minus S_i] | h[S_i]),    S_i = C_i intersected with (C_1 u ... u C_(i-1))

with S_i empty when C_i starts a new connected component.  As a log-linear model it holds every interaction
inside a clique and nothing else, so it is a crc_engine ``ModelSpec`` (``GraphicalModel.spec``): the pairs are
the edges, and a clique of all K lists adds the K-way term.

The hyper-Dirichlet prior (Dawid & Lauritzen) puts a Dirichlet on the first clique's table and, independently for
every configuration of each separator, a Dirichlet on the next clique's conditional table, with that clique's own
parameters.  Two conventions for the parameters:

* ``"consistent"`` (Madigan & York's, TR 234 Table 2 and p. 13): the maximal model has Dirichlet(delta, ...,
  delta) on the 2^K cells and every model uses the margins of that table of parameters, so a clique of c lists has
  delta * 2^(K - c) per cell and every model carries the same prior information about each list.
* ``"per_clique"``: every clique cell has delta.  With delta = 1 (a uniform Dirichlet on every clique) it is the
  reading of "Smith's priors" that reproduces the report's Tables 7 and 8.

Given N the cells are multinomial(N, theta).  With N ~ Poisson(lambda) they are independent Poisson(lambda theta_h),
and with lambda ~ Gamma(a, scale b) N is negative binomial, Madigan & York's informative prior (their eq. 3).  So
the PyMC model below (``build_pymc_model``) is their model exactly: a Gamma prior on lambda, Dirichlet priors on
the clique tables, Poisson likelihoods for the observed cells.  Its marginal likelihood equals their P(D | M = m),
constants included, and the hidden cell is Poisson(lambda theta_0) given the parameters.

The prior is conjugate, so P(D | N, m) has a closed form (``log_evidence_given_N``): the multinomial coefficient
times a Dirichlet-multinomial term for each clique table.  Summing over N gives the exact posterior
(``exact_posterior``), with no Monte Carlo error.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Sequence

import numpy as np
from scipy import stats
from scipy.special import gammaln, logsumexp

from ..modelspace import ModelSpec
from ..tables import histories

CONVENTIONS = ("consistent", "per_clique")


# =========================================================================== graphs
def config_index(H: np.ndarray, cols: Sequence[int]) -> np.ndarray:
    """Index of each row's configuration on the columns ``cols`` (the first column most significant)."""
    cols = list(cols)
    if not cols:
        return np.zeros(H.shape[0], dtype=int)
    w = 2 ** np.arange(len(cols) - 1, -1, -1)
    return (np.asarray(H)[:, cols] @ w).astype(int)


def _maximal_cliques(lists: tuple[str, ...], edges: frozenset) -> list[tuple[str, ...]]:
    cliques = []
    for k in range(len(lists), 0, -1):
        for sub in itertools.combinations(lists, k):
            if all(p in edges for p in itertools.combinations(sub, 2)) and not any(set(sub) < set(c) for c in cliques):
                cliques.append(sub)
    return cliques


def _clique_key(lists: tuple[str, ...], clique: tuple[str, ...]):
    return (-len(clique), [lists.index(v) for v in clique])


def _perfect_order(lists, cliques):
    """Cliques in an order with the running intersection property, and their separators; None if there is none."""
    start = sorted(cliques, key=lambda c: _clique_key(lists, c))
    for order in itertools.permutations(start):
        seps, seen, ok = [], set(), True
        for i, c in enumerate(order):
            s = set(c) & seen
            if i and not any(s <= set(prev) for prev in order[:i]):
                ok = False
                break
            seps.append(tuple(v for v in c if v in s))
            seen |= set(c)
        if ok:
            return tuple(order), tuple(seps)
    return None


@dataclass(frozen=True)
class GraphicalModel:
    """A decomposable graphical model: its cliques in a perfect order and their separators."""

    lists: tuple[str, ...]
    edges: frozenset
    cliques: tuple[tuple[str, ...], ...]
    separators: tuple[tuple[str, ...], ...]

    @property
    def K(self) -> int:
        return len(self.lists)

    @property
    def label(self) -> str:
        """Madigan & York's notation: the cliques, largest first, e.g. [DR][B] or [BD][DR]."""
        return "".join("[" + "".join(c) + "]" for c in sorted(self.cliques, key=lambda c: _clique_key(self.lists, c)))

    @property
    def spec(self) -> ModelSpec:
        """The same log-linear model as a crc_engine ModelSpec (the K-way term only in the saturated model)."""
        sizes = [len(c) for c in self.cliques]
        if any(2 < s < self.K for s in sizes):
            raise NotImplementedError("ModelSpec has no interactions of order 3 to K-1")
        kway = self.K >= 3 and max(sizes) == self.K
        return ModelSpec(self.lists, self.edges, kway=kway, allow_kway=kway, label=self.label)

    def clique_alpha(self, clique: Sequence[str], delta: float, convention: str = "consistent") -> float:
        """Dirichlet parameter of each cell of a clique table."""
        if convention == "consistent":
            return delta * 2.0 ** (self.K - len(clique))
        if convention == "per_clique":
            return float(delta)
        raise ValueError(f"convention must be one of {CONVENTIONS}")


def decomposable_models(lists: Sequence[str]) -> list[GraphicalModel]:
    """Every decomposable graphical model for ``lists``, by number of edges (8 models for three lists)."""
    lists = tuple(lists)
    pairs = list(itertools.combinations(lists, 2))
    out = []
    for k in range(len(pairs) + 1):
        for edges in itertools.combinations(pairs, k):
            e = frozenset(edges)
            order = _perfect_order(lists, _maximal_cliques(lists, e))
            if order is not None:
                out.append(GraphicalModel(lists, e, *order))
    return out


# ======================================================================= priors on N
@dataclass(frozen=True)
class NegativeBinomialPrior:
    """N ~ Poisson(lambda), lambda ~ Gamma(shape a, scale b): Madigan & York's eq. (3)."""

    a: float
    b: float
    name: str = "negative binomial"
    proper = True

    @classmethod
    def from_mean_sd(cls, mean: float, sd: float, name: str = "negative binomial") -> "NegativeBinomialPrior":
        """The prior whose lambda has this mean and standard deviation."""
        return cls((mean / sd) ** 2, sd**2 / mean, name)

    def logpmf(self, N: np.ndarray) -> np.ndarray:
        N = np.asarray(N, float)
        a, b = self.a, self.b
        return gammaln(N + a) - gammaln(a) - gammaln(N + 1) + N * np.log(b / (1 + b)) - a * np.log1p(b)

    def upper(self, eps: float = 1e-16) -> int:
        """An N above which the prior holds less than ``eps``."""
        return int(stats.nbinom.isf(eps, self.a, 1.0 / (1.0 + self.b))) + 1


@dataclass(frozen=True)
class JeffreysPrior:
    """P(N) proportional to 1/N (eq. 1); improper, so no PyMC counterpart that SMC could start from."""

    name: str = "Jeffreys"
    proper = False

    def logpmf(self, N):
        return -np.log(np.asarray(N, float))


@dataclass(frozen=True)
class RissanenPrior:
    """P(N) proportional to 2^(-log*(N)) (eq. 2); log*(N) sums the positive terms of log2 N, log2 log2 N, ..."""

    name: str = "Rissanen"
    proper = True

    def logpmf(self, N):
        x = np.log2(np.asarray(N, float))
        out = np.zeros_like(x)
        while True:
            pos = x > 0
            if not pos.any():
                break
            out[pos] += x[pos]
            x = np.where(pos, np.log2(np.where(pos, x, 1.0)), 0.0)
        return -out * np.log(2.0)


# =================================================================== exact posterior
def log_evidence_given_N(y_obs: np.ndarray, model: GraphicalModel, N: np.ndarray, delta: float,
                         convention: str = "consistent") -> np.ndarray:
    """log P(D | N, m) for every N in ``N``: the multinomial coefficient times, for each clique table, the
    Dirichlet-multinomial ratio B(alpha + counts) / B(alpha) (TR 234, eqs. 5-7).

    ``y_obs`` holds the 2^K - 1 observed cells in crc_engine's history order; the hidden cell is N - n.
    """
    y = np.asarray(y_obs, float)
    K = model.K
    if y.shape != (2**K - 1,):
        raise ValueError(f"expected {2**K - 1} observed cells")
    N = np.asarray(N, float)
    n = y.sum()
    if (N < n).any():
        raise ValueError("N below the number observed")
    H = histories(K, include_unobserved=True)
    full = np.empty((N.size, 2**K))
    full[:, 0] = N - n
    full[:, 1:] = y
    out = gammaln(N + 1) - gammaln(N - n + 1) - gammaln(y + 1).sum()
    for clique, sep in zip(model.cliques, model.separators):
        rest = [v for v in clique if v not in sep]
        cols = [model.lists.index(v) for v in list(sep) + rest]
        idx = config_index(H, cols)
        A = np.zeros((2**K, 2 ** len(cols)))
        A[np.arange(2**K), idx] = 1.0
        m = (full @ A).reshape(N.size, 2 ** len(sep), 2 ** len(rest))
        a = model.clique_alpha(clique, delta, convention)
        R = 2 ** len(rest)
        dm = gammaln(a + m).sum(-1) - R * gammaln(a) + gammaln(R * a) - gammaln(R * a + m.sum(-1))
        out = out + dm.sum(-1)
    return out


@dataclass(frozen=True)
class ExactPosterior:
    """Exact BMA posterior over a model set: no Monte Carlo error."""

    labels: tuple[str, ...]
    log_ml: np.ndarray            # log P(D | m), every constant included
    weights: np.ndarray           # posterior model probabilities
    grid: np.ndarray              # N values (integers) at which the pmfs are given
    pmf: np.ndarray               # (models, grid): P(N | D, m)
    tail_mass: float              # BMA posterior mass beyond the integer grid (heavy-tailed priors only)

    @property
    def bma_pmf(self) -> np.ndarray:
        return self.weights @ self.pmf


def _n_grid(n: int, prior) -> tuple[np.ndarray, np.ndarray, int]:
    """Nodes and weights for the sum over N; the integers up to the returned index are summed exactly."""
    if isinstance(prior, NegativeBinomialPrior):
        top = max(prior.upper(), n + 2000)
        g = np.arange(n, top + 1, dtype=float)
        return g, np.ones_like(g), g.size
    g1 = np.arange(n, 200_000, dtype=float)                     # exact sum
    g2 = np.unique(np.round(np.geomspace(200_000, 1e13, 20_000)))  # the tail, as an integral
    return np.concatenate([g1, g2]), np.concatenate([np.ones_like(g1), np.gradient(g2)]), g1.size


def exact_posterior(y_obs: np.ndarray, models: Sequence[GraphicalModel], delta: float, prior, *,
                    convention: str = "consistent", model_prior: np.ndarray | None = None) -> ExactPosterior:
    """Posterior model probabilities and P(N | D, m) by summing the closed form over N."""
    y = np.asarray(y_obs, float)
    n = int(y.sum())
    G, W, k = _n_grid(n, prior)
    lp = np.stack([log_evidence_given_N(y, m, G, delta, convention) + prior.logpmf(G) + np.log(W) for m in models])
    log_ml = logsumexp(lp, axis=1)
    pri = np.full(len(models), 1.0 / len(models)) if model_prior is None else np.asarray(model_prior, float)
    lw = log_ml + np.log(pri)
    weights = np.exp(lw - logsumexp(lw))
    post = np.exp(lp - log_ml[:, None])
    bma = weights @ post
    tail = float(bma[k:].sum() / bma.sum())
    return ExactPosterior(tuple(m.label for m in models), log_ml, weights, G[:k].astype(int), post[:, :k], tail)


# ============================================================= summaries of N
QUANTILE_KEYS = {0.025: "q025", 0.975: "q975", 0.05: "q05", 0.95: "q95"}


def _continuous_quantile(g: np.ndarray, cdf: np.ndarray, q: float) -> float:
    """Where the CDF, joined linearly between integers, reaches q: in (k - 1, k] when the percentile is k."""
    k = min(int(np.searchsorted(cdf, q)), g.size - 1)
    if k == 0 or cdf[k] <= cdf[k - 1]:
        return float(g[k])
    return float(g[k - 1] + (q - cdf[k - 1]) / (cdf[k] - cdf[k - 1]))


def _continuous_mode(g: np.ndarray, p: np.ndarray) -> float:
    """Vertex of the parabola through the pmf's maximum and its neighbours: within half a unit of the mode."""
    k = int(np.argmax(p))
    if k == 0 or k == g.size - 1:
        return float(g[k])
    a, b, c = p[k - 1], p[k], p[k + 1]
    den = a - 2 * b + c
    return float(g[k] + (a - c) / (2 * den)) if den < 0 else float(g[k])


def n_summary(grid: np.ndarray, pmf: np.ndarray, probs: Sequence[float] = (0.025, 0.975)) -> dict:
    """Madigan & York's summaries of a posterior pmf of N.

    ``N_hat`` is the Bayes estimate under relative squared-error loss, E(1/N) / E(1/N^2) (eq. 9); ``mode`` the
    most probable N; a percentile is the smallest N whose cumulative probability reaches it.  The keys ending in
    ``_c`` are continuous versions of the mode and the percentiles, whose Monte Carlo error is visible even when
    every run rounds to the same integer: the percentile k corresponds to ``_c`` in (k - 1, k], the mode m to
    ``_c`` in [m - 1/2, m + 1/2].
    """
    g = np.asarray(grid, float)
    p = np.asarray(pmf, float)
    p = p / p.sum()
    cdf = np.cumsum(p)
    out = {"N_hat": float((p / g).sum() / (p / g**2).sum()), "mode": int(g[np.argmax(p)]),
           "mode_c": _continuous_mode(g, p), "median": int(g[min(np.searchsorted(cdf, 0.5), g.size - 1)]),
           "mean": float(p @ g), "sd": float(np.sqrt(p @ (g - p @ g) ** 2))}
    for q in probs:
        key = QUANTILE_KEYS.get(q, f"q{q}")
        out[key] = int(g[min(np.searchsorted(cdf, q), g.size - 1)])
        out[key + "_c"] = _continuous_quantile(g, cdf, q)
    return out


def poisson_mixture_pmf(n: int, mu: np.ndarray, x_max: int | None = None,
                        max_elements: int = 20_000_000) -> tuple[np.ndarray, np.ndarray]:
    """Rao-Blackwellised posterior pmf of N = n + M, M ~ Poisson(mu), averaged over draws of the hidden mean ``mu``.

    It has far less Monte Carlo error than one Poisson draw per posterior draw, which matters for the mode.
    ``max_elements`` bounds the memory of each block of draws x grid.
    """
    mu = np.asarray(mu, float).ravel()
    if not np.all(np.isfinite(mu)) or (mu < 0).any():
        raise ValueError("hidden means must be finite and non-negative")
    if x_max is None:
        x_max = int(stats.poisson.isf(1e-12, mu.max())) + 1
    x = np.arange(x_max + 1)
    chunk = max(1, max_elements // x.size)
    pmf = np.zeros(x.size)
    for i in range(0, mu.size, chunk):
        pmf += stats.poisson.pmf(x[None, :], mu[i:i + chunk, None]).sum(axis=0)
    return n + x, pmf / mu.size


# ============================================================================ PyMC
def build_pymc_model(y_obs: np.ndarray, model: GraphicalModel, delta: float, prior: NegativeBinomialPrior, *,
                     convention: str = "consistent"):
    """Madigan & York's model of ``model`` in PyMC.

    lambda ~ Gamma(a, scale b); theta from Dirichlet clique tables along the perfect order; observed cells
    y_h ~ Poisson(lambda theta_h).  Deterministic ``hidden_mu`` = lambda theta_0, the hidden cell's mean.
    """
    import pymc as pm
    import pytensor.tensor as pt

    if not isinstance(prior, NegativeBinomialPrior):
        raise ValueError("SMC starts from draws of the prior, so the prior on N must be proper and continuous in "
                         "lambda: only the negative binomial (Gamma-Poisson) prior has a PyMC form here")
    y = np.asarray(y_obs)
    K = model.K
    H = histories(K, include_unobserved=True)
    with pm.Model() as m:
        lam = pm.Gamma("lam", alpha=prior.a, beta=1.0 / prior.b)
        log_theta = 0.0
        for clique, sep in zip(model.cliques, model.separators):
            rest = [v for v in clique if v not in sep]
            a = model.clique_alpha(clique, delta, convention)
            r_idx = config_index(H, [model.lists.index(v) for v in rest])
            name = "theta_" + "".join(rest) + ("_given_" + "".join(sep) if sep else "")
            if sep:
                s_idx = config_index(H, [model.lists.index(v) for v in sep])
                p = pm.Dirichlet(name, a=np.full((2 ** len(sep), 2 ** len(rest)), a))
                log_theta = log_theta + pt.log(p)[s_idx, r_idx]
            else:
                p = pm.Dirichlet(name, a=np.full(2 ** len(rest), a))
                log_theta = log_theta + pt.log(p)[r_idx]
        log_mu = pt.log(lam) + log_theta
        pm.Poisson("y", mu=pt.exp(log_mu[1:]), observed=y)
        pm.Deterministic("hidden_mu", pt.exp(log_mu[0]))
    return m


def prior_log_theta_draws(model: GraphicalModel, delta: float, rng: np.random.Generator, size: int,
                          convention: str = "consistent") -> np.ndarray:
    """Draws of log theta (size, 2^K) from the hyper-Dirichlet prior, in numpy (tests and checks)."""
    K = model.K
    H = histories(K, include_unobserved=True)
    out = np.zeros((size, 2**K))
    for clique, sep in zip(model.cliques, model.separators):
        rest = [v for v in clique if v not in sep]
        a = model.clique_alpha(clique, delta, convention)
        r_idx = config_index(H, [model.lists.index(v) for v in rest])
        s_idx = config_index(H, [model.lists.index(v) for v in sep])
        p = rng.dirichlet(np.full(2 ** len(rest), a), size=(size, 2 ** len(sep)))
        out += np.log(p[:, s_idx, r_idx])
    return out
