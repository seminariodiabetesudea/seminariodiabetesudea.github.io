"""Phase 4, check 3: frequentist cross-check of the structured models.

**In plain words.** With a lot of data, a Bayesian estimate and the classical (maximum-likelihood) estimate
of the same model should agree, because the data then outweigh the priors.  This check simulates tables with
far more people than the study has, fits each model both ways, and checks that they agree.

**Technically.**  Every model's design matrix, X = [one indicator per stratum-year | the capture part of
``models.structured_design``], is fitted by Poisson maximum likelihood three ways:

* statsmodels' Poisson GLM (IRLS): the reference MLE, N-hat = n + sum over stratum-years of exp(alpha-hat);
* ``crc_engine.mle.fit_design`` (numpy Newton) on ``modelspace.design_matrix`` with a saturated count part,
  whose capture columns are checked to be the structured design's;
* Rcapture ``closedpCI.t`` with a custom ``mX``, for the models whose stratified likelihood factorises into
  single tables, the only kind ``closedpCI.t`` fits (one hidden cell, the intercept):

  - no list x covariate term: the capture part is the same in every stratum-year, so the score equations of
    the stratified model reduce to those of the pooled table and N-hat is the pooled table's (the stratum
    intercepts absorb each stratum's total, exp(alpha_s) = n_s / sum_h exp(x_h theta));
  - independence with one list x covariate term: each level of the covariate has its own capture parameters
    and nothing is shared between levels, so N-hat is the sum of the levels' pooled-table Mt estimates.

  The other models share capture parameters across strata that differ in their capture part; no single
  ``closedpCI.t`` call can represent them, so statsmodels and the engine's own MLE cover them.

The Bayesian side is the PyMC model of ``build_structured_model`` (the plan's priors and NUTS settings); its
posterior median of N = n + sum M, M ~ Poisson(hidden mean) per draw, is compared with the statsmodels MLE.

Pass rule (build plan, Phase 4): on data-rich simulated tables, every posterior median of N within 2% of the
MLE.  The three maximum-likelihood fits must also agree with one another (relative difference below 1e-6)
before the MLE serves as the reference; that requirement is this module's, not the plan's.

**The amendments** (decision 122, ``docs/amendments/decision-122/``).  ``--amendment AM1`` or ``AM2`` fits the amended
models on the same two tables with the recalibrated set (by default all 64, "the amended space") and compares each
posterior median of N with its maximum-likelihood comparator under the same rule (``amended_mle_table``):

* AM1(m): m with fixed list x year effects, a Poisson GLM on [stratum indicators | X_capture(m) without its list x
  period columns, which the list x year columns span | the 27 list x year columns in effects coding]; the second route
  is ``crc_engine.mle`` on the same columns;
* AM2(m): NB1 maximum likelihood on [stratum indicators | X_capture(m)] by statsmodels' ``NegativeBinomial`` (nb1), at
  kappa = 0 (the Poisson fit) when the likelihood falls as kappa leaves zero; the second route is a direct maximisation
  over kappa >= 0 (scipy's L-BFGS-B on ``NB1Likelihood``).

N-hat is n plus the fitted hidden means.  The two routes must agree as above (for AM2 on kappa too); Rcapture is not
run (``RCAPTURE_SKIPPED`` says why).  ``--shard i/k`` fits every k-th model of each scenario's list into the run's
checkpoints and writes no summary, so k processes can share one folder; ``--summarize-only`` then builds the summary
from the checkpoints.  Without these options a run is the frozen one.

**The re-check's reference rule** (decision 127 (d)).  By default an AM2 model's comparator serves as its reference
under decision 125's rule: both routes converge and they agree, N within ``MLE_AGREEMENT`` relative and kappa within
``MLE_AGREEMENT`` x max(1, kappa).  ``--reference-rule decision-127`` drops one condition: the second route's success
flag (L-BFGS-B's) is recorded and no longer required, so the reference is valid when statsmodels converges and the two
routes agree as before (``am2_reference_valid``).  Decision 127 applies it to AM2's check 3 only, so it is refused for
AM1 and for the frozen check (``check_reference_rule``).  The rule changes no Bayesian fit, so the checkpoints' identity
does not hold it: ``--summarize-only`` computes every comparator again under the rule and reads the fits from the
checkpoints, as the re-check does on a copy of the first run's.  ``results.json`` then records the rule and, per
scenario, the models whose reference is not valid, those statsmodels or the second route did not report converged, and
the largest kappa difference.  The default rule writes the outputs it wrote before, bit for bit.
"""

from __future__ import annotations

import argparse
import json
import itertools
import math
import os
import warnings
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np
from scipy.special import gammaln

from ..amendments import AM1, AM2, AMENDMENTS
from ..mle import fit_design
from ..models import build_structured_model, cell_means, posterior_N, structured_design, with_period
from ..modelspace import Design, ModelSpec, design_matrix, model_space
from ..priors import PHASE3_PROPOSED, PHASE3_RECALIBRATED, RECALIBRATED_RATE
from ..tables import CaptureTable, histories
from . import _xc_common as xc

#: Pass rule of the build plan: |posterior median of N / MLE - 1| at most this.
MEDIAN_TOLERANCE = 0.02
#: The maximum-likelihood implementations must agree this closely to serve as the reference.
MLE_AGREEMENT = 1e-6
ROOT_SEED = 20261102
PRIOR_SETS = {"proposed": PHASE3_PROPOSED, "recalibrated": PHASE3_RECALIBRATED["E1"]}
#: The amendments' check 3 runs under this prior set only (decision 122, step 3).
AMENDMENT_PRIOR_SET = "recalibrated"
#: Each amendment's maximum-likelihood comparator (decision 122, step 3) and its second route.
COMPARATORS = {
    "AM1": "AM1(m) with fixed list x year effects: a Poisson GLM on [stratum indicators | X_capture(m) without list x "
           "period | the 27 list x year columns in effects coding] by statsmodels; crc_engine.mle as the second route",
    "AM2": "AM2(m) by NB1 maximum likelihood on [stratum indicators | X_capture(m)]: statsmodels NegativeBinomial "
           "(nb1), at kappa = 0 (the Poisson fit) when the likelihood falls as kappa leaves zero; a direct scipy "
           "maximisation over kappa >= 0 as the second route"}
SECOND_ROUTE = {"AM1": "crc_engine.mle", "AM2": "scipy L-BFGS-B"}
#: Why Rcapture is not run for the amended models.
RCAPTURE_SKIPPED = {
    "AM1": "Rcapture's closedpCI.t fits the Poisson log-linear model of single tables; AM1's comparator has list x "
           "year effects, which only its independence model without list x covariate terms splits into single tables "
           "(one per year), so Rcapture would check one model of 64",
    "AM2": "Rcapture's closedpCI.t fits Poisson counts, not NB1 counts"}
#: When an AM2 model's maximum-likelihood comparator serves as its reference (``am2_reference_valid``).
REFERENCE_RULES = {
    "decision-125": "both routes converge (statsmodels, and the second route's success flag) and agree: N within 1e-6 "
                    "relative and kappa within 1e-6 x max(1, kappa)",
    "decision-127": "statsmodels converges and the two routes agree: N within 1e-6 relative and kappa within 1e-6 x "
                    "max(1, kappa); the second route's success flag is recorded, not required (decision 127 (d))"}
#: The rule the first run was judged on (decision 125), everywhere; decision 127's applies to AM2's check 3 only.
DEFAULT_REFERENCE_RULE = "decision-125"


@dataclass(frozen=True)
class Scenario:
    """A data-rich simulated table on E1's strata (2 sexes x 3 age bands x 10 years).

    Fixed before any fit: hundreds of people per stratum-year, so every observed cell expects tens of people.
    """

    name: str
    log_hidden: float                                   # alpha: log hidden count per stratum-year (mean)
    beta: Mapping[str, float]
    pairs: Mapping[str, float]
    list_cov: Mapping[str, Mapping[str, tuple]] = field(default_factory=dict)
    description: str = ""

    @property
    def true_spec(self) -> ModelSpec:
        pairs = frozenset((p[0], p[1]) for p in self.pairs)
        return ModelSpec(xc.LISTS, pairs, tuple(c for c in xc.COVARIATES if c in self.list_cov))


SCENARIOS = {
    "rich-high": Scenario(
        "rich-high", float(np.log(100.0)), {"A": -0.2, "B": 0.2, "C": -0.6}, {"AB": float(np.log(2.0)), "BC": float(np.log(0.6))},
        {"age_band": {"A": (0.3, 0.0, -0.3), "B": (-0.2, 0.1, 0.1), "C": (0.0, -0.15, 0.15)}},
        "about 600 people per stratum-year, completeness about 85%; truth AB + BC with list x age band"),
    "rich-low": Scenario(
        "rich-low", float(np.log(300.0)), {"A": -1.0, "B": -0.8, "C": -1.2}, {"AB": float(np.log(2.0)), "AC": float(np.log(1.5))},
        {"age_band": {"A": (0.2, 0.0, -0.2), "B": (-0.3, 0.1, 0.2), "C": (0.1, -0.1, 0.0)},
         "period": {"A": (0.15, -0.15), "B": (0.0, 0.0), "C": (-0.2, 0.2)}},
        "about 800 people per stratum-year, completeness about 60%; truth AB + AC with list x age band and period"),
}


def simulate(scenario: Scenario, seed: int) -> dict:
    """The scenario's table, true N, expected totals per stratum-year and the truth's design."""
    rng = np.random.default_rng(seed)
    table = xc.e1_table()
    d = structured_design(table, scenario.true_spec, periods=xc.PERIODS)
    params = xc.count_truth(table.levels, rng, log_level=scenario.log_hidden)
    params["theta_capture"] = xc.capture_theta(d, scenario.beta, scenario.pairs, scenario.list_cov)
    tab, N, _ = xc.simulate_table(table, scenario.true_spec, params, rng)
    mu = cell_means({k: np.asarray(v)[None, ...] for k, v in params.items()}, d)[0]
    expected_total = np.bincount(d.stratum, weights=mu, minlength=d.S)
    expected_hidden = mu[d.hidden]
    return {"table": tab, "N_true": N, "expected_total": expected_total,
            "expected_completeness": float(1 - expected_hidden.sum() / expected_total.sum())}


# ------------------------------------------------------------------------- maximum likelihood
def glm_design(table: CaptureTable, spec: ModelSpec):
    """X = [stratum-year indicators | structured capture part], with the structured design itself."""
    d = structured_design(table, spec, periods=xc.PERIODS)
    X = np.hstack([np.eye(d.S)[d.stratum], d.X_capture])
    return X, d


def poisson_glm(X: np.ndarray, d) -> dict:
    """statsmodels' Poisson GLM (IRLS) on the observed rows of ``X``: N-hat = n + the fitted hidden means, with the
    delta-method standard error of their sum, the coefficients and the fitted observed means."""
    import statsmodels.api as sm

    obs = ~d.hidden
    res = sm.GLM(d.y[obs], X[obs], family=sm.families.Poisson()).fit(tol=1e-13, maxiter=500)
    beta = np.asarray(res.params)
    Xh = X[d.hidden]
    hidden = np.exp(Xh @ beta)
    g = (Xh * hidden[:, None]).sum(axis=0)
    var = float(g @ np.asarray(res.cov_params()) @ g)
    return {"N": float(d.n_observed + hidden.sum()), "hidden": float(hidden.sum()),
            "se_hidden_mean": float(np.sqrt(var)), "converged": bool(res.converged), "deviance": float(res.deviance), "df_resid": int(res.df_resid),
            "n_params": int(X.shape[1]), "llf": float(res.llf), "beta": beta, "fitted": np.asarray(res.fittedvalues)}


def fit_statsmodels(table: CaptureTable, spec: ModelSpec) -> dict:
    X, d = glm_design(table, spec)
    r = poisson_glm(X, d)
    return {k: r[k] for k in ("N", "se_hidden_mean", "converged", "deviance", "df_resid", "n_params")}


def fit_engine_mle(table: CaptureTable, spec: ModelSpec) -> dict:
    """``crc_engine.mle`` on the modelspace design with a saturated count part (same capture columns)."""
    tab = with_period(table, xc.PERIODS) if "period" in spec.list_covariates else table
    D = design_matrix(replace(spec, count_part="saturated"), tab)
    _, d = glm_design(table, spec)
    cap = np.hstack([D.X[:, sl] for b, sl in D.blocks.items() if b != "count"])
    if cap.shape != d.X_capture.shape or not np.array_equal(cap, d.X_capture):
        raise AssertionError(f"{spec.name}: the modelspace and structured capture columns differ")
    f = fit_design(D)
    return {"N": f.N, "converged": bool(f.converged), "boundary": bool(f.boundary)}


def collapsible(spec: ModelSpec) -> str | None:
    """How Rcapture can fit ``spec`` on single tables: "pooled", "by-<covariate>", or None."""
    if not spec.list_covariates:
        return "pooled"
    if not spec.pairs and len(spec.list_covariates) == 1:
        return f"by-{spec.list_covariates[0]}"
    return None


def _histpos_order(K: int = 3) -> np.ndarray:
    """crc-engine's observed-history index of every row of Rcapture's ``histpos.t(K)`` (111, 110, ..., 001)."""
    H = histories(K)
    rc = np.array(list(itertools.product((1, 0), repeat=K)))[:-1]
    return np.array([int(np.flatnonzero((H == r).all(axis=1))[0]) for r in rc])


def rcapture_payload(table: CaptureTable, specs: Sequence[ModelSpec]) -> tuple[list[dict], dict]:
    """Single-table fits for Rcapture, and how each model's N-hat is assembled from them."""
    order = _histpos_order(table.K)
    tab = with_period(table, xc.PERIODS)
    fits, plan = [], {}
    for spec in specs:
        how = collapsible(spec)
        if how is None:
            continue
        one = CaptureTable(table.lists, tab.strata.iloc[:1].reset_index(drop=True), tab.counts[:1], tab.levels)
        if how == "pooled":
            dd = design_matrix(replace(spec, count_part="intercept"), one)
            groups = {"all": np.ones(tab.S, bool)}
        else:
            var = how[3:]
            dd = design_matrix(ModelSpec(spec.lists, count_part="intercept"), one)
            groups = {str(lv): (tab.strata[var] == lv).to_numpy() for lv in tab.levels[var]}
        cols = [i for i, c in enumerate(dd.columns) if c != "count:intercept"]
        mX = dd.X[~dd.hidden][:, cols][order]
        ids = []
        for g, rows in groups.items():
            fid = f"{spec.name}|{g}"
            fits.append({"id": fid, "freq": tab.counts[rows].sum(axis=0)[order].tolist(), "mX": mX.tolist()})
            ids.append(fid)
        plan[spec.name] = ids
    return fits, plan


R_CLOSEDPCI = r"""
suppressPackageStartupMessages({library(jsonlite); library(Rcapture)})
inp <- fromJSON(Sys.getenv("XC_IN"), simplifyVector = FALSE)
H <- histpos.t(3)
out <- lapply(inp$fits, function(f) {
  X <- cbind(H, freq = unlist(f$freq))
  mX <- matrix(unlist(f$mX), nrow = nrow(H), byrow = TRUE)
  r <- tryCatch(suppressWarnings(closedpCI.t(X, dfreq = TRUE, mX = mX, mname = f$id)), error = function(e) e)
  if (inherits(r, "error")) return(list(id = f$id, error = conditionMessage(r)))
  list(id = f$id, abundance = unname(r$results[1, "abundance"]), stderr = unname(r$results[1, "stderr"]),
       deviance = unname(r$results[1, "deviance"]), df = unname(r$results[1, "df"]),
       infoFit = unname(r$results[1, "infoFit"]), converged = isTRUE(r$fit$converged))
})
write_json(list(fits = out), Sys.getenv("XC_OUT"), auto_unbox = TRUE, digits = NA)
"""


def fit_rcapture(table: CaptureTable, specs: Sequence[ModelSpec]) -> dict[str, dict]:
    fits, plan = rcapture_payload(table, specs)
    if not fits:
        return {}
    got = {f["id"]: f for f in xc.run_r(R_CLOSEDPCI, {"fits": fits})["fits"]}
    out = {}
    for name, ids in plan.items():
        parts = [got[i] for i in ids]
        err = [p.get("error") for p in parts if "error" in p]
        out[name] = ({"error": "; ".join(err)} if err else
                     {"N": float(sum(p["abundance"] for p in parts)), "tables": len(parts),
                      "converged": all(p["converged"] for p in parts),
                      "how": collapsible(next(s for s in specs if s.name == name))})
    return out


def mle_table(table: CaptureTable, specs: Sequence[ModelSpec], *, with_r: bool = True) -> list[dict]:
    """Every model fitted by the three maximum-likelihood routes, with their agreement."""
    rc = fit_rcapture(table, specs) if with_r and xc.r_available() else {}
    rows = []
    for spec in specs:
        s = fit_statsmodels(table, spec)
        e = fit_engine_mle(table, spec)
        row = {"model": spec.name, "N_statsmodels": s["N"], "se_hidden_statsmodels": s["se_hidden_mean"],
               "statsmodels_converged": s["converged"], "n_params": s["n_params"], "deviance": s["deviance"],
               "df_resid": s["df_resid"], "N_engine": e["N"], "engine_converged": e["converged"],
               "engine_boundary": e["boundary"], "rel_engine_vs_statsmodels": e["N"] / s["N"] - 1}
        r = rc.get(spec.name)
        if r and "N" in r:
            row.update(N_rcapture=r["N"], rcapture_route=r["how"], rcapture_tables=r["tables"],
                       rcapture_converged=r["converged"], rel_rcapture_vs_statsmodels=r["N"] / s["N"] - 1)
        elif r:
            row.update(rcapture_error=r["error"])
        rels = [abs(row[k]) for k in ("rel_engine_vs_statsmodels", "rel_rcapture_vs_statsmodels") if k in row]
        row["mle_agree"] = bool(s["converged"] and e["converged"] and max(rels) < MLE_AGREEMENT)
        rows.append(row)
    return rows


# ------------------------------------------------------------------------- the amendments' comparators (decision 122)
def am1_glm_design(table: CaptureTable, spec: ModelSpec):
    """AM1(m)'s comparator design, [stratum-year indicators | X_capture(m) without list x period | the 27 list x year
    columns in effects coding], with AM1(m)'s structured design and the mask of the capture columns kept.  The list x
    year columns span list x period, so m's list x period columns are dropped and the columns stay independent."""
    if spec.amendment != AM1.id:
        raise ValueError(f"{spec.name}: the AM1 comparator is for an AM1 model")
    d = structured_design(table, spec, periods=xc.PERIODS)
    keep = np.ones(len(d.capture_columns), bool)
    if "list×period" in d.capture_blocks:
        keep[d.capture_blocks["list×period"]] = False
    return np.hstack([np.eye(d.S)[d.stratum], d.X_capture[:, keep]]), d, keep


def _without_block(D: Design, block: str) -> Design:
    """``D`` without the columns of ``block`` (if it has them)."""
    if block not in D.blocks:
        return D
    sl = D.blocks[block]
    keep = [i for i in range(D.X.shape[1]) if not sl.start <= i < sl.stop]
    blocks, start = {}, 0
    for b, s in D.blocks.items():
        if b != block:
            blocks[b] = slice(start, start + s.stop - s.start)
            start += s.stop - s.start
    return replace(D, X=D.X[:, keep], columns=tuple(D.columns[i] for i in keep), blocks=blocks)


def fit_am1_comparator(table: CaptureTable, spec: ModelSpec) -> dict:
    """AM1(m)'s comparator by statsmodels' Poisson GLM and, as the second route, ``crc_engine.mle`` on the modelspace
    design with a saturated count part and the same capture columns (checked)."""
    X, d, keep = am1_glm_design(table, spec)
    s = poisson_glm(X, d)
    tab = with_period(table, xc.PERIODS) if "period" in spec.list_covariates else table
    D = _without_block(design_matrix(replace(spec, count_part="saturated"), tab), "list×period")
    cap = np.hstack([D.X[:, sl] for b, sl in D.blocks.items() if b != "count"])
    if not np.array_equal(cap, d.X_capture[:, keep]):
        raise AssertionError(f"{spec.name}: the modelspace and structured comparator columns differ")
    e = fit_design(D)
    rel = float(e.N / s["N"] - 1)
    return {"comparator": "Poisson GLM, fixed list x year effects", "N_statsmodels": s["N"],
            "se_hidden_statsmodels": s["se_hidden_mean"], "statsmodels_converged": s["converged"],
            "n_params": s["n_params"], "deviance": s["deviance"], "df_resid": s["df_resid"],
            "second_route": SECOND_ROUTE[AM1.id], "N_second": float(e.N), "second_converged": bool(e.converged),
            "second_boundary": bool(e.boundary), "rel_second_vs_statsmodels": rel,
            "mle_agree": bool(s["converged"] and e.converged and abs(rel) < MLE_AGREEMENT)}


def _log1p_ratio(k: float) -> tuple[float, float]:
    """log(1 + k) / k and its derivative in k, by their series near zero (where they are 1 and -1/2)."""
    if k < 1e-4:
        return (1.0 - k / 2 + k**2 / 3 - k**3 / 4 + k**4 / 5,
                -0.5 + 2 * k / 3 - 3 * k**2 / 4 + 4 * k**3 / 5)
    return math.log1p(k) / k, (k / (1.0 + k) - math.log1p(k)) / k**2


class NB1Likelihood:
    """The NB1 log-likelihood of counts ``y`` with log means ``X`` beta and dispersion kappa >= 0, every constant
    included, and its gradient in (beta, kappa), for ``__call__(theta)`` with theta = (beta, kappa).

    NB1(mu, kappa) is the negative binomial with size r = mu / kappa (AM2's counts, ``models.nb1_parameters``).  For
    integer y, log Gamma(y + r) - log Gamma(r) = y log r + sum_{j<y} log(1 + j / r), so

        log p(y) = y log mu + sum_{j<y} log(1 + j kappa / mu) - log y! - mu log(1 + kappa) / kappa - y log(1 + kappa),

    smooth in kappa >= 0, and the Poisson log-likelihood at kappa = 0, where its slope in kappa is
    ((y - mu)^2 - y) / (2 mu).
    """

    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = np.asarray(X, float)
        self.y = np.asarray(y).astype(np.int64)
        if np.any(self.y < 0) or not np.array_equal(self.y, np.asarray(y)):
            raise ValueError("NB1 counts are non-negative integers")
        self.cell = np.repeat(np.arange(self.y.size), self.y)           # one entry per j < y, for every cell
        self.j = (np.arange(self.y.sum()) - np.repeat(np.cumsum(self.y) - self.y, self.y)).astype(float)
        self.log_y_factorial = gammaln(self.y + 1.0)

    def __call__(self, theta) -> tuple[float, np.ndarray]:
        theta = np.asarray(theta, float)
        beta, kappa = theta[:-1], float(theta[-1])
        eta = self.X @ beta
        mu = np.exp(eta)
        c = kappa * np.exp(-eta)                                         # kappa / mu
        jc = self.j * c[self.cell]
        s = np.bincount(self.cell, np.log1p(jc), minlength=self.y.size)
        ds = np.bincount(self.cell, self.j / (1.0 + jc), minlength=self.y.size)
        g, dg = _log1p_ratio(kappa)
        ll = float(np.sum(self.y * eta + s - self.log_y_factorial - mu * g) - self.y.sum() * math.log1p(kappa))
        d_eta = self.y - c * ds - mu * g
        d_kappa = float(np.sum(ds / mu - mu * dg) - self.y.sum() / (1.0 + kappa))
        return ll, np.append(self.X.T @ d_eta, d_kappa)


def fit_nb1_statsmodels(X: np.ndarray, d) -> dict:
    """NB1 maximum likelihood by statsmodels' ``NegativeBinomial`` (loglike_method "nb1": variance mu (1 + alpha), alpha
    being kappa).  The maximum over kappa >= 0 is the Poisson fit (kappa = 0) when the log-likelihood's slope in kappa
    there, sum ((y - mu)^2 - y) / (2 mu) at the Poisson maximum, is not positive: the Poisson fit maximises over beta,
    so that slope is the profile likelihood's.  Otherwise Newton's method (statsmodels' analytic Hessian, in alpha
    itself) starts from the Poisson fit and the moment estimate of kappa; its own default start would put the
    boundary cases below zero."""
    from statsmodels.discrete.discrete_model import NegativeBinomial

    obs = ~d.hidden
    y = d.y[obs]
    p = poisson_glm(X, d)
    mu = p["fitted"]
    slope = float(np.sum(((y - mu) ** 2 - y) / (2.0 * mu)))
    if slope <= 0:
        beta, kappa, converged, llf = p["beta"], 0.0, p["converged"], p["llf"]
    else:
        start = np.append(p["beta"], max(0.05, float(np.sum((y - mu) ** 2 / mu - 1.0) / p["df_resid"])))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            res = NegativeBinomial(y, X[obs], loglike_method="nb1").fit(start_params=start, method="newton",
                                                                         maxiter=200, tol=1e-12, disp=0)
        params = np.asarray(res.params, float)
        beta, kappa, llf = params[:-1], float(params[-1]), float(res.llf)
        converged = bool(res.mle_retvals["converged"] and np.all(np.isfinite(params)) and kappa > 0)
    hidden = np.exp(X[d.hidden] @ beta)
    return {"N": float(d.n_observed + hidden.sum()), "kappa": kappa, "boundary": slope <= 0,
            "score_kappa_at_zero": slope, "converged": converged, "llf": llf, "n_params": int(X.shape[1]) + 1}


def fit_nb1_scipy(X: np.ndarray, d) -> dict:
    """NB1 maximum likelihood by a direct maximisation of ``NB1Likelihood`` over beta and kappa >= 0 (scipy's
    L-BFGS-B), from a start of its own: each stratum's mean observed count, no capture effect, kappa = 0.1."""
    from scipy.optimize import minimize

    obs = ~d.hidden
    nb = NB1Likelihood(X[obs], d.y[obs])
    scale = max(1.0, float(nb.y.sum()))
    start = np.zeros(X.shape[1] + 1)
    per_stratum = np.bincount(d.stratum[obs], nb.y, minlength=d.S) / d.n_hist
    start[:d.S] = np.log(np.maximum(per_stratum, 0.5))                   # the stratum indicators come first
    start[-1] = 0.1

    def objective(theta):
        ll, g = nb(theta)
        return -ll / scale, -g / scale

    r = minimize(objective, start, jac=True, method="L-BFGS-B", bounds=[(None, None)] * X.shape[1] + [(0.0, None)],
                 options={"maxiter": 20000, "maxfun": 40000, "ftol": 1e-16, "gtol": 1e-12, "maxcor": 30})
    hidden = np.exp(X[d.hidden] @ r.x[:-1])
    return {"N": float(d.n_observed + hidden.sum()), "kappa": float(r.x[-1]), "converged": bool(r.success),
            "llf": float(-r.fun * scale), "iterations": int(r.nit)}


def check_reference_rule(rule: str, amendment: str | None) -> None:
    """Refuse a reference rule the decision log does not apply to ``amendment``'s check 3.  Decision 127 (d) applies its
    rule to AM2's check 3 only, so it is refused for AM1 and for the frozen check (no amendment); the default rule,
    decision 125's, applies everywhere."""
    if rule not in REFERENCE_RULES:
        raise ValueError(f"unknown reference rule {rule!r}; the rules are {sorted(REFERENCE_RULES)}")
    if rule != DEFAULT_REFERENCE_RULE and amendment != AM2.id:
        raise ValueError(f"the reference rule {rule} is decision 127's for AM2's check 3 only; it is refused for "
                         f"{'the frozen check' if amendment is None else amendment}")


def am2_reference_valid(first: Mapping, second: Mapping, rule: str = DEFAULT_REFERENCE_RULE) -> bool:
    """Whether an AM2 model's comparator serves as its reference, from its first route's fit (``fit_nb1_statsmodels``)
    and its second's (``fit_nb1_scipy``).  The routes must agree: N within ``MLE_AGREEMENT`` relative and kappa within
    ``MLE_AGREEMENT`` x max(1, statsmodels' kappa).  Under decision 125 both routes must also report success; under
    decision 127 (d) statsmodels must, and the second route's success flag is not required."""
    check_reference_rule(rule, AM2.id)
    rel = float(second["N"] / first["N"] - 1)
    agree = (abs(rel) < MLE_AGREEMENT
             and abs(second["kappa"] - first["kappa"]) <= MLE_AGREEMENT * max(1.0, first["kappa"]))
    if rule == DEFAULT_REFERENCE_RULE:
        return bool(first["converged"] and second["converged"] and agree)
    return bool(first["converged"] and agree)


def fit_am2_comparator(table: CaptureTable, spec: ModelSpec, *, reference_rule: str = DEFAULT_REFERENCE_RULE) -> dict:
    """AM2(m)'s comparator: NB1 maximum likelihood on m's design by statsmodels (``fit_nb1_statsmodels``) and, as the
    second route, by a direct maximisation (``fit_nb1_scipy``); they must agree on N and on kappa, and
    ``reference_rule`` says which routes must report success (``am2_reference_valid``)."""
    if spec.amendment != AM2.id:
        raise ValueError(f"{spec.name}: the AM2 comparator is for an AM2 model")
    check_reference_rule(reference_rule, AM2.id)
    X, d = glm_design(table, spec)
    s, q = fit_nb1_statsmodels(X, d), fit_nb1_scipy(X, d)
    rel = float(q["N"] / s["N"] - 1)
    return {"comparator": "NB1 maximum likelihood", "N_statsmodels": s["N"], "kappa_statsmodels": s["kappa"],
            "kappa_boundary": s["boundary"], "score_kappa_at_zero": s["score_kappa_at_zero"],
            "statsmodels_converged": s["converged"], "llf": s["llf"], "n_params": s["n_params"],
            "second_route": SECOND_ROUTE[AM2.id], "N_second": q["N"], "kappa_second": q["kappa"],
            "second_converged": q["converged"], "rel_second_vs_statsmodels": rel,
            "mle_agree": am2_reference_valid(s, q, reference_rule)}


def amended_mle_table(table: CaptureTable, specs: Sequence[ModelSpec], *,
                      reference_rule: str = DEFAULT_REFERENCE_RULE) -> list[dict]:
    """Each amended model's maximum-likelihood comparator by its two routes, with their agreement under
    ``reference_rule`` (decision 127's for AM2 models only: ``check_reference_rule``, before any fit); Rcapture is
    skipped (``RCAPTURE_SKIPPED``)."""
    check_reference_rule(reference_rule, AM2.id)                  # a known rule, even for no model
    for spec in specs:                                             # every model before any fit
        check_reference_rule(reference_rule, spec.amendment)
    comparators = {AM1.id: fit_am1_comparator, AM2.id: fit_am2_comparator}
    rule = {} if reference_rule == DEFAULT_REFERENCE_RULE else {"reference_rule": reference_rule}
    rows = []
    for spec in specs:
        if spec.amendment not in comparators:
            raise ValueError(f"{spec.name} has no amendment, so no amended comparator")
        rows.append({"model": spec.name, **comparators[spec.amendment](table, spec, **rule), "rcapture": "skipped"})
    return rows


# ------------------------------------------------------------------------------ Bayesian fits
def bayes_fit(table: CaptureTable, spec: ModelSpec, prior_set: str, sampler: xc.Sampler, seed: int,
              exposure: np.ndarray | None) -> dict:
    priors = PRIOR_SETS[prior_set]
    with xc.timed() as t_build:
        sm = build_structured_model(table, spec, priors, periods=xc.PERIODS,
                                    exposure=exposure if priors.count_target == "total" else None)
    with xc.timed() as t_fit:
        idata = xc.nuts(sm.model, sampler, seed)
    _, N = posterior_N(sm, idata, np.random.default_rng(seed + 1))
    q = np.quantile(N, [0.025, 0.5, 0.975])
    return {"median": float(q[1]), "lower": float(q[0]), "upper": float(q[2]), "mean": float(N.mean()),
            "sd": float(N.std(ddof=1)), "gates": xc.gate_summary(idata, N), "sampler": xc.nuts_sampler_name(idata),
            "seconds_build": t_build.seconds, "seconds_fit": t_fit.seconds}


PILOT_MODELS = ("independence", "true", "richest")


def select_models(scenario: Scenario, which: str | Sequence[str]) -> list[ModelSpec]:
    space = model_space(xc.LISTS, xc.COVARIATES)
    if which == "all":
        return space
    names = PILOT_MODELS if which == "pilot" else tuple(which)
    out = []
    for n in names:
        if n == "independence":
            out.append(ModelSpec(xc.LISTS))
        elif n == "true":
            out.append(scenario.true_spec)
        elif n == "richest":
            out.append(ModelSpec(xc.LISTS, frozenset(itertools.combinations(xc.LISTS, 2)), xc.COVARIATES))
        else:
            out.append(next(s for s in space if s.name == n))
    return out


class MissingFit(LookupError):
    """A fit that ``run(..., summarize_only=True)`` needs has no checkpoint."""


def in_shard(position: int, shard: tuple[int, int]) -> bool:
    """Whether the fit at ``position`` (0-based) of a scenario's list of fits is shard (i, k)'s: i - 1 modulo k."""
    i, k = shard
    return position % k == i - 1


def _resumable_fit(out_dir, scenario: str, prior_set: str, spec: ModelSpec, fit_seed: int, fit, identity: dict, *,
                   load_only: bool = False) -> dict:
    """One Bayesian fit, kept under ``<out_dir>/checkpoints/`` once done (decision 87): a rerun with the same
    sampler and root seed loads it instead of refitting, so a stopped run loses at most the fit in progress.
    ``load_only`` raises ``MissingFit`` instead of fitting.  The identity file is replaced whole, so processes that
    share the folder (shards) never read it half-written."""
    if out_dir is None:
        return fit()
    import hashlib
    import pickle

    ckpt = Path(out_dir) / "checkpoints"
    ckpt.mkdir(parents=True, exist_ok=True)
    ident = json.loads(json.dumps(identity, default=str, sort_keys=True))
    idf = ckpt / "identity.json"
    if idf.exists() and json.loads(idf.read_text()) != ident:
        raise RuntimeError(f"{ckpt} holds fits made with other settings; resume with the same ones or move it away")
    tmp_id = ckpt / f"identity.json.{os.getpid()}.tmp"
    tmp_id.write_text(json.dumps(ident, indent=1, sort_keys=True))
    tmp_id.replace(idf)
    key = hashlib.sha256(f"{scenario}|{prior_set}|{spec.name}|{fit_seed}".encode()).hexdigest()[:24]
    f = ckpt / f"{key}.pkl"
    if f.exists():
        try:
            return pickle.loads(f.read_bytes())
        except Exception:                                           # noqa: BLE001 - a torn file is refitted
            pass
    if load_only:
        raise MissingFit(f"{scenario}, {prior_set}, {spec.name} (seed {fit_seed}): no checkpoint {f.name}")
    b = fit()
    tmp = ckpt / f"{key}.pkl.tmp"
    tmp.write_bytes(pickle.dumps(b, protocol=pickle.HIGHEST_PROTOCOL))
    tmp.replace(f)
    return b


def run(out_dir=None, *, scenarios: Sequence[str] = tuple(SCENARIOS), bayes_models="pilot",
        prior_sets: Sequence[str] = ("proposed",), recalibrated_models: Sequence[str] = ("true",),
        sampler: xc.Sampler = xc.Sampler(), seed: int = ROOT_SEED, with_r: bool = True,
        amendment: str | None = None, shard: tuple[int, int] | None = None, summarize_only: bool = False,
        reference_rule: str = DEFAULT_REFERENCE_RULE) -> dict:
    """Run check 3 and write ``results.json``, ``mle.csv`` and ``bayes.csv`` to ``out_dir`` (if given).

    ``bayes_models`` is "pilot" (independence, the true model, the richest), "all" (the 64) or names;
    "recalibrated" in ``prior_sets`` fits ``recalibrated_models`` with the recalibrated set as well.

    ``amendment`` (decision 122) gives every fitted model the amendment, under the recalibrated set only (``prior_sets``
    must be ("recalibrated",) and ``recalibrated_models`` chooses the models; "all" is the amended space), and compares
    each with its maximum-likelihood comparator (``amended_mle_table``, for the fitted models; no Rcapture).

    ``shard`` (i, k), 1 <= i <= k, fits only the fits ``in_shard`` of each scenario's list, keeps them as checkpoints in
    ``out_dir``, and writes ``shards/shard-<i>-of-<k>.json`` instead of a summary.  Each fit keeps the seed it has in
    the whole list, so k processes can share the folder.  ``summarize_only`` builds the summary from the checkpoints alone,
    as the whole run would, and refuses while any fit is missing.

    ``reference_rule`` (``REFERENCE_RULES``) says when an AM2 comparator serves as the reference: decision 125's, the
    default, or decision 127's, which is refused but for AM2 (``check_reference_rule``, before anything is simulated or
    fitted).  It changes no Bayesian fit, so the checkpoints' identity does not hold it; a summary applies it to the
    comparators, which are always computed again from the scenario's table (``summarize_only`` too).  Under decision
    127's rule, ``results.json`` records it and, per scenario, what it changes (``_amended_mle_summary``).
    """
    if amendment is not None:
        if amendment not in AMENDMENTS:
            raise ValueError(f"unknown amendment {amendment!r}; the amendments are {sorted(AMENDMENTS)}")
        if tuple(prior_sets) != (AMENDMENT_PRIOR_SET,):
            raise ValueError(f"the amendments' check 3 runs under the {AMENDMENT_PRIOR_SET} set only (decision 122); "
                             f"got {list(prior_sets)}")
    check_reference_rule(reference_rule, amendment)
    rule = {} if reference_rule == DEFAULT_REFERENCE_RULE else {"reference_rule": reference_rule}
    if shard is not None:
        if summarize_only or not (len(shard) == 2 and 1 <= int(shard[0]) <= int(shard[1])):
            raise ValueError(f"a shard is (i, k) with 1 <= i <= k, without summarize_only; got {shard}")
        if out_dir is None:
            raise ValueError("a shard keeps its fits in the run folder: give out_dir")
    if summarize_only and out_dir is None:
        raise ValueError("summarize_only reads the run folder's checkpoints: give out_dir")
    xc.quiet()
    space = model_space(xc.LISTS, xc.COVARIATES)
    sc_seeds = dict(zip(scenarios, xc.seeds(seed, len(scenarios))))
    result = {"check": "3: frequentist cross-check", "rule": {"median_within": MEDIAN_TOLERANCE,
              "mle_agreement": MLE_AGREEMENT}, "sampler": sampler.as_dict(), "root_seed": seed,
              "prior_sets": list(prior_sets), "scenarios": {}}
    identity = {"sampler": sampler.as_dict(), "seed": seed}
    if amendment is not None:            # an amended run never reads a frozen run's fits, nor the reverse
        result.update(amendment=amendment, comparator=COMPARATORS[amendment],
                      rcapture={"run": False, "reason": RCAPTURE_SKIPPED[amendment]})
        identity["amendment"] = amendment
    if rule:                              # decision 127 (d); not in the identity, since the rule changes no fit
        result.update(reference_rule=reference_rule, reference_valid_when=REFERENCE_RULES[reference_rule])
    all_bayes, all_mle, fitted, missing = [], [], [], []
    with xc.timed() as t_all:
        for name in scenarios:
            sc = SCENARIOS[name]
            sim = simulate(sc, sc_seeds[name])
            tab = sim["table"]
            fits = [(prior_set, spec if amendment is None else replace(spec, amendment=amendment))
                    for prior_set in prior_sets
                    for spec in select_models(sc, bayes_models if prior_set == "proposed" else recalibrated_models)]
            mle, by_name = [], {}
            if shard is None:
                with xc.timed() as t_mle:
                    mle = (mle_table(tab, space, with_r=with_r) if amendment is None
                           else amended_mle_table(tab, [spec for _, spec in fits], **rule))
                by_name = {r["model"]: r for r in mle}
            exposure = sim["expected_total"] / RECALIBRATED_RATE["E1"]
            bayes = []
            fit_seeds = iter(xc.seeds(sc_seeds[name] + 1, 512))
            for position, (prior_set, spec) in enumerate(fits):
                fit_seed = next(fit_seeds)       # drawn even for a resumed fit or another shard's: later seeds stay
                if shard is not None and not in_shard(position, shard):
                    continue
                try:
                    b = _resumable_fit(out_dir, name, prior_set, spec, fit_seed,    # own process: decision 88
                                       lambda: xc.in_fresh_process(bayes_fit, tab, spec, prior_set, sampler,
                                                                   fit_seed, exposure),
                                       identity=identity, load_only=summarize_only)
                except MissingFit as e:
                    missing.append(str(e))
                    continue
                fitted.append({"scenario": name, "prior_set": prior_set, "model": spec.name, "seed": fit_seed})
                if shard is not None:
                    continue
                ref = by_name[spec.name]["N_statsmodels"]
                rel = b["median"] / ref - 1
                bayes.append({"scenario": name, "model": spec.name, "prior_set": prior_set, "N_mle": ref,
                              **{k: v for k, v in b.items() if k != "gates"}, "rel_median_vs_mle": rel,
                              "pass": bool(abs(rel) <= MEDIAN_TOLERANCE), "gates_passed": b["gates"]["passed"],
                              "gate_failures": b["gates"]["failures"], "gate_metrics": b["gates"]["metrics"]})
            if shard is not None:
                continue
            result["scenarios"][name] = {
                "description": sc.description, "true_model": sc.true_spec.name, "n_observed": tab.n_observed,
                "N_true": sim["N_true"], "expected_completeness": sim["expected_completeness"],
                "min_cell": int(tab.counts.min()), "median_cell": float(np.median(tab.counts)),
                "seconds_mle_64_models": t_mle.seconds,
                **(_mle_summary(mle) if amendment is None else _amended_mle_summary(mle, amendment, **rule)),
                "bayes": bayes}
            all_bayes += bayes
            all_mle += [{"scenario": name, **r} for r in mle]
    if missing:
        raise RuntimeError(f"{len(missing)} fits are missing from {Path(out_dir) / 'checkpoints'}, so no summary is "
                           f"built (run the shards first): " + "; ".join(missing[:10]))
    if shard is not None:
        record = {"check": result["check"], **({"amendment": amendment} if amendment else {}), "shard": list(shard),
                  "fits": fitted, "seconds_total": t_all.seconds}
        xc.write_json(Path(out_dir) / "shards" / f"shard-{shard[0]}-of-{shard[1]}.json", record)
        return record
    result["passed"] = bool(all_bayes and all(b["pass"] for b in all_bayes)
                            and all(s["mle_all_agree"] for s in result["scenarios"].values()))
    result["n_bayes_fits"] = len(all_bayes)
    result["seconds_total"] = t_all.seconds
    result["provenance"] = xc.provenance(r=xc.r_versions() if with_r and xc.r_available() else None)
    if out_dir is not None:
        import pandas as pd

        xc.write_json(Path(out_dir) / "results.json", result)
        pd.DataFrame(all_mle).to_csv(Path(out_dir) / "mle.csv", index=False)
        pd.DataFrame([{k: v for k, v in b.items() if k not in ("gate_failures", "gate_metrics")} for b in all_bayes]).to_csv(
            Path(out_dir) / "bayes.csv", index=False)
    return result


def _mle_summary(mle: Sequence[Mapping]) -> dict:
    """The frozen check's summary of a scenario's maximum-likelihood table."""
    return {"mle_all_agree": all(r["mle_agree"] for r in mle),
            "rcapture_models": sum("N_rcapture" in r for r in mle),
            "max_rel_rcapture_vs_statsmodels": max((abs(r["rel_rcapture_vs_statsmodels"]) for r in mle
                                                    if "rel_rcapture_vs_statsmodels" in r), default=None),
            "max_rel_engine_vs_statsmodels": max(abs(r["rel_engine_vs_statsmodels"]) for r in mle)}


def _amended_mle_summary(mle: Sequence[Mapping], amendment: str, reference_rule: str = DEFAULT_REFERENCE_RULE) -> dict:
    """The summary of a scenario's amended comparators: both routes' agreement, and for AM2 the boundary fits.  Under
    decision 127's rule (AM2 only) also what the rule changes: the models whose reference is not valid, those
    statsmodels or the second route did not report converged, and the largest kappa difference between the routes
    relative to max(1, statsmodels' kappa), as the rule compares them (nan if any is nan)."""
    out = {"mle_models": len(mle), "mle_all_agree": all(r["mle_agree"] for r in mle), "rcapture_models": 0,
           "second_route": SECOND_ROUTE[amendment],
           "max_rel_second_route_vs_statsmodels": max((abs(r["rel_second_vs_statsmodels"]) for r in mle), default=None)}
    if amendment == AM2.id:
        out["kappa_boundary_models"] = sum(bool(r["kappa_boundary"]) for r in mle)
    if reference_rule != DEFAULT_REFERENCE_RULE:
        kappa = [abs(r["kappa_second"] - r["kappa_statsmodels"]) / max(1.0, r["kappa_statsmodels"]) for r in mle]
        out.update(references_not_valid=[r["model"] for r in mle if not r["mle_agree"]],
                   statsmodels_unconverged_models=[r["model"] for r in mle if not r["statsmodels_converged"]],
                   second_route_unconverged_models=[r["model"] for r in mle if not r["second_converged"]],
                   max_rel_kappa_second_route_vs_statsmodels=(
                       None if not kappa else math.nan if any(math.isnan(k) for k in kappa) else max(kappa)))
    return out


def parse_shard(text: str) -> tuple[int, int]:
    """"i/k" as (i, k), with 1 <= i <= k."""
    try:
        i, k = (int(x) for x in text.split("/"))
    except ValueError:
        raise argparse.ArgumentTypeError(f"a shard is i/k with 1 <= i <= k, not {text!r}") from None
    if not 1 <= i <= k:
        raise argparse.ArgumentTypeError(f"a shard is i/k with 1 <= i <= k, not {text!r}")
    return i, k


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--out", default=None,
                   help="default: the pilot folder check3-crosscheck (check3-crosscheck-<amendment> with --amendment)")
    p.add_argument("--models", default=None, help='"pilot", "all" or comma-separated model names; default "pilot", or '
                   '"all" (the amended space) with --amendment')
    p.add_argument("--prior-sets", default=None, help='default "proposed,recalibrated"; with --amendment '
                   '"recalibrated", the only set it takes')
    p.add_argument("--scenarios", default=",".join(SCENARIOS))
    p.add_argument("--draws", type=int, default=2000)
    p.add_argument("--tune", type=int, default=2000)
    p.add_argument("--chains", type=int, default=4)
    p.add_argument("--cores", type=int, default=xc.MAX_CORES)
    p.add_argument("--seed", type=int, default=ROOT_SEED)
    p.add_argument("--no-r", action="store_true")
    p.add_argument("--amendment", choices=sorted(AMENDMENTS), default=None,
                   help="fit the amended models against their maximum-likelihood comparators (decision 122)")
    p.add_argument("--shard", type=parse_shard, default=None,
                   help="i/k: fit only shard i of k of each scenario's models into OUT's checkpoints; no summary")
    p.add_argument("--summarize-only", action="store_true",
                   help="build the summary from the checkpoints in OUT (after the shards); refused while a fit is "
                        "missing")
    p.add_argument("--reference-rule", choices=list(REFERENCE_RULES), default=DEFAULT_REFERENCE_RULE,
                   help="when an AM2 comparator serves as the reference: decision-125 (the default: both routes "
                        "converge and agree) or decision-127 (AM2 only, decision 127 (d): statsmodels converges and "
                        "the routes agree; the second route's success flag is not required)")
    a = p.parse_args(argv)
    if a.reference_rule != DEFAULT_REFERENCE_RULE and a.amendment != AM2.id:
        p.error(f"--reference-rule {a.reference_rule} is decision 127's for AM2's check 3 only: give --amendment AM2")
    out = a.out or str(xc.pilot_dir("check3-crosscheck" if a.amendment is None else f"check3-crosscheck-{a.amendment}"))
    models = a.models or ("pilot" if a.amendment is None else "all")
    models = models if models in ("pilot", "all") else models.split(",")
    sampler = xc.Sampler(a.chains, a.draws, a.tune, cores=a.cores)
    if a.amendment is None:
        kw = dict(scenarios=a.scenarios.split(","), bayes_models=models,
                  prior_sets=(a.prior_sets or "proposed,recalibrated").split(","), sampler=sampler, seed=a.seed,
                  with_r=not a.no_r)
    else:
        kw = dict(scenarios=a.scenarios.split(","), prior_sets=(a.prior_sets or AMENDMENT_PRIOR_SET).split(","),
                  recalibrated_models=models, sampler=sampler, seed=a.seed, with_r=not a.no_r, amendment=a.amendment)
    if a.shard is not None:
        kw["shard"] = a.shard
    if a.summarize_only:
        kw["summarize_only"] = True
    if a.reference_rule != DEFAULT_REFERENCE_RULE:
        kw["reference_rule"] = a.reference_rule
    res = run(out, **kw)
    if "shard" in res:
        print(f"check 3, shard {res['shard'][0]} of {res['shard'][1]}: {len(res['fits'])} Bayesian fits; "
              f"{res['seconds_total']:.0f} s; checkpoints in {out}")
        return
    print(f"check 3 {'PASSED' if res['passed'] else 'FAILED'}; {res['n_bayes_fits']} Bayesian fits; "
          f"{res['seconds_total']:.0f} s; written to {out}")


if __name__ == "__main__":
    main()
