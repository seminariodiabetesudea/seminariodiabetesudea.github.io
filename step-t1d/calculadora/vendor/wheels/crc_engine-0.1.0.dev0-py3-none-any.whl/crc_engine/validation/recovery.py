"""Phase 4, check 1: recovery of N on simulated data.

For each scenario (``_core_sim.SCENARIOS``) and replicate the check:

1. draws a dataset from the scenario's fixed truth: 60 stratum-years shaped like the E1 cohort, every cell a
   Poisson count, so the realised N = n + hidden is known (``_core_sim.simulate``);
2. fits the 8 dependence structures under the truth's covariate setting with short NUTS chains (nutpie,
   ``_core_fit.SHORT_SAMPLER``), each the analysis plan's PyMC model (``models.build_structured_model``,
   non-centred form) with the chosen prior set, one compile per structure (``_core_fit``);
3. weights the 8 models (uniform model prior) by their marginal likelihoods and pools their draws of N
   (``models.posterior_N``) as a mixture, never averaging point estimates;
4. records whether the BMA 95% equal-tailed interval covers the true N, and the relative bias of the BMA
   median.

Weights.  The full-space Laplace approximation of these hierarchical models was 35 log units below SMC in a
probe, and importance sampling from a t fitted to the draws had Pareto k-hat about 1, so neither can carry the
weights.  The 8 structures are nested in the all-pairs model, with the same priors on every shared term and
independent Normal priors on the pairs, so only Bayes factors against the all-pairs model are needed.  The
main weights bridge the all-pairs posterior and each sub-model's posterior, both fitted by NUTS to the same
dataset (``_core_evidence.nested_bridge``: Meng & Wong 1996, warp-II of Meng & Schilling 2002): the sub-model's
draws are saved in stage 1 and the all-pairs fit (stage 2) evaluates its own log density on them.  Reported beside them: the bridge's forward
half alone, the Savage-Dickey density ratio from the all-pairs draws ("sd", ``_core_evidence.savage_dickey``);
differences of full-space Laplace approximations ("laplace"); and, on a seeded 10% subset of replicates, SMC
marginal likelihoods ("smc", ``crc_engine.marginal.smc_log_marginal_likelihood``) as a diagnostic only.  The
yardstick on that subset is bridge sampling of each model on a fresh NUTS fit
(``crc_engine.marginal.bridge_log_marginal_likelihood``), because check 4 found SMC biased on the structured
models.  Each structure's own Savage-Dickey ratios for its sub-models are checked against the main weights
(routes).

Pass rule (build plan, Phase 4): where the truth is in the model space, BMA 95% CrI coverage 90-98% and
mean relative bias within +-5%.  Misspecified scenarios are reported as found, never tuned away.

The amendments (decision 122, ``docs/amendments/decision-122/``).  ``--amendment AM1`` or ``AM2`` gives each of the 8
structures the amendment, in the stage, bridge and reference fits alike.  Its default scenarios
(``AMENDMENT_RUN_SCENARIOS``) are the frozen space's four in-space ones, the scenario that exercises the amendment's
term (AM1: ``list-by-year``, inside AM1's space; AM2: ``cohort-like-nb1``, every cell NB1 at kappa = 1) and decision
91's dense variant ``sparse-low-at-study-density``.  Whether a truth is in the space follows the amendment
(``_core_sim.Scenario.in_space_under``), and so does the pass rule's reach.  The root seed is the frozen run's, so a
scenario both runs share has the same datasets (a paired comparison).  The summary records the amendment, each
scenario's in-space flag and the amendment's verdict under decision 123 (``amendment_rule``).  Without an amendment a
run is the frozen one.

Run: ``python -m crc_engine.validation.recovery --out <folder> [--scenarios ...] [--replicates 5] [--amendment AM1]``.
Everything is simulated; nothing reads study data.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import os
import platform
import subprocess
import sys
import time
import zlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Mapping, Sequence

import numpy as np

from ..amendments import AMENDMENTS
from ..modelspace import ModelSpec
from ._core_fit import SHORT_SAMPLER, fit_many, limit_threads, pair_label, resolve_priors
from ._core_sim import (AGE_BANDS, AMENDMENT_SCENARIOS, LISTS, PERIODS, SCENARIOS, SEXES, YEARS, SimData, Truth,
                        find_scenario, make_truth, simulate, study_table, synthetic_person_years)

LEVEL = 0.95
PASS_COVERAGE = (0.90, 0.98)
PASS_REL_BIAS = 0.05
PILOT_SCENARIOS = ("cohort-like", "sparse-low", "latent-hard-to-reach")
#: The frozen space's in-space scenarios, which every amendment's check 1 runs again (decision 122, step 3).
_IN_SPACE = ("cohort-like", "sparse-low", "large-complete", "independent-mid")
#: Each amendment's scenarios: the four above, the scenario that exercises the amendment's term, and decision 91's
#: dense variant of sparse-low, on which decision 123 judges sparse-low.
AMENDMENT_RUN_SCENARIOS = {"AM1": _IN_SPACE + ("list-by-year", "sparse-low-at-study-density"),
                           "AM2": _IN_SPACE + ("cohort-like-nb1", "sparse-low-at-study-density")}
#: The scenario decision 123 reports beside the frozen space's result instead of requiring it to pass.
REPORTED_ONLY = "sparse-low"
#: Weighting methods, in the order they are reported.  "bridge" is the main one; "sd" its forward half.
METHODS = ("bridge", "sd", "laplace", "smc")
#: Savage-Dickey consistency: log ratios are compared between models that both carry this weight.
ROUTE_WEIGHT_MIN = 0.01
FULL_REPLICATES = 100


# --------------------------------------------------------------------------- small pieces
def seed_for(root: int, *parts) -> int:
    """A 32-bit seed from the root seed and labels (stable when other scenarios or models are added)."""
    key = [int(root)] + [zlib.crc32(str(p).encode()) for p in parts]
    return int(np.random.SeedSequence(key).generate_state(1)[0])


def dependence_structures(covariates: Sequence[str], amendment: str | None = None) -> list[ModelSpec]:
    """The 8 dependence structures (independence, one pair, two pairs, all pairs) under one covariate setting, each
    with ``amendment`` (decision 122) when one is given."""
    pairs = list(itertools.combinations(LISTS, 2))
    return [ModelSpec(LISTS, frozenset(p), tuple(covariates), amendment=amendment)
            for k in range(len(pairs) + 1) for p in itertools.combinations(pairs, k)]


def _check_amendment(amendment: str | None) -> None:
    if amendment is not None and amendment not in AMENDMENTS:
        raise ValueError(f"unknown amendment {amendment!r}; the amendments are {sorted(AMENDMENTS)}")


def weights_from_log_ml(log_ml: Mapping[str, float], prior: Mapping[str, float] | None = None) -> dict[str, float]:
    """Posterior model probabilities from (relative) log marginal likelihoods; a NaN gets weight zero."""
    names = list(log_ml)
    a = np.array([log_ml[n] for n in names], float)
    if prior is not None:
        a = a + np.log(np.array([prior[n] for n in names], float))
    ok = np.isfinite(a)
    if not ok.any():
        return {n: float("nan") for n in names}
    a = np.where(ok, a - a[ok].max(), -np.inf)
    w = np.exp(a)
    return dict(zip(names, (w / w.sum()).tolist()))


def mixture_quantiles(draws: Sequence[np.ndarray], weights: Sequence[float], qs: Sequence[float]) -> np.ndarray:
    """Quantiles of the mixture sum_k w_k F_k, F_k the empirical distribution of ``draws[k]``.

    The exact limit of drawing from each model in proportion to its weight; inverse-CDF convention (the
    smallest value whose mixture CDF reaches q).
    """
    vals = np.concatenate([np.asarray(d, float).ravel() for d in draws])
    w = np.concatenate([np.full(np.size(d), wk / np.size(d)) for d, wk in zip(draws, weights)])
    order = np.argsort(vals, kind="stable")
    vals, cw = vals[order], np.cumsum(w[order])
    cw /= cw[-1]
    idx = np.searchsorted(cw, np.asarray(qs, float) - 1e-12, side="left")
    return vals[np.minimum(idx, len(vals) - 1)]


def bma_summary(N_draws: Mapping[str, np.ndarray], weights: Mapping[str, float], N_true: int,
                level: float = LEVEL) -> dict:
    """Median, equal-tailed interval and mean of the BMA mixture of N; coverage and relative bias."""
    names = [n for n in N_draws if np.isfinite(weights.get(n, np.nan)) and weights[n] > 0]
    if not names:
        return {"median": float("nan"), "lower": float("nan"), "upper": float("nan"), "mean": float("nan"),
                "covered": False, "rel_bias": float("nan"), "rel_width": float("nan")}
    a = (1.0 - level) / 2.0
    lo, med, hi = mixture_quantiles([N_draws[n] for n in names], [weights[n] for n in names], [a, 0.5, 1 - a])
    mean = float(sum(weights[n] * np.mean(N_draws[n]) for n in names) / sum(weights[n] for n in names))
    return {"median": float(med), "lower": float(lo), "upper": float(hi), "mean": mean,
            "covered": bool(lo <= N_true <= hi), "rel_bias": float((med - N_true) / N_true),
            "rel_width": float((hi - lo) / N_true)}


def clopper_pearson(k: int, n: int, level: float = 0.95) -> tuple[float, float]:
    from scipy.stats import beta

    a = (1.0 - level) / 2.0
    lo = 0.0 if k == 0 else float(beta.ppf(a, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1 - a, k + 1, n - k))
    return lo, hi


def scenario_verdict(rows: Sequence[Mapping], method: str, in_space: bool) -> dict:
    """Coverage and bias of one scenario under one weighting method, with the pass rule."""
    rows = [r for r in rows if np.isfinite(r.get(f"{method}_median", np.nan))]
    n = len(rows)
    if n == 0:
        return {"replicates": 0}
    k = int(sum(bool(r[f"{method}_covered"]) for r in rows))
    rb = np.array([r[f"{method}_rel_bias"] for r in rows], float)
    cov = k / n
    lo, hi = clopper_pearson(k, n)
    out = {"replicates": n, "covered": k, "coverage": cov, "coverage_ci95": [lo, hi],
           "mean_rel_bias": float(rb.mean()), "rel_bias_se": float(rb.std(ddof=1) / math.sqrt(n)) if n > 1 else None,
           "median_rel_bias": float(np.median(rb)),
           "mean_rel_width": float(np.mean([r[f"{method}_rel_width"] for r in rows]))}
    if in_space:
        ok_cov = PASS_COVERAGE[0] <= cov <= PASS_COVERAGE[1]
        ok_bias = abs(out["mean_rel_bias"]) <= PASS_REL_BIAS
        out.update(rule_coverage=bool(ok_cov), rule_bias=bool(ok_bias), passed=bool(ok_cov and ok_bias),
                   # can the coverage window be met at all with this many replicates?
                   coverage_rule_attainable=any(PASS_COVERAGE[0] <= j / n <= PASS_COVERAGE[1] for j in range(n + 1)))
    else:
        out["passed"] = None            # misspecified: reported as found
    return out


def amendment_rule(verdicts: Mapping[str, Mapping], amendment: str) -> dict:
    """An amendment's check 1 verdict (decision 122, step 3; decision 123), on the main weights (bridge).

    Every scenario of the amendment's run but sparse-low must pass check 1's rule: the frozen space's other in-space
    scenarios, the amendment's new scenario and decision 91's dense variant of sparse-low.  sparse-low is reported
    beside the frozen space's result: its failure is decision 96's limitation and does not fail the amendment, which
    the dense variant's rule then decides.  ``passed`` is None while a required scenario has not been run.
    """
    required = [s for s in AMENDMENT_RUN_SCENARIOS[amendment] if s != REPORTED_ONLY]
    missing = [s for s in required if s not in verdicts]
    failed = [s for s in required if s in verdicts and verdicts[s]["bridge"].get("passed") is not True]
    return {"decisions": [122, 123], "weights": "bridge", "required": required, "reported_only": [REPORTED_ONLY],
            "sparse_low_passed": verdicts.get(REPORTED_ONLY, {}).get("bridge", {}).get("passed"),
            "missing": missing, "failed": failed, "passed": None if missing else not failed}


def scenario_record(name: str, amendment: str | None = None) -> dict:
    """A scenario's configuration record; with an amendment its in-space flag is the amended space's."""
    sc = find_scenario(name)
    return sc.as_dict() if amendment is None else {**sc.as_dict(), "in_space": sc.in_space_under(amendment)}


def environment() -> dict:
    import importlib.metadata as md

    vers = {}
    for p in ("pymc", "pytensor", "nutpie", "numpy", "scipy", "arviz", "arviz-stats", "crc-engine"):
        try:
            vers[p] = md.version(p)
        except md.PackageNotFoundError:
            vers[p] = None
    try:
        sha = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True, timeout=10,
                             cwd=Path(__file__).resolve().parent).stdout.strip() or None
        dirty = bool(subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True, timeout=10,
                                    cwd=Path(__file__).resolve().parent).stdout.strip())
    except Exception:            # noqa: BLE001 - git is optional
        sha, dirty = None, None
    return {"python": sys.version.split()[0], "packages": vers, "git_sha": sha, "git_dirty": dirty,
            "machine_cores": os.cpu_count(), "platform": platform.platform()}


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (set, frozenset, tuple)):
        return list(o)
    raise TypeError(type(o))


def write_json(path: Path, obj) -> None:
    path.write_text(json.dumps(obj, indent=2, default=_json_default, allow_nan=True) + "\n")


def _checkpoint_ready(checkpoint: Path, identity: Mapping | None) -> None:
    """Create ``checkpoint`` and pin it to the run's ``identity``; refuse a folder made under another identity."""
    checkpoint.mkdir(parents=True, exist_ok=True)
    f = checkpoint / "identity.json"
    ident = json.loads(json.dumps(identity or {}, default=str, sort_keys=True))
    if f.exists():
        old = json.loads(f.read_text())
        if old != ident:
            raise RuntimeError(f"{checkpoint} holds jobs of a run with other settings; resume with the same settings "
                               f"or move the folder away (stored {old}, now {ident})")
    else:
        f.write_text(json.dumps(ident, indent=1, sort_keys=True))


def run_pool(jobs: Sequence[Mapping], fn: Callable, workers: int, log: Callable = print, *,
             checkpoint: Path | None = None, identity: Mapping | None = None) -> list:
    """Run ``fn`` on every job in ``workers`` spawned processes (one thread each); results in job order.

    Each job gets a fresh process (decision 88): a process keeps every model it has compiled, about 80 MB each,
    until it exits, so long-lived workers grew to 3.6 GB each in the first full run.

    With ``checkpoint`` (decision 87), each finished job's result is written to ``<checkpoint>/<index>.pkl`` as it
    arrives, and a rerun with the same ``identity`` (the settings that fix the job list) loads those and runs only
    the rest, so a stopped run loses minutes, not hours.
    """
    import multiprocessing as mp
    import pickle
    from concurrent.futures import ProcessPoolExecutor, as_completed

    limit_threads(1)                    # inherited by the spawned workers
    out = [None] * len(jobs)
    todo = list(range(len(jobs)))
    if checkpoint is not None:
        _checkpoint_ready(checkpoint, identity)
        done_before = []
        for i in range(len(jobs)):
            f = checkpoint / f"{i:05d}.pkl"
            if f.exists():
                try:
                    out[i] = pickle.loads(f.read_bytes())
                    done_before.append(i)
                except Exception:                                   # noqa: BLE001 - a torn file is rerun
                    pass
        todo = [i for i in todo if i not in set(done_before)]
        if done_before:
            log(f"  resumed {len(done_before)} of {len(jobs)} jobs from {checkpoint}")

    def keep(i: int, result) -> None:
        out[i] = result
        if checkpoint is not None:
            tmp = checkpoint / f"{i:05d}.pkl.tmp"
            tmp.write_bytes(pickle.dumps(result, protocol=pickle.HIGHEST_PROTOCOL))
            tmp.replace(checkpoint / f"{i:05d}.pkl")

    n_done = len(jobs) - len(todo)
    if workers <= 1:
        for i in todo:
            keep(i, fn(jobs[i]))
            n_done += 1
            log(f"  job {n_done}/{len(jobs)} done")
        return out
    if todo:
        with ProcessPoolExecutor(max_workers=workers, mp_context=mp.get_context("spawn"),
                                 max_tasks_per_child=1) as ex:
            futs = {ex.submit(fn, jobs[i]): i for i in todo}
            for f in as_completed(futs):
                keep(futs[f], f.result())
                n_done += 1
                log(f"  job {n_done}/{len(jobs)} done")
    return out


# --------------------------------------------------------------------------- reference on a subset
#: NUTS settings of the reference fits whose draws feed ``marginal.bridge_log_marginal_likelihood``.
REFERENCE_SAMPLER = {"chains": 4, "tune": 1000, "draws": 1000, "target_accept": 0.9}


def subset_keys(keys, fraction: float, root_seed: int) -> list[tuple[str, int]]:
    """The seeded subset of replicates (at least one) checked against the reference marginal likelihoods."""
    keys = sorted(keys)
    m = max(1, math.ceil(fraction * len(keys)))
    rng = np.random.default_rng(seed_for(root_seed, "smc-subset"))
    return [keys[i] for i in sorted(rng.choice(len(keys), size=m, replace=False))]


def bridge_reference_job(job: Mapping) -> dict:
    """Worker: a fresh NUTS fit of one structure on one dataset and its bridge-sampling log marginal likelihood
    (``crc_engine.marginal.bridge_log_marginal_likelihood``), the yardstick for the subset."""
    limit_threads(1)
    import warnings

    warnings.filterwarnings("ignore")
    import pymc as pm

    from ..marginal import bridge_log_marginal_likelihood
    from ..models import build_structured_model
    from ..tables import CaptureTable

    t0 = time.perf_counter()
    table = CaptureTable.empty(job["lists"], job["table_levels"]).with_counts(job["counts"])
    pri = resolve_priors(job["prior_name"])
    sm = build_structured_model(table, job["spec"], pri, periods=job["periods"],
                                exposure=job["exposure"] if pri.count_target == "total" else None, noncentred=True)
    smp = job["sampler"]
    with sm.model:
        idata = pm.sample(draws=smp["draws"], tune=smp["tune"], chains=smp["chains"], cores=1,
                          target_accept=smp["target_accept"], random_seed=job["seed"], progressbar=False,
                          compute_convergence_checks=False, nuts_sampler="nutpie")
    t1 = time.perf_counter()
    b = bridge_log_marginal_likelihood(sm.model, idata, random_seed=job["seed"])
    ss = idata["sample_stats"]
    return {"key": job["key"], "label": pair_label(job["spec"].pairs), "spec": job["spec"].name, "log_ml": b.log_ml,
            "cv": b.cv, "converged": b.converged, "n_eff": b.n_eff, "n_nonfinite": b.n_nonfinite,
            "divergences": int(np.asarray(ss["diverging"].values).sum()) if "diverging" in ss else None,
            "seconds_fit": t1 - t0, "seconds_bridge": time.perf_counter() - t1}


def run_reference_subset(keys, data, prior_name, exposure, root_seed, workers, log, sampler=None, *,
                         checkpoint: Path | None = None, identity: Mapping | None = None,
                         amendment: str | None = None) -> list[dict]:
    """Reference log marginal likelihoods of the 8 structures (each with ``amendment``) on each replicate in
    ``keys``."""
    jobs = []
    for key in keys:
        for spec in dependence_structures(find_scenario(key[0]).covariates, amendment):
            jobs.append({**_job_template(prior_name, exposure, sampler or REFERENCE_SAMPLER), "key": list(key),
                         "counts": data[key].counts, "spec": spec,
                         "seed": seed_for(root_seed, "reference", key[0], key[1], spec.name)})
    log(f"recovery: bridge-sampling reference on {len(keys)} replicates ({len(jobs)} NUTS fits)")
    return run_pool(jobs, bridge_reference_job, workers, log, checkpoint=checkpoint, identity=identity)


def write_reference(out: Path, results: Sequence[Mapping]) -> None:
    import pandas as pd

    pd.DataFrame([{**{k: v for k, v in r.items() if k != "key"}, "scenario": r["key"][0],
                   "replicate": int(r["key"][1])} for r in results]).to_csv(out / "reference_subset.csv", index=False)


def reference_only(out_dir: str | Path, *, workers: int = 4, log: Callable = print) -> dict:
    """Add the bridge-sampling reference to a finished run (same seeded subset as its SMC), then re-summarise."""
    out = Path(out_dir)
    cfg = json.loads((out / "config.json").read_text())
    table = study_table()
    exposure = synthetic_person_years(table)
    root = int(cfg["root_seed"])
    scen = list(cfg["scenarios"])
    keys = [(s, r) for s in scen for r in range(int(cfg["replicates"]))]
    chosen = subset_keys(keys, float(cfg["smc"]["fraction"]) or 0.1, root)
    truths = {s: make_truth(find_scenario(s), table, exposure) for s in {k[0] for k in chosen}}
    data = {k: simulate(truths[k[0]], np.random.default_rng(seed_for(root, "data", k[0], k[1]))) for k in chosen}
    write_reference(out, run_reference_subset(chosen, data, cfg["prior_set"], exposure, root, workers, log,
                                              amendment=cfg.get("amendment")))
    return summarize_recovery(out)


# --------------------------------------------------------------------------- SMC on a subset
def smc_job(job: Mapping) -> dict:
    """Worker: SMC log marginal likelihood of one structure on one dataset (``crc_engine.marginal``)."""
    limit_threads(1)
    import warnings

    warnings.filterwarnings("ignore")
    from ..marginal import smc_log_marginal_likelihood
    from ..models import build_structured_model
    from ..tables import CaptureTable

    t0 = time.perf_counter()
    table = CaptureTable.empty(job["lists"], job["table_levels"]).with_counts(job["counts"])
    pri = resolve_priors(job["prior_name"])
    sm = build_structured_model(table, job["spec"], pri, periods=job["periods"],
                                exposure=job["exposure"] if pri.count_target == "total" else None, noncentred=True)
    res = smc_log_marginal_likelihood(sm.model, draws=job["draws"], chains=job["chains"], cores=1,
                                      random_seed=job["seed"], keep_idata=False)
    return {"key": job["key"], "spec": job["spec"].name, "label": pair_label(job["spec"].pairs),
            "log_ml": res.log_ml, "per_chain": res.per_chain.tolist(), "stages": res.stages.tolist(),
            "spread": res.spread, "seconds": time.perf_counter() - t0}


# --------------------------------------------------------------------------- the check
def _job_template(prior_name: str, exposure: np.ndarray, sampler: Mapping, noncentred: bool = True) -> dict:
    return {"lists": LISTS, "table_levels": {"sex": SEXES, "age_band": AGE_BANDS, "year": YEARS},
            "exposure": exposure, "periods": PERIODS, "prior_name": prior_name, "noncentred": noncentred,
            "sampler": dict(sampler)}


def run_recovery(out_dir: str | Path, *, scenarios: Sequence[str] | None = None, replicates: int = 5,
                 prior_name: str = "recalibrated", root_seed: int = 20261102, workers: int = 4,
                 sampler: Mapping | None = None, smc_fraction: float = 0.1, smc_draws: int = 2000,
                 smc_chains: int = 4, importance_draws: int = 0, chunk: int | None = None,
                 noncentred: bool = True, keep_unconstrained: bool = False, reference_sampler: Mapping | None = None,
                 run_smc: bool = True, amendment: str | None = None, log: Callable = print) -> dict:
    """Run check 1 and write its machine-readable results to ``out_dir``; returns the summary.

    ``scenarios`` defaults to ``PILOT_SCENARIOS``.  With ``amendment`` (decision 122) every structure is fitted with
    it, and the default is the amendment's ``AMENDMENT_RUN_SCENARIOS``.
    """
    _check_amendment(amendment)
    if scenarios is None:
        scenarios = PILOT_SCENARIOS if amendment is None else AMENDMENT_RUN_SCENARIOS[amendment]
    t_start = time.perf_counter()
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    out = Path(out_dir)
    (out / "draws").mkdir(parents=True, exist_ok=True)
    sampler = dict(SHORT_SAMPLER, **(sampler or {}))
    resolve_priors(prior_name)
    table = study_table()
    exposure = synthetic_person_years(table)
    truths: dict[str, Truth] = {s: make_truth(find_scenario(s), table, exposure) for s in scenarios}
    data: dict[tuple[str, int], SimData] = {
        (s, r): simulate(truths[s], np.random.default_rng(seed_for(root_seed, "data", s, r)))
        for s in scenarios for r in range(replicates)}

    # ---- NUTS fits.  Stage 1: the 7 sub-models of the all-pairs model, their unconstrained draws saved.
    # Stage 2: the all-pairs model, bridged to every sub-model fitted to the same dataset.
    udir = out / "unconstrained"
    udir.mkdir(exist_ok=True)
    # decision 87: every finished job is kept under checkpoints/, so a stopped run resumes where it stopped; the
    # identity holds every setting that fixes the job lists (the workers too: they size stage 2's chunks)
    ckpt = out / "checkpoints"
    identity = {"scenarios": list(scenarios), "replicates": replicates, "prior": prior_name, "seed": root_seed,
                "sampler": sampler, "chunk": chunk, "noncentred": noncentred, "importance_draws": importance_draws,
                "smc_fraction": smc_fraction, "reference_sampler": reference_sampler}
    if chunk is None:                   # stage 2's chunks then depend on the workers, so a resume needs the same
        identity["workers"] = workers
    if amendment is not None:           # an amended run never resumes a frozen run's jobs, nor the reverse
        identity["amendment"] = amendment
    by_cov: dict[tuple, list[str]] = {}
    for s in scenarios:
        by_cov.setdefault(tuple(find_scenario(s).covariates), []).append(s)

    def datasets(names, spec):
        return [{"key": [s, r], "counts": data[(s, r)].counts, "seed": seed_for(root_seed, "fit", s, r, spec.name)}
                for s in names for r in range(replicates)]

    def chunks(ds, size):
        return [ds[i:i + size] for i in range(0, len(ds), size)]

    stage1 = []
    for cov, names in by_cov.items():
        for spec in dependence_structures(cov, amendment)[:-1]:
            ds = datasets(names, spec)
            for part in chunks(ds, chunk or len(ds)):
                stage1.append({**_job_template(prior_name, exposure, sampler, noncentred), "spec": spec,
                               "evidence": True, "importance_draws": importance_draws,
                               "save_unconstrained": str(udir), "datasets": part})
    n_fits = len(scenarios) * replicates * 8
    log(f"recovery: {len(scenarios)} scenarios x {replicates} replicates x 8 structures = {n_fits} fits; "
        f"stage 1: {len(stage1)} jobs on {workers} workers")
    results1 = run_pool(stage1, fit_many, workers, log, checkpoint=ckpt / "stage1", identity=identity)
    layouts = {(tuple(j["spec"].list_covariates), r["label"]): r["layout"] for j, r in zip(stage1, results1)}
    stage2 = []
    for cov, names in by_cov.items():
        full_spec = dependence_structures(cov, amendment)[-1]
        bridge_from = {pair_label(sp.pairs): {"dir": str(udir), "layout": layouts[(cov, pair_label(sp.pairs))]}
                       for sp in dependence_structures(cov, amendment)[:-1]}
        ds = datasets(names, full_spec)
        for part in chunks(ds, chunk or max(1, math.ceil(len(ds) / workers))):
            stage2.append({**_job_template(prior_name, exposure, sampler, noncentred), "spec": full_spec,
                           "evidence": True, "importance_draws": importance_draws, "bridge_from": bridge_from,
                           "datasets": part})
    log(f"recovery: stage 2 (all pairs, bridges): {len(stage2)} jobs")
    results = results1 + run_pool(stage2, fit_many, workers, log, checkpoint=ckpt / "stage2", identity=identity)
    if not keep_unconstrained:
        for f in udir.glob("u_*.npy"):
            f.unlink()
        udir.rmdir()

    fits: dict[tuple[str, int], dict[str, dict]] = {}
    compile_secs, job_secs = [], []
    for res in results:
        compile_secs.append(res["compile_seconds"] + res.get("jit_seconds", 0.0))
        job_secs.append(res["job_seconds"])
        for rec in res["results"]:
            key = (rec["key"][0], int(rec["key"][1]))
            fits.setdefault(key, {})[res["label"]] = {**rec, "spec": res["spec"],
                                                      "compile_seconds": res["compile_seconds"],
                                                      "jit_seconds": res.get("jit_seconds", 0.0)}

    # ---- per replicate: weights, BMA, coverage
    labels = [pair_label(sp.pairs) for sp in dependence_structures(())]
    full = labels[-1]
    rows, fit_rows, routes = [], [], []
    for (s, r), by in sorted(fits.items()):
        sim, sc = data[(s, r)], find_scenario(s)
        in_space = sc.in_space_under(amendment)
        N_draws = {lab: by[lab]["N"] for lab in labels}
        sd_all, br = by[full]["savage_dickey"], by[full]["bridge"]
        rel = {"bridge": {lab: 0.0 if lab == full else br[lab]["log_bf"] for lab in labels},
               "sd": {lab: 0.0 if lab == full else sd_all[lab]["log_bf"] for lab in labels},
               "laplace": {lab: by[lab]["laplace"]["log_ml"] - by[full]["laplace"]["log_ml"] for lab in labels}}
        w = {m: weights_from_log_ml(v) for m, v in rel.items()}
        tl = pair_label(sc.spec.pairs) if in_space else None
        row = {"scenario": s, "replicate": r, "in_space": in_space, "N_true": sim.N, "n": sim.n,
               "true_structure": tl, "_rel": rel, "_w": w}
        for m in ("bridge", "sd", "laplace"):
            row.update({f"{m}_{k}": v for k, v in bma_summary(N_draws, w[m], sim.N).items()})
            row[f"{m}_top"] = max(w[m], key=w[m].get)
        if tl is not None:                                   # the true structure alone (an oracle, for context)
            row.update({f"true_model_{k}": v for k, v in bma_summary({tl: N_draws[tl]}, {tl: 1.0}, sim.N).items()})
            row["bridge_weight_true"] = w["bridge"][tl]
        # consistency: each structure's own Savage-Dickey ratios for its sub-models against the main (bridge)
        # weights.  Between models that both carry weight the log ratios are compared; for every route, the weight
        # the sub-model would get from it instead (w_fitted x |e^own - e^main|, capped at 1) is reported.
        gaps, wgaps = [], []
        for lab in labels:
            for sub, v in by[lab].get("savage_dickey", {}).items():
                via = rel["bridge"][sub] - rel["bridge"][lab]
                wgap = min(1.0, w["bridge"][lab] * abs(math.exp(min(v["log_bf"], 50.0)) - math.exp(min(via, 50.0))))
                routes.append({"scenario": s, "replicate": r, "fitted": lab, "sub_model": sub,
                               "log_bf_own_route": v["log_bf"], "log_bf_main": via, "khat": v["khat"],
                               "rel_mcse": v["rel_mcse"], "weight_fitted": w["bridge"][lab],
                               "weight_sub_model": w["bridge"][sub], "weight_gap": wgap,
                               **({"bridge_forward": br[sub]["log_bf_forward"], "bridge_reverse": br[sub]["log_bf_reverse"],
                                   "khat_forward": br[sub]["khat_forward"], "khat_reverse": br[sub]["khat_reverse"]}
                                  if lab == full else {})})
                if lab == full:
                    continue
                wgaps.append(wgap)
                if min(w["bridge"][sub], w["bridge"][lab]) >= ROUTE_WEIGHT_MIN:
                    gaps.append(abs(v["log_bf"] - via))
        row["sd_route_gap_max"] = float(max(gaps, default=0.0))
        row["sd_route_weight_gap_max"] = float(max(wgaps, default=0.0))
        heavy = [lab for lab in labels[:-1] if w["bridge"][lab] >= ROUTE_WEIGHT_MIN]
        row["bridge_khat_forward_max"] = float(max((br[lab]["khat_forward"] for lab in heavy), default=0.0))
        row["bridge_khat_reverse_max"] = float(max((br[lab]["khat_reverse"] for lab in heavy), default=0.0))
        row["bridge_vs_forward_max"] = float(max((abs(br[lab]["log_bf"] - br[lab]["log_bf_forward"]) for lab in heavy),
                                                 default=0.0))
        row["bridge_vs_reverse_max"] = float(max((abs(br[lab]["log_bf"] - br[lab]["log_bf_reverse"]) for lab in heavy),
                                                 default=0.0))
        rows.append(row)
        np.savez_compressed(out / "draws" / f"N_{s}_r{r:03d}.npz",
                            **{lab: N_draws[lab].astype(np.int32) for lab in labels},
                            N_true=np.int64(sim.N), n=np.int64(sim.n))
        for lab in labels:
            f, g = by[lab], by[lab]["gates"]
            q = np.quantile(f["N"], [0.025, 0.5, 0.975])
            fit_rows.append({
                "scenario": s, "replicate": r, "structure": lab, "spec": f["spec"], "seed": f["seed"], "n": sim.n,
                "N_true": sim.N, "N_lower": q[0], "N_median": q[1], "N_upper": q[2],
                "bridge_rel_log_ml": rel["bridge"][lab], "bridge_weight": w["bridge"][lab],
                "sd_rel_log_ml": rel["sd"][lab], "sd_weight": w["sd"][lab],
                "laplace_log_ml": f["laplace"]["log_ml"], "laplace_converged": f["laplace"]["converged"],
                "laplace_weight": w["laplace"][lab],
                "importance_log_ml": f.get("importance", {}).get("log_ml"),
                "importance_khat": f.get("importance", {}).get("khat"),
                **{k: g.get(k) for k in ("rhat_max", "ess_bulk_min", "ess_tail_min", "rhat_N", "ess_bulk_N",
                                         "ess_tail_N", "divergences", "ebfmi_min", "treedepth_frac",
                                         "rhat_unconstrained_max", "ess_bulk_unconstrained_min", "gates_passed")},
                **{k: f.get(k) for k in ("seconds_sample", "seconds_gates", "seconds_savage_dickey", "seconds_laplace",
                                         "seconds_importance", "seconds_total", "compile_seconds",
                                         "jit_seconds")}})

    # ---- SMC on a seeded subset of replicates
    smc = (run_smc_subset(rows, data, prior_name, exposure, root_seed, smc_fraction, smc_draws, smc_chains,
                          workers, log, amendment=amendment) if run_smc else {"status": "not run (skipped)"})
    if smc_fraction > 0:
        chosen = subset_keys({(r["scenario"], r["replicate"]) for r in rows}, smc_fraction, root_seed)
        write_reference(out, run_reference_subset(chosen, data, prior_name, exposure, root_seed, workers, log,
                                                  sampler=reference_sampler, checkpoint=ckpt / "reference",
                                                  identity=identity, amendment=amendment))
    for row in rows:
        key = (row["scenario"], row["replicate"])
        lm = smc.get("log_ml", {}).get(key)
        if lm is None:
            continue
        rel_smc = {lab: lm[lab] - lm[full] for lab in labels}
        w_smc = weights_from_log_ml(rel_smc)
        row["_rel"]["smc"], row["_w"]["smc"] = rel_smc, w_smc
        N_draws = {lab: fits[key][lab]["N"] for lab in labels}
        row.update({f"smc_{k}": v for k, v in bma_summary(N_draws, w_smc, row["N_true"]).items()})
        row["smc_top"] = max(w_smc, key=w_smc.get)
        for m in ("bridge", "sd", "laplace"):
            relevant = [lab for lab in labels if max(w_smc[lab], row["_w"][m][lab]) >= 0.01]
            row[f"{m}_vs_smc_log_bf_max"] = float(max(abs(row["_rel"][m][lab] - rel_smc[lab]) for lab in relevant))
            row[f"{m}_vs_smc_weight_tv"] = float(0.5 * sum(abs(row["_w"][m][lab] - w_smc[lab]) for lab in labels))

    # ---- write
    import pandas as pd

    flat = []
    for row in rows:
        f = {k: v for k, v in row.items() if not k.startswith("_")}
        for m, ws in row["_w"].items():
            f.update({f"{m}_w[{lab}]": v for lab, v in ws.items()})
        for m, rs in row["_rel"].items():
            f.update({f"{m}_rel_log_ml[{lab}]": v for lab, v in rs.items()})
        flat.append(f)
    pd.DataFrame(flat).to_csv(out / "replicates.csv", index=False)
    pd.DataFrame(fit_rows).to_csv(out / "fits.csv", index=False)
    pd.DataFrame(routes).to_csv(out / "savage_dickey_routes.csv", index=False)
    if smc.get("runs"):
        pd.DataFrame(smc["runs"]).to_csv(out / "smc_subset.csv", index=False)

    config = {"scenarios": {s: scenario_record(s, amendment) for s in scenarios}, "sampler": sampler,
              "noncentred": noncentred, "prior_set": prior_name, "root_seed": root_seed, "replicates": replicates,
              "workers": workers, "chunk": chunk, "smc": {"fraction": smc_fraction, "draws": smc_draws,
                                                         "chains": smc_chains},
              "importance_draws": importance_draws, "person_years": "synthetic (_core_sim.synthetic_person_years)",
              "environment": environment()}
    if amendment is not None:
        config["amendment"] = amendment
    write_json(out / "config.json", config)
    summary = summarize_recovery(out, timing_extra={"job_seconds": job_secs, "compile_seconds": compile_secs,
                                                    "wall_seconds": time.perf_counter() - t_start,
                                                    "started": started})
    log(f"recovery: wrote {out}")
    return summary


def summarize_recovery(out_dir: str | Path, timing_extra: Mapping | None = None) -> dict:
    """Compute ``summary.json`` from a run's written outputs (``config.json``, ``replicates.csv``, ``fits.csv``,
    ``smc_subset.csv``), so a summary can always be rebuilt from what is on disk."""
    import pandas as pd

    out = Path(out_dir)
    cfg = json.loads((out / "config.json").read_text())
    reps = pd.read_csv(out / "replicates.csv")
    fits = pd.read_csv(out / "fits.csv")
    rows = reps.to_dict("records")
    fit_rows = fits.to_dict("records")
    scenarios = list(cfg["scenarios"])
    amendment = cfg.get("amendment")
    in_space = {s: find_scenario(s).in_space_under(amendment) for s in scenarios}
    table = study_table()
    exposure = synthetic_person_years(table)
    extra = dict(timing_extra or {})
    smc = {"status": "not run"}
    if (out / "smc_subset.csv").exists():
        sm = pd.read_csv(out / "smc_subset.csv")
        smc = {"status": "run", "replicates": sorted({(r.scenario, int(r.replicate)) for r in sm.itertuples()}),
               "draws": cfg["smc"]["draws"], "chains": cfg["smc"]["chains"],
               "seconds_mean": float(sm["seconds"].mean()), "seconds_max": float(sm["seconds"].max()),
               "spread_max": float(sm["spread"].max()), "runs": len(sm)}
    compile_secs = extra.get("compile_seconds") or [
        float(c + j) for c, j in fits[["compile_seconds", "jit_seconds"]].drop_duplicates().itertuples(index=False)]
    verdicts = {}
    for s in scenarios:
        rs = [r for r in rows if r["scenario"] == s]
        verdicts[s] = {m: scenario_verdict(rs, m, in_space[s]) for m in METHODS}
        if in_space[s]:
            verdicts[s]["true_model_alone"] = scenario_verdict(rs, "true_model", True)
            verdicts[s]["mean_bridge_weight_on_true_structure"] = float(np.mean([r["bridge_weight_true"] for r in rs]))
    full_run = None if amendment is None else [find_scenario(s) for s in AMENDMENT_RUN_SCENARIOS[amendment]]
    timing = timing_summary(fit_rows, compile_secs, extra.get("job_seconds", []), smc, int(cfg["workers"]),
                            extra.get("wall_seconds"), scenarios=full_run)
    summary = {
        "check": "Phase 4 check 1: recovery on simulated data",
        **({} if amendment is None else {"amendment": amendment}),
        "started": extra.get("started"), "summarised": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "prior_set": cfg["prior_set"], "priors": resolve_priors(cfg["prior_set"]).name, "root_seed": cfg["root_seed"],
        "replicates": cfg["replicates"], "noncentred": cfg["noncentred"], "level": LEVEL,
        "weights_main": "bridge (all-pairs fit bridged to each sub-model's fit, warp-II); "
                        "'sd' = its forward half alone (Savage-Dickey from the all-pairs draws)",
        "pass_rule": {"coverage": PASS_COVERAGE, "abs_mean_rel_bias_max": PASS_REL_BIAS,
                      "applies_to": "scenarios whose truth is in the model space"},
        "scenarios": {s: {"in_space": in_space[s],
                          "expected_N": float(make_truth(find_scenario(s), table, exposure).expected_total.sum()),
                          "expected_completeness": make_truth(find_scenario(s), table, exposure).expected_completeness,
                          "true_structure": pair_label(find_scenario(s).spec.pairs) if in_space[s] else None,
                          "verdict": verdicts[s]} for s in scenarios},
        **({} if amendment is None else {"amendment_rule": amendment_rule(verdicts, amendment)}),
        "bridge": {k: float(np.nanmax([r[f"bridge_{k}"] for r in rows])) for k in
                   ("khat_forward_max", "khat_reverse_max", "vs_forward_max", "vs_reverse_max")},
        "savage_dickey_routes": {
            "gap_max": float(np.nanmax([r["sd_route_gap_max"] for r in rows])),
            "gap_median": float(np.nanmedian([r["sd_route_gap_max"] for r in rows])),
            "weight_gap_max": float(np.nanmax([r["sd_route_weight_gap_max"] for r in rows])),
            "rule": f"log gaps between models that both have weight >= {ROUTE_WEIGHT_MIN}; weight gap: the change "
                    "in a sub-model's weight if its own route were used instead of the main weights"},
        "smc_subset": smc,
        "timing": timing,
    }
    if (out / "reference_subset.csv").exists():
        summary["reference_subset"] = reference_agreement(out, reps)
        est = summary["timing"]["full_run_estimate"]
        rs = summary["reference_subset"]
        est["reference_runs"] = math.ceil(0.1 * FULL_REPLICATES * est["scenarios"]) * 8
        est["core_hours_reference"] = est["reference_runs"] * (rs["seconds_fit_mean"] + rs["seconds_bridge_mean"]) / 3600.0
        est["total_core_hours"] += est["core_hours_reference"]
        for w in (4, 10):
            est[f"wall_hours_{w}_workers"] += est["core_hours_reference"] / w
    sub = [r for r in rows if np.isfinite(r.get("smc_median", np.nan))]
    if sub:
        summary["smc_subset"]["note"] = ("diagnostic only: Phase 4 check 4 found SMC's marginal likelihood biased on "
                                         "the structured models; the yardstick is reference_subset (bridge sampling)")
        summary["smc_subset"]["agreement"] = {
            m: {"log_bf_abs_diff_max": float(max(r[f"{m}_vs_smc_log_bf_max"] for r in sub)),
                "weight_total_variation_max": float(max(r[f"{m}_vs_smc_weight_tv"] for r in sub)),
                "N_median_rel_diff_max": float(max(abs(r[f"{m}_median"] - r["smc_median"]) / r["N_true"] for r in sub)),
                "same_coverage_outcome": int(sum(bool(r[f"{m}_covered"]) == bool(r["smc_covered"]) for r in sub)),
                "replicates": len(sub)}
            for m in ("bridge", "sd", "laplace")}
    write_json(out / "summary.json", summary)
    return summary


def reference_agreement(out: Path, reps) -> dict:
    """Each weighting method against the bridge-sampling reference, on the reference subset.

    Writes ``reference_comparison.csv`` (one row per replicate and structure) and returns, per method, the largest
    log Bayes factor difference among structures with weight >= 0.01 under either, the total-variation distance
    between the weight vectors, and the BMA median and coverage under the reference weights.  SMC, where it was
    run, is compared the same way, as a diagnostic.
    """
    import pandas as pd

    ref = pd.read_csv(out / "reference_subset.csv")
    labels = [pair_label(sp.pairs) for sp in dependence_structures(())]
    full = labels[-1]
    rows, agree = [], {}
    for (s, r), grp in ref.groupby(["scenario", "replicate"]):
        lm = grp.set_index("label")["log_ml"]
        rel_ref = {lab: float(lm[lab] - lm[full]) for lab in labels}
        w_ref = weights_from_log_ml(rel_ref)
        rep = reps[(reps.scenario == s) & (reps.replicate == r)].iloc[0]
        d = np.load(out / "draws" / f"N_{s}_r{int(r):03d}.npz")
        N_draws = {lab: d[lab] for lab in labels}
        ref_bma = bma_summary(N_draws, w_ref, int(rep["N_true"]))
        for lab in labels:
            rows.append({"scenario": s, "replicate": int(r), "structure": lab, "reference_rel_log_ml": rel_ref[lab],
                         "reference_weight": w_ref[lab], "reference_cv": float(grp.set_index("label")["cv"][lab]),
                         **{f"{m}_rel_log_ml": rep.get(f"{m}_rel_log_ml[{lab}]", np.nan) for m in METHODS},
                         **{f"{m}_weight": rep.get(f"{m}_w[{lab}]", np.nan) for m in METHODS}})
        for m in METHODS:
            if not np.isfinite(rep.get(f"{m}_rel_log_ml[{full}]", np.nan)):
                continue
            rel_m = {lab: float(rep[f"{m}_rel_log_ml[{lab}]"]) for lab in labels}
            w_m = {lab: float(rep[f"{m}_w[{lab}]"]) for lab in labels}
            relevant = [lab for lab in labels if max(w_m[lab], w_ref[lab]) >= ROUTE_WEIGHT_MIN]
            a = agree.setdefault(m, {"log_bf_abs_diff": [], "weight_tv": [], "N_median_rel_diff": [],
                                     "same_coverage": [], "replicates": []})
            a["log_bf_abs_diff"].append(max(abs(rel_m[lab] - rel_ref[lab]) for lab in relevant))
            a["weight_tv"].append(0.5 * sum(abs(w_m[lab] - w_ref[lab]) for lab in labels))
            a["N_median_rel_diff"].append(abs(float(rep[f"{m}_median"]) - ref_bma["median"]) / float(rep["N_true"]))
            a["same_coverage"].append(bool(rep[f"{m}_covered"]) == bool(ref_bma["covered"]))
            a["replicates"].append([s, int(r)])
    pd.DataFrame(rows).to_csv(out / "reference_comparison.csv", index=False)
    return {"yardstick": "crc_engine.marginal.bridge_log_marginal_likelihood on a fresh NUTS fit "
                         f"({REFERENCE_SAMPLER['chains']} chains x {REFERENCE_SAMPLER['draws']} draws) of each structure",
            "replicates": sorted({(s, int(r)) for s, r in zip(ref.scenario, ref.replicate)}),
            "reference_cv_max": float(ref["cv"].max()), "reference_divergent_fits": int((ref["divergences"] > 0).sum()),
            "reference_fits": int(len(ref)), "seconds_fit_mean": float(ref["seconds_fit"].mean()),
            "seconds_bridge_mean": float(ref["seconds_bridge"].mean()),
            "agreement": {m: {"log_bf_abs_diff_max": float(max(a["log_bf_abs_diff"])),
                              "weight_total_variation_max": float(max(a["weight_tv"])),
                              "N_median_rel_diff_max": float(max(a["N_median_rel_diff"])),
                              "same_coverage_outcome": int(sum(a["same_coverage"])), "replicates": len(a["replicates"]),
                              "role": "diagnostic (SMC)" if m == "smc" else ("main weights" if m == "bridge" else
                                                                            "alternative")}
                          for m, a in agree.items()}}


def run_smc_subset(rows, data, prior_name, exposure, root_seed, fraction, draws, chains, workers, log, *,
                   amendment: str | None = None) -> dict:
    """SMC log marginal likelihoods of the 8 structures (each with ``amendment``) on a seeded subset of the
    replicates."""
    if fraction <= 0:
        return {"status": "not run (fraction 0)"}
    try:
        from .. import marginal  # noqa: F401
    except ImportError as e:      # pragma: no cover - depends on the parallel module
        return {"status": f"not run: crc_engine.marginal unavailable ({e})"}
    keys = sorted({(r["scenario"], r["replicate"]) for r in rows})
    chosen = subset_keys(keys, fraction, root_seed)
    jobs = []
    for key in chosen:
        for spec in dependence_structures(find_scenario(key[0]).covariates, amendment):
            jobs.append({**_job_template(prior_name, exposure, {}), "key": list(key), "counts": data[key].counts,
                         "spec": spec, "draws": draws, "chains": chains,
                         "seed": seed_for(root_seed, "smc", key[0], key[1], spec.name)})
    log(f"recovery: SMC on {len(chosen)} of {len(keys)} replicates ({len(jobs)} runs, {chains} chains x {draws} draws)")
    res = run_pool(jobs, smc_job, workers, log)
    log_ml: dict[tuple, dict[str, float]] = {}
    for r in res:
        log_ml.setdefault((r["key"][0], int(r["key"][1])), {})[r["label"]] = r["log_ml"]
    runs = [{"scenario": r["key"][0], "replicate": r["key"][1], "structure": r["label"], "log_ml": r["log_ml"],
             "spread": r["spread"], "stages": max(r["stages"]), "per_chain": json.dumps(r["per_chain"]),
             "seconds": r["seconds"]} for r in res]
    return {"status": "run", "replicates": [list(k) for k in chosen], "draws": draws, "chains": chains,
            "seconds_mean": float(np.mean([r["seconds"] for r in res])),
            "seconds_max": float(np.max([r["seconds"] for r in res])),
            "spread_max": float(max(r["spread"] for r in res)), "log_ml": log_ml, "runs": runs}


def timing_summary(fit_rows, compile_secs, job_secs, smc, workers, wall, scenarios=None) -> dict:
    """Measured times and the compute estimate for the full run (100 replicates of every scenario: ``SCENARIOS``, or
    the given ones, an amendment's run)."""
    per_fit = float(np.mean([f["seconds_total"] for f in fit_rows]))
    comp = float(np.mean(compile_secs))
    full_run = list(SCENARIOS.values()) if scenarios is None else list(scenarios)
    n_scen_full = len(full_run)
    covs = {tuple(s.covariates) for s in full_run}
    fits_full = FULL_REPLICATES * n_scen_full * 8
    core_s = fits_full * per_fit
    est = {"fits": fits_full, "scenarios": n_scen_full, "replicates": FULL_REPLICATES,
           "core_hours_nuts": core_s / 3600.0}
    if smc.get("status") == "run":
        smc_runs = math.ceil(0.1 * FULL_REPLICATES * n_scen_full) * 8
        est["smc_runs"] = smc_runs
        est["core_hours_smc"] = smc_runs * smc["seconds_mean"] / 3600.0
    total_core_h = est["core_hours_nuts"] + est.get("core_hours_smc", 0.0)
    for w in (4, 10):
        # each worker compiles each structure once (8 per covariate setting), then fits its share
        est[f"wall_hours_{w}_workers"] = (total_core_h * 3600.0 / w + 8 * len(covs) * comp / min(w, 8)) / 3600.0
    est["total_core_hours"] = total_core_h
    return {"fits": len(fit_rows), "seconds_per_fit_mean": per_fit,
            "seconds_per_fit_p90": float(np.quantile([f["seconds_total"] for f in fit_rows], 0.9)),
            "seconds_sample_mean": float(np.mean([f["seconds_sample"] for f in fit_rows])),
            "seconds_savage_dickey_mean": float(np.mean([f["seconds_savage_dickey"] or 0 for f in fit_rows])),
            "seconds_laplace_mean": float(np.mean([f["seconds_laplace"] or 0 for f in fit_rows])),
            "compile_seconds_mean": comp, "compile_seconds_max": float(np.max(compile_secs)),
            "job_seconds": list(job_secs), "workers": workers, "wall_seconds": wall, "full_run_estimate": est}


def main(argv: Sequence[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--out", required=True)
    p.add_argument("--scenarios", nargs="+", default=None, choices=sorted(SCENARIOS) + sorted(AMENDMENT_SCENARIOS),
                   help="default: the pilot scenarios; with --amendment, that amendment's six "
                        "(AMENDMENT_RUN_SCENARIOS)")
    p.add_argument("--amendment", choices=sorted(AMENDMENTS), default=None,
                   help="fit every structure with this amendment of the model space (decision 122)")
    p.add_argument("--replicates", type=int, default=5)
    p.add_argument("--prior", default="recalibrated", choices=["recalibrated", "proposed"])
    p.add_argument("--seed", type=int, default=20261102)
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--chunk", type=int, default=None)
    p.add_argument("--smc-fraction", type=float, default=0.1,
                   help="share of replicates in the reference subset (bridge sampling; SMC as a diagnostic)")
    p.add_argument("--skip-smc", action="store_true", help="run the bridge-sampling reference on the subset, not SMC")
    p.add_argument("--smc-draws", type=int, default=2000)
    p.add_argument("--smc-chains", type=int, default=4)
    p.add_argument("--importance-draws", type=int, default=0)
    p.add_argument("--centred", action="store_true", help="the plan's first attempt (centred pooled terms)")
    p.add_argument("--keep-unconstrained", action="store_true", help="keep every fit's unconstrained draws")
    p.add_argument("--summarize-only", action="store_true", help="rebuild summary.json from the outputs in --out")
    p.add_argument("--reference-only", action="store_true",
                   help="add the bridge-sampling reference to the finished run in --out, then re-summarise")
    p.add_argument("--chains", type=int, default=SHORT_SAMPLER["chains"])
    p.add_argument("--tune", type=int, default=SHORT_SAMPLER["tune"])
    p.add_argument("--draws", type=int, default=SHORT_SAMPLER["draws"])
    a = p.parse_args(argv)
    if a.summarize_only:
        summarize_recovery(a.out)
        return
    if a.reference_only:
        reference_only(a.out, workers=a.workers, log=lambda m: print(m, flush=True))
        return
    scenarios = a.scenarios or list(PILOT_SCENARIOS if a.amendment is None else AMENDMENT_RUN_SCENARIOS[a.amendment])
    run_recovery(a.out, scenarios=scenarios, replicates=a.replicates, prior_name=a.prior, root_seed=a.seed,
                 workers=a.workers, chunk=a.chunk, smc_fraction=a.smc_fraction, smc_draws=a.smc_draws,
                 smc_chains=a.smc_chains, importance_draws=a.importance_draws, noncentred=not a.centred,
                 keep_unconstrained=a.keep_unconstrained, run_smc=not a.skip_smc,
                 sampler={"chains": a.chains, "tune": a.tune, "draws": a.draws}, amendment=a.amendment,
                 log=lambda m: print(m, flush=True))


if __name__ == "__main__":
    main()
