"""Phase 4, check 4: accuracy of the marginal likelihoods behind the model weights.

**In plain words.** The weight of each model rests on one number per model, its marginal likelihood, which
the study computes in two independent ways (bridge sampling, checked by importance sampling; decision 78).
Here both are checked on small models where that number can also be computed directly, by brute force, so we
know the right answer.  SMC, the first draft's method, is still run as a diagnostic: this check found it
biased on the structured models (decision 70).

**Technically.** Two families of small models, each fitted with the plan's settings (NUTS: 4 chains x 2 000
draws after 2 000 tuning steps; bridge sampling and importance sampling from those draws; SMC: 4 chains x
2 000 draws):

* **Unstratified** (``models.build_model``, the Phase 1 builder with the proposed priors) on the old app's
  three-list table: M0 (2 parameters), independence (4), one pair (5) and all pairs (7).  Reference:
  adaptive Gauss-Hermite quadrature centred at the posterior mode on the Laplace scale, for up to five
  parameters (two grid sizes, to show it has converged), and importance sampling with 10^6 draws.
* **Structured** (``models.build_structured_model``, the plan's Phase 3 model) on a small simulated table
  (2 sexes x 3 age bands x 2 years, two one-year periods): independence, one pair, all pairs, one pair with
  list x sex, and the richest model, with the proposed priors; independence and all pairs with the
  recalibrated priors as well (made-up person-years).  Reference: importance sampling with 10^6 draws.
* **Amended** (decision 122, ``docs/amendments/decision-122/``; ``amendment_cases``, ``--cases amendments``):
  the two recalibrated structured cases, each with AM1 (a partially pooled list x year term; on the tiny
  table one zero-sum group of its two years) and each with AM2 (NB1 counts).  Reference: importance sampling
  with 10^6 draws.  ``cases`` and the selection "all" stay the frozen plan's eleven cases.

The references never call PyMC's log density.  The joint density is written out in numpy in a non-centred
parametrisation whose every factor is a normalised standard density: each zero-sum effect is its scale
times an orthonormal basis of the zero-sum subspace times independent N(0, 1) coordinates (the same
distribution as ``ZeroSumNormal``), each HalfNormal scale is integrated on the log scale with its Jacobian,
the random walk's steps are its scale times N(0, 1) draws, and the likelihood uses the engine's
``linear_predictor``.  A normalisation error in PyMC's densities or transforms would therefore show up as
a bridge-sampling error rather than cancel.  The amendments' terms follow the same rules: AM1's scales
sigma_l on the log scale, and its zero-sum draws z as N(0, 1) coordinates in an orthonormal zero-sum basis of
each year group, with deviations sigma_l sqrt(n / (n - 1)) z on the list x year columns; AM2's dispersion
kappa on the log scale, and the NB1 likelihood with every constant (``nb1_loglik``).  A capture block or an
amendment the reference has no density for is refused rather than left out.  The importance-sampling
proposal is a multivariate t (5 degrees of freedom, covariance x 1.2^2) fitted to the NUTS draws mapped into
that parametrisation; the reference is used only when its Pareto k-hat is below 0.7 and its standard error
below 0.02 log units.  Each case computes two such references with two seeds and uses the more precise reliable
one.  An amended case with neither reliable gets one retry (decision 124): two more references with the next two
seeds of the case's stream, ten times the draws and the covariance x 1.5^2; the case is judged on the most precise
reliable reference of the four, and every reference is recorded.  The frozen cases never retry.

The plan's importance sampling (``marginal.importance_log_marginal_likelihood``) differs from the reference
in its density and its parametrisation: it weights its proposal draws by PyMC's own log density on PyMC's
unconstrained space, with Pareto-smoothed weights and the plan's number of draws, so the reference checks
that implementation.  SMC follows the first draft's procedure: when its chains spread by more than 0.5 log
units the draws are doubled (here at most twice); the first attempt is reported beside the final one.

Pass rule (build plan, Phase 4, with decision 78's pair): bridge sampling and importance sampling each within
0.2 log units of the reference, importance sampling with Pareto k-hat below 0.7.  SMC is reported, not
judged.
"""

from __future__ import annotations

import argparse
import itertools
import math
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Sequence

import numpy as np
from scipy.special import gammaln, logsumexp

from ..amendments import AM1, AM1_BLOCK, AM1_SIGMA, AM1_Z, AM2, AM2_KAPPA
from ..bma import BMA_SETTINGS
from ..marginal import (bridge_log_marginal_likelihood, importance_log_marginal_likelihood,
                        smc_log_marginal_likelihood)
from ..mle import laplace_fit
from ..models import (THREE_WAY, StructuredDesign, build_model, build_structured_model, linear_predictor,
                      random_walk, structured_design, zero_sum_sigma)
from ..modelspace import ModelSpec, design_matrix
from ..priors import PHASE3_PROPOSED, PHASE3_RECALIBRATED, PriorSpec
from ..tables import CaptureTable
from . import _xc_common as xc

TOLERANCE = 0.2                  # build plan: |estimate - reference| at most this, log units
REFERENCE_MAX_SE = 0.02          # a reference noisier than this is not used
REFERENCE_MAX_KHAT = 0.7         # nor one whose importance weights have a heavier tail than this
IS_DRAWS = 1_000_000
#: The plan doubles the SMC draws while the chains spread by more than 0.5 log units; at most this many times here.
SMC_MAX_DOUBLINGS = 2
IS_DF = 5.0
IS_SCALE = 1.2
#: Decision 124: an amended case without a reliable reference retries once with this many times the draws and the
#: proposal's covariance scaled by this factor squared.
RETRY_DRAWS_FACTOR = 10
RETRY_IS_SCALE = 1.5
ROOT_SEED = 20261104
PRIOR_SETS = {"proposed": PHASE3_PROPOSED, "recalibrated": PHASE3_RECALIBRATED["E1"]}

TINY_LEVELS = {"sex": ("F", "M"), "age_band": ("0-4", "5-9", "10-14"), "year": (2015, 2016)}
TINY_PERIODS = {"2015": (2015, 2015), "2016": (2016, 2016)}
#: Made-up person-years per stratum-year for the recalibrated set (about 5 per 100 000 at the truth).
TINY_EXPOSURE = 400_000.0


def zero_sum_basis(L: int) -> np.ndarray:
    """An orthonormal basis (L, L-1) of the zero-sum subspace of R^L."""
    q, _ = np.linalg.qr(np.vstack([np.eye(L - 1), -np.ones((1, L - 1))]))
    return q


def _log_halfnormal_on_log_scale(u: np.ndarray, sigma: float) -> np.ndarray:
    """Density of log s when s ~ HalfNormal(sigma): HalfNormal(e^u) * e^u."""
    s = np.exp(u)
    return 0.5 * np.log(2 / np.pi) - np.log(sigma) - s**2 / (2 * sigma**2) + u


def _log_std_normal(z: np.ndarray) -> np.ndarray:
    return -0.5 * (z**2 + np.log(2 * np.pi))


def poisson_loglik(y: np.ndarray, log_mu: np.ndarray) -> np.ndarray:
    """Poisson log-likelihood summed over the last axis, every constant included."""
    return np.sum(y * log_mu - np.exp(log_mu) - gammaln(y + 1), axis=-1)


#: Below this log kappa, log(log(1 + kappa) / kappa) is -kappa / 2 to double precision (``nb1_logpmf``).
_SMALL_LOG_KAPPA = -30.0


def nb1_logpmf(y, log_mu, log_kappa) -> np.ndarray:
    """log P(y) of NB1(mu, kappa), AM2's count distribution (decision 122), elementwise over broadcast arrays.

    NB1 is the negative binomial with size r = mu / kappa, P(y) = Gamma(y + r) / (Gamma(r) y!) (r / (r + mu))^r
    (mu / (r + mu))^y, every constant included.  Since log Gamma(y + r) - log Gamma(r) = y log r + sum_{j<y}
    log(1 + j / r) for a count y, it is computed from log mu and log kappa as

        y log mu - mu log(1 + kappa) / kappa - log y! - y log(1 + kappa) + sum_{j=1}^{y-1} log(1 + j / r).

    No two large log-gammas are subtracted, so it keeps its accuracy at any r, and the Poisson limit kappa -> 0
    holds even where kappa underflows.  Every term is a number for finite log mu and log kappa except the second,
    which is -inf where mu overflows: an importance proposal's extreme draws get a number or -inf, never NaN and
    never an error.  A mean that is not a number gives -inf.
    """
    y = np.asarray(y, float)
    log_mu = np.asarray(log_mu, float)
    log_kappa = np.asarray(log_kappa, float)
    with np.errstate(over="ignore", under="ignore", invalid="ignore", divide="ignore"):
        log1p_kappa = np.logaddexp(0.0, log_kappa)
        small = log_kappa < _SMALL_LOG_KAPPA                  # there log(1 + kappa) itself may underflow
        log_ratio = np.where(small, -0.5 * np.exp(np.minimum(log_kappa, 0.0)),
                             np.log(np.where(small, 1.0, log1p_kappa)) - log_kappa)   # log(log(1 + kappa) / kappa)
        out = y * log_mu - np.exp(log_mu + log_ratio) - gammaln(y + 1.0) - y * log1p_kappa
        log_r = log_mu - log_kappa
        for j in range(1, int(np.max(y, initial=0.0))):
            out = out + np.where(y > j, np.logaddexp(0.0, math.log(j) - log_r), 0.0)
    return np.where(np.isnan(out), -np.inf, out)


def nb1_loglik(y: np.ndarray, log_mu: np.ndarray, log_kappa: np.ndarray) -> np.ndarray:
    """NB1 log-likelihood summed over the last axis (the cells), every constant included; ``log_kappa`` has one value
    per draw, shape ``log_mu.shape[:-1]`` (``nb1_logpmf``)."""
    return np.sum(nb1_logpmf(y, log_mu, np.asarray(log_kappa, float)[..., None]), axis=-1)


# =========================================================================== reference densities
class Phase1Reference:
    """log p(y, theta) of ``build_model`` (independent Normal priors), vectorised over draws."""

    def __init__(self, table: CaptureTable, spec: ModelSpec, priors: PriorSpec):
        d = design_matrix(spec, table)
        self.X, self.y = d.X_obs, d.y_obs
        mu, sd = np.zeros(d.n_params), np.zeros(d.n_params)
        for block, sl in d.blocks.items():
            pr = {"count": priors.count_intercept, "capture": priors.list_effects, "pairs": priors.pairs}[block]
            mu[sl], sd[sl] = pr.mu, pr.sigma
        self.prior_mean, self.prior_sd = mu, sd
        self.dim = d.n_params

    def log_density(self, theta: np.ndarray) -> np.ndarray:
        theta = np.atleast_2d(theta)
        lp = np.sum(-0.5 * ((theta - self.prior_mean) / self.prior_sd) ** 2 - np.log(self.prior_sd)
                    - 0.5 * np.log(2 * np.pi), axis=-1)
        return lp + poisson_loglik(self.y, theta @ self.X.T)

    def from_posterior(self, idata) -> np.ndarray:
        th = np.asarray(idata["posterior"]["theta"].values)
        return th.reshape(-1, th.shape[-1])


@dataclass
class _Block:
    name: str
    size: int
    kind: str                       # "normal", "std", "logscale"
    mu: float = 0.0
    sd: float = 1.0


def _log_scale_name(var: str, level: str | None = None) -> str:
    """The reference's coordinate for the log of a scale (an amendment's): "log_<var>" or "log_<var>[<level>]"."""
    return f"log_{var}" if level is None else f"log_{var}[{level}]"


class StructuredReference:
    """log p(y, u) of ``build_structured_model`` in a non-centred, explicitly normalised parametrisation u.

    Every zero-sum effect is scale x (orthonormal zero-sum basis) x N(0, 1) coordinates, every pooled term and
    the random walk are non-centred, and every HalfNormal scale is sampled on the log scale with its Jacobian.

    An amended model (decision 122) gains AM1's coordinates, log sigma_l for each list and the N(0, 1)
    coordinates of z in an orthonormal zero-sum basis of each year group (lists x groups x (n - 1)), or AM2's
    log kappa, last, with the NB1 likelihood.  A capture block or an amendment without a density here is refused.
    """

    def __init__(self, d: StructuredDesign, priors: PriorSpec):
        if d.spec.amendment not in (None, AM1.id, AM2.id):
            raise ValueError(f"check 4's reference has no density for the amendment {d.spec.amendment!r}")
        self.d, self.priors = d, priors
        lv = d.levels
        self.Ls, self.La, self.T = (len(lv[v]) for v in ("sex", "age_band", "year"))
        Ls, La, T = self.Ls, self.La, self.T
        self.B = {"sex": zero_sum_basis(Ls), "age_band": zero_sum_basis(La), "year": zero_sum_basis(T)}
        for c in d.spec.list_covariates:
            self.B[c] = zero_sum_basis(len(lv[c]))
        K = len(d.spec.lists)
        self.blocks = [
            _Block("alpha", 1, "normal", priors.count_intercept.mu, priors.count_intercept.sigma),
            _Block("delta_sex", Ls - 1, "std"), _Block("eta_age", La - 1, "std"),
            _Block("delta_eta", (Ls - 1) * (La - 1), "std"),
            _Block("log_gamma_sigma", 1, "logscale", sd=priors.year_rw_scale.sigma), _Block("gamma_z", T - 1, "std"),
            _Block("log_tau", 1, "logscale", sd=priors.stratum_year_scale.sigma),
            _Block("delta_gamma", (Ls - 1) * (T - 1), "std"), _Block("eta_gamma", (La - 1) * (T - 1), "std"),
            _Block("log_tau3", 1, "logscale", sd=priors.three_way_scale.sigma),
            _Block(THREE_WAY, (Ls - 1) * (La - 1) * (T - 1), "std"),
        ]
        for b in d.capture_blocks:
            if b == "capture":
                self.blocks.append(_Block("beta", K, "normal", priors.list_effects.mu, priors.list_effects.sigma))
            elif b.startswith("list×"):
                c = b[len("list×"):]
                self.blocks.append(_Block("list_x_" + c, K * (len(lv[c]) - 1), "std"))
            elif b == "pairs":
                n = d.capture_blocks["pairs"].stop - d.capture_blocks["pairs"].start
                self.blocks.append(_Block("lambda", n, "normal", priors.pairs.mu, priors.pairs.sigma))
            elif b == AM1_BLOCK:               # AM1: log sigma_l per list, then z's coordinates in each year group
                groups = d.year_groups
                self.blocks += [_Block(_log_scale_name(AM1_SIGMA, l), 1, "logscale", sd=AM1.prior.sigma)
                                for l in d.spec.lists]
                self.blocks.append(_Block(AM1_Z, K * len(groups) * (len(groups[0]) - 1), "std"))
                self.B[AM1_Z] = zero_sum_basis(len(groups[0]))
            else:
                raise KeyError(f"check 4's reference has no density for the capture block {b!r}")
        if d.spec.amendment == AM2.id:         # AM2: log kappa, the last coordinate
            self.blocks.append(_Block(_log_scale_name(AM2_KAPPA), 1, "logscale", sd=AM2.prior.sigma))
        self.slices, start = {}, 0
        for b in self.blocks:
            self.slices[b.name] = slice(start, start + b.size)
            start += b.size
        self.dim = start
        self.f = {"sex": zero_sum_sigma([Ls], priors.sex.sigma), "age": zero_sum_sigma([La], priors.age.sigma),
                  "sex_age": zero_sum_sigma([Ls, La], priors.sex_age.sigma),
                  "sex_year": zero_sum_sigma([Ls, T], 1.0), "age_year": zero_sum_sigma([La, T], 1.0),
                  "three": zero_sum_sigma([Ls, La, T], 1.0), "list_cov": {}}
        for c in d.spec.list_covariates:
            self.f["list_cov"][c] = zero_sum_sigma([len(lv[c])], priors.list_covariates.sigma)
        self.y = np.nan_to_num(d.y_obs)

    # ---------------------------------------------------------------- u -> model parameters
    def params(self, u: np.ndarray) -> dict:
        u = np.atleast_2d(u)
        n = u.shape[0]
        g = lambda name: u[:, self.slices[name]]                                       # noqa: E731
        Bs, Ba, Bt = self.B["sex"], self.B["age_band"], self.B["year"]
        Ls, La, T = self.Ls, self.La, self.T
        p = {"alpha": g("alpha")[:, 0],
             "delta_sex": self.f["sex"] * g("delta_sex") @ Bs.T,
             "eta_age": self.f["age"] * g("eta_age") @ Ba.T,
             "delta_eta": self.f["sex_age"] * np.einsum("ij,njk,lk->nil", Bs, g("delta_eta").reshape(n, Ls - 1, La - 1), Ba)}
        sig = np.exp(g("log_gamma_sigma"))
        p["gamma"] = random_walk(sig * g("gamma_z"))
        tau = np.exp(g("log_tau"))[:, :, None]
        p["delta_gamma"] = tau * self.f["sex_year"] * np.einsum("ij,njk,lk->nil", Bs, g("delta_gamma").reshape(n, Ls - 1, T - 1), Bt)
        p["eta_gamma"] = tau * self.f["age_year"] * np.einsum("ij,njk,lk->nil", Ba, g("eta_gamma").reshape(n, La - 1, T - 1), Bt)
        tau3 = np.exp(g("log_tau3"))[:, :, None, None]
        z3 = g(THREE_WAY).reshape(n, Ls - 1, La - 1, T - 1)
        p[THREE_WAY] = tau3 * self.f["three"] * np.einsum("ia,jb,kc,nabc->nijk", Bs, Ba, Bt, z3)
        parts = []
        K = len(self.d.spec.lists)
        for b in self.d.capture_blocks:
            if b == "capture":
                parts.append(g("beta"))
            elif b.startswith("list×"):
                c = b[len("list×"):]
                L = len(self.d.levels[c])
                x = self.f["list_cov"][c] * g("list_x_" + c).reshape(n, K, L - 1) @ self.B[c].T     # (n, K, L)
                parts.append(x[:, :, : L - 1].reshape(n, K * (L - 1)))
            elif b == "pairs":
                parts.append(g("lambda"))
            elif b == AM1_BLOCK:               # effects coding, as the engine adds it: years 1 .. T - 1, list-major
                parts.append(self.am1_deviations(u)[:, :, : T - 1].reshape(n, K * (T - 1)))
            else:
                raise KeyError(f"check 4's reference has no density for the capture block {b!r}")
        p["theta_capture"] = np.concatenate(parts, axis=1)
        return p

    def am1_deviations(self, u: np.ndarray) -> np.ndarray:
        """AM1's deviations per draw, shape (draws, lists, years): u[l, years of g] = sigma_l sqrt(n / (n - 1)) z[l, g],
        z[l, g] the orthonormal zero-sum basis of g's n years times N(0, 1) coordinates (decision 122)."""
        u = np.atleast_2d(u)
        groups, lists = self.d.year_groups, self.d.spec.lists
        n_years = len(groups[0])
        log_sigma = np.hstack([u[:, self.slices[_log_scale_name(AM1_SIGMA, l)]] for l in lists])
        scale = np.exp(log_sigma) * math.sqrt(n_years / (n_years - 1.0))                # (draws, lists)
        z = u[:, self.slices[AM1_Z]].reshape(len(u), len(lists), len(groups), n_years - 1) @ self.B[AM1_Z].T
        out = np.empty((len(u), len(lists), self.T))
        for k, years in enumerate(groups):
            out[:, :, list(years)] = scale[:, :, None] * z[:, :, k, :]
        return out

    def log_prior(self, u: np.ndarray) -> np.ndarray:
        u = np.atleast_2d(u)
        lp = np.zeros(u.shape[0])
        for b in self.blocks:
            x = u[:, self.slices[b.name]]
            if b.kind == "normal":
                lp += np.sum(-0.5 * ((x - b.mu) / b.sd) ** 2 - np.log(b.sd) - 0.5 * np.log(2 * np.pi), axis=1)
            elif b.kind == "std":
                lp += np.sum(_log_std_normal(x), axis=1)
            else:
                lp += _log_halfnormal_on_log_scale(x[:, 0], b.sd)
        return lp

    def log_density(self, u: np.ndarray) -> np.ndarray:
        p = self.params(u)
        log_mu = linear_predictor(p, self.d)[:, ~self.d.hidden]
        if self.d.spec.amendment == AM2.id:            # AM2: NB1 counts with the draw's kappa (decision 122)
            log_kappa = np.atleast_2d(u)[:, self.slices[_log_scale_name(AM2_KAPPA)]][:, 0]
            return self.log_prior(u) + nb1_loglik(self.y, log_mu, log_kappa)
        return self.log_prior(u) + poisson_loglik(self.y, log_mu)

    # ---------------------------------------------------------------- PyMC posterior -> u
    def from_posterior(self, idata) -> np.ndarray:
        post = idata["posterior"]
        v = lambda k: np.asarray(post[k].values).reshape((-1,) + post[k].shape[2:])   # noqa: E731
        Bs, Ba, Bt = self.B["sex"], self.B["age_band"], self.B["year"]
        cols = {"alpha": v("alpha")[:, None],
                "delta_sex": v("delta_sex") @ Bs / self.f["sex"],
                "eta_age": v("eta_age") @ Ba / self.f["age"],
                "delta_eta": np.einsum("ij,nil,lk->njk", Bs, v("delta_eta"), Ba).reshape(len(v("alpha")), -1) / self.f["sex_age"]}
        sig = v("gamma_sigma")
        steps = v("gamma_steps") if "gamma_steps" in post else sig[:, None] * v("gamma_z")
        cols["log_gamma_sigma"] = np.log(sig)[:, None]
        cols["gamma_z"] = steps / sig[:, None]
        tau = v("tau")
        cols["log_tau"] = np.log(tau)[:, None]
        n = len(tau)
        for name, B1, f in (("delta_gamma", Bs, self.f["sex_year"]), ("eta_gamma", Ba, self.f["age_year"])):
            x = v(name)
            cols[name] = np.einsum("ij,nil,lk->njk", B1, x, Bt).reshape(n, -1) / (tau[:, None] * f)
        tau3 = v("tau3")
        cols["log_tau3"] = np.log(tau3)[:, None]
        z3 = v(THREE_WAY + "_z")
        cols[THREE_WAY] = np.einsum("ia,jb,kc,nijk->nabc", Bs, Ba, Bt, z3).reshape(n, -1) / self.f["three"]
        lists = self.d.spec.lists
        for b in self.d.capture_blocks:
            if b == "capture":
                cols["beta"] = v("beta")
            elif b.startswith("list×"):
                c = b[len("list×"):]
                cols["list_x_" + c] = (v("list_x_" + c) @ self.B[c]).reshape(n, -1) / self.f["list_cov"][c]
            elif b == "pairs":
                cols["lambda"] = v("lambda")
            elif b == AM1_BLOCK:               # AM1: log sigma_l, and z's coordinates in each year group's basis
                sigma = v(AM1_SIGMA)
                for j, l in enumerate(lists):
                    cols[_log_scale_name(AM1_SIGMA, l)] = np.log(sigma[:, j])[:, None]
                groups = self.d.year_groups
                z = v(AM1_Z).reshape(n, len(lists), len(groups), len(groups[0]))
                cols[AM1_Z] = (z @ self.B[AM1_Z]).reshape(n, -1)
            else:
                raise KeyError(f"check 4's reference has no density for the capture block {b!r}")
        if self.d.spec.amendment == AM2.id:
            cols[_log_scale_name(AM2_KAPPA)] = np.log(v(AM2_KAPPA))[:, None]
        return np.hstack([cols[b.name] for b in self.blocks])


# =========================================================================== reference integrals
@dataclass(frozen=True)
class Reference:
    log_ml: float
    se: float
    method: str
    khat: float | None = None
    ess: float | None = None
    detail: dict = field(default_factory=dict)

    @property
    def reliable(self) -> bool:
        return self.se <= REFERENCE_MAX_SE and (self.khat is None or self.khat < REFERENCE_MAX_KHAT)


def importance_sampling(log_density, mean: np.ndarray, cov: np.ndarray, *, draws: int = IS_DRAWS,
                        df: float = IS_DF, scale: float = IS_SCALE, seed: int, chunk: int = 50_000) -> Reference:
    """log p(y) = log E_g[q / g], g a multivariate t; standard error from the weights, Pareto k-hat of their tail."""
    from arviz_stats.base import array_stats

    d = mean.size
    L = np.linalg.cholesky(np.atleast_2d(cov)) * scale
    logdet = np.log(np.diag(L)).sum()
    const = gammaln((df + d) / 2) - gammaln(df / 2) - 0.5 * d * np.log(df * np.pi) - logdet
    rng = np.random.default_rng(seed)
    lw = np.empty(draws)
    for start in range(0, draws, chunk):
        m = min(chunk, draws - start)
        z = rng.standard_normal((m, d))
        w = rng.chisquare(df, m)
        x = mean + (z @ L.T) * np.sqrt(df / w)[:, None]
        r = np.linalg.solve(L, (x - mean).T)
        log_g = const - 0.5 * (df + d) * np.log1p((r**2).sum(axis=0) / df)
        lq = log_density(x)
        lw[start:start + m] = np.where(np.isfinite(lq), lq, -np.inf) - log_g
    top = np.max(lw)
    wn = np.exp(lw - top)
    mean_w = wn.mean()
    se = float(np.sqrt(wn.var() / draws) / mean_w)
    khat = float(array_stats.pareto_khat(wn[None, :], chain_axis=0, draw_axis=1, r_eff=1.0, tail="right",
                                         log_weights=False))
    ess = float(wn.sum() ** 2 / (wn**2).sum())
    return Reference(float(top + np.log(mean_w)), se, f"importance sampling, {draws} draws, t({df:g})",
                     khat, ess, {"nonfinite": int((~np.isfinite(lw)).sum())})


def gauss_hermite(log_density, mode: np.ndarray, cov: np.ndarray, n: int, *, chunk: int = 400_000) -> float:
    """Adaptive Gauss-Hermite quadrature: theta = mode + sqrt(2) L z on an n^d product grid."""
    x, w = np.polynomial.hermite.hermgauss(n)
    d = mode.size
    L = np.linalg.cholesky(np.atleast_2d(cov))
    logw1 = np.log(w) + x**2
    const = 0.5 * d * np.log(2.0) + np.log(np.diag(L)).sum()
    total = []
    grid = itertools.product(range(n), repeat=d)
    while True:
        idx = np.array(list(itertools.islice(grid, chunk)))
        if idx.size == 0:
            break
        z = x[idx]
        theta = mode + np.sqrt(2.0) * z @ L.T
        total.append(logsumexp(logw1[idx].sum(axis=1) + log_density(theta)))
    return float(const + logsumexp(total))


# =========================================================================== the models
@dataclass(frozen=True)
class Case:
    name: str
    family: str                       # "unstratified" or "structured"
    spec: ModelSpec
    prior_set: str = "proposed"


def tiny_table(seed: int) -> CaptureTable:
    """The small stratified table of the structured cases (about 20 people per stratum-year)."""
    rng = np.random.default_rng(seed)
    table = CaptureTable.empty(xc.LISTS, TINY_LEVELS)
    truth = ModelSpec(xc.LISTS, frozenset({("A", "B")}), ("sex",))
    d = structured_design(table, truth, periods=TINY_PERIODS)
    params = xc.count_truth(table.levels, rng, log_level=float(np.log(4.0)), interaction_sd=0.1)
    params["theta_capture"] = xc.capture_theta(d, {"A": -0.3, "B": 0.0, "C": -0.5}, {"AB": float(np.log(1.5))},
                                               {"sex": {"A": (0.2, -0.2), "B": (0.0, 0.0), "C": (-0.15, 0.15)}})
    tab, _, _ = xc.simulate_table(table, truth, params, rng, periods=TINY_PERIODS)
    return tab


def cases() -> list[Case]:
    L = xc.LISTS
    allp = frozenset(itertools.combinations(L, 2))
    ab = frozenset({("A", "B")})
    return [
        Case("U-M0", "unstratified", ModelSpec.classical_m0(L)),
        Case("U-indep", "unstratified", ModelSpec.independence(L)),
        Case("U-AB", "unstratified", ModelSpec(L, ab)),
        Case("U-allpairs", "unstratified", ModelSpec(L, allp)),
        Case("S-indep", "structured", ModelSpec(L)),
        Case("S-AB", "structured", ModelSpec(L, ab)),
        Case("S-allpairs", "structured", ModelSpec(L, allp)),
        Case("S-AB|sex", "structured", ModelSpec(L, ab, ("sex",))),
        Case("S-richest", "structured", ModelSpec(L, allp, xc.COVARIATES)),
        Case("S-indep|recal", "structured", ModelSpec(L), "recalibrated"),
        Case("S-allpairs|recal", "structured", ModelSpec(L, allp), "recalibrated"),
    ]


PILOT_CASES = ("U-M0", "U-indep", "U-allpairs", "S-indep", "S-allpairs", "S-richest", "S-indep|recal")
#: The amendments' cases (decision 122, step 3): S-indep and S-allpairs with the recalibrated priors, each with AM1
#: and each with AM2.
AMENDMENT_CASES = ("S-indep|recal|AM1", "S-allpairs|recal|AM1", "S-indep|recal|AM2", "S-allpairs|recal|AM2")


def amendment_cases() -> list[Case]:
    """The amendments' cases: each is a frozen case (its name before the last "|") with the amendment set in its spec,
    on the same table, with the same prior set and pass rule.  They are kept out of ``cases``, the frozen plan's check,
    so that its selection "all" and the validation report's list of planned cases stay as they were."""
    frozen = {c.name: c for c in cases()}
    out = []
    for name in AMENDMENT_CASES:
        base, amendment = name.rsplit("|", 1)
        c = frozen[base]
        out.append(Case(name, c.family, replace(c.spec, amendment=amendment), c.prior_set))
    return out


def case_seeds(seed: int = ROOT_SEED) -> dict[str, int]:
    """One seed per case, the frozen cases' first.  The seed streams are prefix-stable (``xc.seeds``), so the frozen
    cases keep the seeds they had before the amendments' cases were added."""
    names = [c.name for c in cases() + amendment_cases()]
    return dict(zip(names, xc.seeds(seed + 1, len(names))))


def select_cases(case_names: Sequence[str] | str = "pilot") -> list[Case]:
    """The cases ``run`` runs: "pilot", "all" (the frozen plan's eleven), "amendments" (decision 122's four) or a list
    of names, in the order of ``cases`` then ``amendment_cases``."""
    if case_names == "all":
        return cases()
    named = {"pilot": PILOT_CASES, "amendments": AMENDMENT_CASES}
    names = named[case_names] if isinstance(case_names, str) and case_names in named else tuple(case_names)
    return [c for c in cases() + amendment_cases() if c.name in names]


def legacy_table() -> CaptureTable:
    """The old app's three-list table (Hospital, Laboratory, Clinic), with its lists named A, B and C."""
    from .app_references import load_reference, reference_table

    t = reference_table(load_reference(), "loglinear_3source")
    return CaptureTable(xc.LISTS, t.strata, t.counts, t.levels)


def run_case(case: Case, table: CaptureTable, *, sampler: xc.Sampler, smc_draws: int, smc_chains: int,
             is_draws: int, seed: int) -> dict:
    """SMC, bridge sampling and the references for one model; the pass rule applied.

    An amended case whose two references are both unreliable retries once (decision 124, ``RETRY_DRAWS_FACTOR``,
    ``RETRY_IS_SCALE``); its row records the retry under ``reference_retry``.  A frozen case's row is as before."""
    # prefix-stable: the first five as before the plan's importance sampling, the first six as before decision 124
    s_nuts, s_bridge, s_smc, s_is, s_is2, s_imp, s_retry, s_retry2 = xc.seeds(seed, 8)
    priors = PRIOR_SETS[case.prior_set]
    with xc.timed() as t_build:
        if case.family == "unstratified":
            model, _ = build_model(table, case.spec, priors)
            ref_model = Phase1Reference(table, case.spec, priors)
        else:
            exposure = np.full(table.S, TINY_EXPOSURE) if priors.count_target == "total" else None
            sm = build_structured_model(table, case.spec, priors, periods=TINY_PERIODS, exposure=exposure)
            model = sm.model
            ref_model = StructuredReference(sm.design, priors)
    with xc.timed() as t_nuts:
        idata = xc.nuts(model, sampler, s_nuts)
    with xc.timed() as t_bridge:
        br = bridge_log_marginal_likelihood(model, idata, random_seed=s_bridge)
    with xc.timed() as t_imp:                   # the plan's second opinion (decision 78), PyMC's own density
        imp = importance_log_marginal_likelihood(model, idata, random_seed=s_imp)
    # SMC as the plan runs it: double the draws while the chains spread by more than 0.5 log units
    attempts = []
    with xc.timed() as t_smc:
        draws_now = smc_draws
        for k, s in enumerate(xc.seeds(s_smc, SMC_MAX_DOUBLINGS + 1)):
            smc = smc_log_marginal_likelihood(model, draws=draws_now, chains=smc_chains, random_seed=s,
                                              cores=min(sampler.cores, smc_chains), keep_idata=False)
            attempts.append({"draws": draws_now, "log_ml": smc.log_ml, "per_chain": smc.per_chain.tolist(),
                             "spread": smc.spread, "stages": smc.stages.tolist()})
            if not smc.too_spread() or k == SMC_MAX_DOUBLINGS:
                break
            draws_now *= 2
    refs: list[Reference] = []
    with xc.timed() as t_ref:
        if case.family == "unstratified":
            lap = laplace_fit(ref_model.X, ref_model.y, ref_model.prior_mean, ref_model.prior_sd)
            mean, cov = lap.mode, lap.cov
            if ref_model.dim <= 5:
                n_hi = {1: 120, 2: 80, 3: 60, 4: 40, 5: 24}[ref_model.dim]
                n_lo = n_hi - max(4, n_hi // 4)
                hi = gauss_hermite(ref_model.log_density, mean, cov, n_hi)
                lo = gauss_hermite(ref_model.log_density, mean, cov, n_lo)
                refs.append(Reference(hi, abs(hi - lo), f"Gauss-Hermite quadrature, {n_hi}^{ref_model.dim} points",
                                      detail={"coarser_grid_log_ml": lo, "coarser_points_per_axis": n_lo}))
            laplace = lap.log_evidence
        else:
            u = ref_model.from_posterior(idata)
            mean, cov = u.mean(axis=0), np.cov(u, rowvar=False)
            laplace = None
        for k, s in enumerate((s_is, s_is2)):
            r = importance_sampling(ref_model.log_density, mean, cov, draws=is_draws, seed=s)
            refs.append(Reference(r.log_ml, r.se, r.method + (" (second seed)" if k else ""), r.khat, r.ess,
                                  r.detail))
    usable = [r for r in refs if r.reliable]
    retry = None
    if case.spec.amendment is not None:          # decision 124: the amended cases only, and only without a reference
        retry = {"decision": 124, "ran": not usable, "draws": RETRY_DRAWS_FACTOR * is_draws, "df": IS_DF,
                 "scale": RETRY_IS_SCALE}
        if not usable:
            with xc.timed() as t_retry:
                for k, s in enumerate((s_retry, s_retry2)):
                    r = importance_sampling(ref_model.log_density, mean, cov, draws=RETRY_DRAWS_FACTOR * is_draws,
                                            scale=RETRY_IS_SCALE, seed=s)
                    method = (f"{r.method}, covariance x {RETRY_IS_SCALE:g}^2 (decision 124 retry"
                              f"{', second seed' if k else ''})")
                    refs.append(Reference(r.log_ml, r.se, method, r.khat, r.ess, r.detail))
            retry["seconds"] = t_retry.seconds
            usable = [r for r in refs if r.reliable]
    ref = min(usable, key=lambda r: r.se) if usable else None
    row = {"case": case.name, "family": case.family, "model": case.spec.name, "prior_set": case.prior_set,
           "dim": int(ref_model.dim), "n_observed": int(table.n_observed),
           "smc_log_ml": smc.log_ml, "smc_per_chain": smc.per_chain.tolist(), "smc_spread": smc.spread,
           "smc_stages": smc.stages.tolist(), "smc_draws_final": attempts[-1]["draws"],
           "smc_first_log_ml": attempts[0]["log_ml"], "smc_attempts": attempts,
           "bridge_log_ml": br.log_ml, "bridge_cv": br.cv, "bridge_iterations": br.iterations,
           "bridge_converged": br.converged, "bridge_n_eff": br.n_eff, "bridge_nonfinite": br.n_nonfinite,
           "importance_log_ml": imp.log_ml, "importance_log_ml_raw": imp.log_ml_raw, "importance_se": imp.se,
           "importance_khat": imp.khat, "importance_ess": imp.ess, "importance_draws": imp.draws,
           "importance_reliable": imp.reliable,
           "laplace_log_ml": laplace,
           "references": [{"method": r.method, "log_ml": r.log_ml, "se": r.se, "khat": r.khat, "ess": r.ess,
                           "reliable": r.reliable, **r.detail} for r in refs],
           "reference_used": None if ref is None else ref.method,
           "reference_log_ml": None if ref is None else ref.log_ml,
           "seconds": {"build": t_build.seconds, "nuts": t_nuts.seconds, "bridge": t_bridge.seconds,
                       "importance": t_imp.seconds, "smc": t_smc.seconds, "references": t_ref.seconds},
           "nuts_divergences": int(np.asarray(idata["sample_stats"]["diverging"].values).sum()),
           "nuts_sampler": xc.nuts_sampler_name(idata)}
    if retry is not None:
        row["reference_retry"] = retry
    if ref is not None:
        row["smc_first_minus_reference"] = attempts[0]["log_ml"] - ref.log_ml
        row["smc_minus_reference"] = smc.log_ml - ref.log_ml
        row["bridge_minus_reference"] = br.log_ml - ref.log_ml
        row["importance_minus_reference"] = imp.log_ml - ref.log_ml
        row["smc_pass"] = bool(abs(row["smc_minus_reference"]) <= TOLERANCE)       # diagnostic only
        row["bridge_pass"] = bool(abs(row["bridge_minus_reference"]) <= TOLERANCE)
        row["importance_pass"] = bool(imp.reliable and abs(row["importance_minus_reference"]) <= TOLERANCE)
        row["pass"] = row["bridge_pass"] and row["importance_pass"]       # the plan's pair (decision 78)
    else:
        row["pass"] = None                       # no reliable reference: reported, not judged
    row["smc_minus_bridge"] = smc.log_ml - br.log_ml
    row["importance_minus_bridge"] = imp.log_ml - br.log_ml
    row["importance_bridge_agree_plan"] = bool(imp.reliable and abs(row["importance_minus_bridge"])
                                               <= BMA_SETTINGS.agreement_max)
    return row


def run(out_dir=None, *, case_names: Sequence[str] | str = "pilot", sampler: xc.Sampler = xc.Sampler(),
        smc_draws: int = 2000, smc_chains: int = 4, is_draws: int = IS_DRAWS, seed: int = ROOT_SEED) -> dict:
    """Run check 4 on ``case_names`` (``select_cases``); write ``results.json`` and ``cases.csv``.

    With the amendments' cases among them, ``passed_by_amendment`` judges each amendment on its own cases."""
    xc.quiet()
    chosen = select_cases(case_names)
    tables = {"unstratified": legacy_table(), "structured": tiny_table(xc.seeds(seed, 1)[0])}
    seeds = case_seeds(seed)
    result = {"check": "4: marginal-likelihood accuracy", "rule": {"within": TOLERANCE,
              "reference_max_se": REFERENCE_MAX_SE, "reference_max_khat": REFERENCE_MAX_KHAT},
              "sampler": sampler.as_dict(), "smc": {"draws": smc_draws, "chains": smc_chains},
              "importance_sampling": {"draws": is_draws, "df": IS_DF, "scale": IS_SCALE}, "root_seed": seed,
              "tables": {"unstratified": "legacy loglinear_3source (n = %d)" % tables["unstratified"].n_observed,
                         "structured": {"levels": {k: list(map(str, v)) for k, v in TINY_LEVELS.items()},
                                        "n_observed": tables["structured"].n_observed,
                                        "zero_cells": int((tables["structured"].counts == 0).sum()),
                                        "cells": int(tables["structured"].counts.size)}}}
    if any(c.spec.amendment is not None for c in chosen):
        result["reference_retry"] = {"decision": 124, "applies_to": "amended cases without a reliable reference",
                                     "draws": RETRY_DRAWS_FACTOR * is_draws, "df": IS_DF, "scale": RETRY_IS_SCALE}
    rows = []
    with xc.timed() as t_all:
        for c in chosen:
            rows.append(run_case(c, tables[c.family], sampler=sampler, smc_draws=smc_draws, smc_chains=smc_chains,
                                 is_draws=is_draws, seed=seeds[c.name]))
    judged = [r for r in rows if r["pass"] is not None]
    result["cases"] = rows
    result["n_without_reliable_reference"] = len(rows) - len(judged)
    result["passed"] = bool(judged and all(r["pass"] for r in judged) and len(judged) == len(rows))
    amended: dict[str, list] = {}
    for c, r in zip(chosen, rows):
        if c.spec.amendment is not None:
            amended.setdefault(c.spec.amendment, []).append(r["pass"])
    if amended:              # an amendment passes check 4 when each of its cases passes (decision 122)
        result["passed_by_amendment"] = {a: all(p is True for p in v) for a, v in amended.items()}
    result["seconds_total"] = t_all.seconds
    result["provenance"] = xc.provenance()
    if out_dir is not None:
        import pandas as pd

        xc.write_json(Path(out_dir) / "results.json", result)
        flat = [{k: v for k, v in r.items() if k not in ("references", "smc_per_chain", "smc_stages", "seconds",
                                                          "smc_attempts", "reference_retry")}
                | {f"seconds_{k}": v for k, v in r["seconds"].items()}
                | ({"reference_retry_ran": r["reference_retry"]["ran"]} if "reference_retry" in r else {})
                for r in rows]
        pd.DataFrame(flat).to_csv(Path(out_dir) / "cases.csv", index=False)
    return result



#: SMC variants of the diagnostic: (kernel, draws, non-centred count part).  Diagnosis only, never a pass.
SMC_VARIANTS = {"plan": ("IMH", 2000, False), "imh-8000": ("IMH", 8000, False), "mh": ("MH", 2000, False),
                "noncentred": ("IMH", 2000, True)}


def smc_diagnostic(results_path, *, case_names: Sequence[str] = ("S-indep", "S-richest"),
                   variants: Sequence[str] = ("noncentred", "imh-8000", "mh"), seed: int = ROOT_SEED + 7,
                   cores: int = xc.MAX_CORES, out_path=None) -> dict:
    """Why SMC misses: rerun it on structured cases with other kernels, more draws or the non-centred form.

    The references are read from a finished check 4 run (``results_path``).  The non-centred model is the
    builder's own second-attempt form (``noncentred=True``): the same model, so the same marginal likelihood.
    This is a diagnosis for the decision log; it never changes a pass or a fail.
    """
    import json

    import pymc as pm

    xc.quiet()
    done = {c["case"]: c for c in json.loads(Path(results_path).read_text())["cases"]}
    table = tiny_table(xc.seeds(ROOT_SEED, 1)[0])
    rows = []
    for name, s_case in zip(case_names, xc.seeds(seed, len(case_names))):
        case = next(c for c in cases() if c.name == name)
        ref = done[name]["reference_log_ml"]
        priors = PRIOR_SETS[case.prior_set]
        exposure = np.full(table.S, TINY_EXPOSURE) if priors.count_target == "total" else None
        for v, s_var in zip(variants, xc.seeds(s_case, len(variants))):
            kernel, draws, nc = SMC_VARIANTS[v]
            sm = build_structured_model(table, case.spec, priors, periods=TINY_PERIODS, exposure=exposure,
                                        noncentred=nc)
            with xc.timed() as t:
                res = smc_log_marginal_likelihood(sm.model, draws=draws, chains=4, random_seed=s_var,
                                                  cores=min(cores, 4), keep_idata=False,
                                                  kernel=getattr(pm.smc.kernels, kernel))
            rows.append({"case": name, "variant": v, "kernel": kernel, "draws": draws, "noncentred": nc,
                         "log_ml": res.log_ml, "per_chain": res.per_chain.tolist(), "spread": res.spread,
                         "stages": res.stages.tolist(), "reference_log_ml": ref,
                         "minus_reference": res.log_ml - ref, "seconds": t.seconds})
    out = {"diagnostic": "SMC variants on structured cases (not a pass rule)", "references_from": str(results_path),
           "rows": rows, "provenance": xc.provenance()}
    if out_path is not None:
        xc.write_json(Path(out_path), out)
    return out

def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--out", default=str(xc.pilot_dir("check4-marginal-accuracy")))
    p.add_argument("--cases", default="pilot", help='"pilot", "all" (the frozen plan\'s cases), "amendments" (decision '
                   '122\'s four cases) or comma-separated case names')
    p.add_argument("--draws", type=int, default=2000)
    p.add_argument("--tune", type=int, default=2000)
    p.add_argument("--chains", type=int, default=4)
    p.add_argument("--smc-draws", type=int, default=2000)
    p.add_argument("--smc-chains", type=int, default=4)
    p.add_argument("--is-draws", type=int, default=IS_DRAWS)
    p.add_argument("--cores", type=int, default=xc.MAX_CORES)
    p.add_argument("--seed", type=int, default=ROOT_SEED)
    p.add_argument("--smc-diagnostic", action="store_true",
                   help="rerun SMC variants on structured cases against the references in OUT/results.json")
    a = p.parse_args(argv)
    if a.smc_diagnostic:
        d = smc_diagnostic(Path(a.out) / "results.json", cores=a.cores, out_path=Path(a.out) / "smc-diagnostic.json")
        for r in d["rows"]:
            print(f"{r['case']:12s} {r['variant']:10s} {r['log_ml']:.3f} - reference = {r['minus_reference']:+.3f} "
                  f"(spread {r['spread']:.2f}, {r['seconds']:.0f} s)")
        return
    names = a.cases if a.cases in ("pilot", "all", "amendments") else a.cases.split(",")
    res = run(a.out, case_names=names, sampler=xc.Sampler(a.chains, a.draws, a.tune, cores=a.cores),
              smc_draws=a.smc_draws, smc_chains=a.smc_chains, is_draws=a.is_draws, seed=a.seed)
    print(f"check 4 {'PASSED' if res['passed'] else 'FAILED'}; {len(res['cases'])} cases; "
          f"{res['seconds_total']:.0f} s; written to {a.out}")


if __name__ == "__main__":
    main()
