"""Marginal likelihoods for the recovery check's BMA weights: Laplace and importance sampling.

Both approximate log p(y | M) = log of the integral of exp(logp(x)) over the PyMC model's unconstrained
space, where ``logp`` is the model's own joint log density with the log-Jacobian of every transform (what
``Model.logp()`` and nutpie's compiled function return).  Working there means the priors are exactly
the fitted model's, including the zero-sum priors' correlation across levels: PyMC's zero-sum transform
is an isometry onto the zero-sum subspace, so its unconstrained coordinates carry an independent
N(0, sigma^2) prior and every correlation is implied, not restated.

* ``laplace``: the mode (L-BFGS, then Newton steps), the Hessian by central differences of the analytic
  gradient, and log p(y) ~ logp(mode) + d/2 log(2 pi) - 1/2 log det(-H).
* ``importance``: draws from a multivariate t fitted to the posterior draws, with the Pareto k-hat of the
  importance weights (``pareto_khat``) as the reliability check (k-hat above 0.7: unreliable).

For nested models, whose dropped terms have priors independent of the rest (the pairwise terms do), Bayes
factors need no absolute marginal likelihood: ``savage_dickey`` estimates the Savage-Dickey density ratio from
the full model's draws, and ``nested_bridge`` bridges the full model's posterior and the sub-model's posterior
(each fitted by NUTS), which stays accurate when the zero point sits in the tail of the full posterior.

A design-matrix Laplace in effects coding (``mle.laplace_fit``) is a different matter: it takes
independent Normal priors, while a zero-sum effect of L levels gives its L - 1 effects-coded coefficients
a covariance with negative off-diagonal terms (``zero_sum_effects_cov``).  ``laplace_glm`` takes a full
prior covariance; the tests check it against the PyMC model and show how far independent priors move the
marginal likelihood.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Sequence

import numpy as np

from ..models import zero_sum_sigma
from ..modelspace import sum_to_zero

LOG_2PI = math.log(2.0 * math.pi)
#: Above this Pareto k-hat an importance-sampling estimate is unreliable (Vehtari et al. 2024).
KHAT_MAX = 0.7


# --------------------------------------------------------------------------- zero-sum priors, effects coding
def zero_sum_effects_cov(levels: Sequence[int], sd: float) -> np.ndarray:
    """Prior covariance of the effects-coded coefficients of a zero-sum Normal effect.

    The effect sums to zero along each of its axes (sizes ``levels``) and every cell has SD ``sd``, as
    ``pm.ZeroSumNormal(sigma=models.zero_sum_sigma(levels, sd), n_zerosum_axes=len(levels))``.  Effects
    coding (``modelspace.sum_to_zero``) keeps the cells whose index is below L - 1 on every axis, row-major;
    their covariance is sigma^2 x kron_i (I - J / L_i)[:L_i - 1, :L_i - 1], with negative off-diagonal
    terms whenever an axis has three or more levels.
    """
    out = np.full((1, 1), zero_sum_sigma(levels, sd) ** 2)
    for L in levels:
        out = np.kron(out, (np.eye(L) - np.full((L, L), 1.0 / L))[: L - 1, : L - 1])
    return out


def effects_to_cells(levels: Sequence[int]) -> np.ndarray:
    """The matrix C (cells x coefficients) mapping effects-coded coefficients to every cell of the effect."""
    out = np.ones((1, 1))
    for L in levels:
        out = np.kron(out, sum_to_zero(range(L)))
    return out


def list_covariate_prior_cov(n_lists: int, L: int, sd: float) -> np.ndarray:
    """Covariance of a list x covariate block in design order (list-major, the first L - 1 levels).

    Each list's row is its own zero-sum effect over the L levels (``models.build_structured_model``
    builds ``ZeroSumNormal(dims=("list", c))`` with one zero-sum axis), so the block is kron(I, cov).
    """
    return np.kron(np.eye(n_lists), zero_sum_effects_cov([L], sd))


def gaussian_logpdf(x: np.ndarray, mean: np.ndarray, cov: np.ndarray) -> float:
    L = np.linalg.cholesky(cov)
    z = np.linalg.solve(L, np.asarray(x, float) - np.asarray(mean, float))
    return float(-0.5 * z @ z - np.log(np.diag(L)).sum() - 0.5 * len(z) * LOG_2PI)


@dataclass(frozen=True)
class GLMLaplace:
    mode: np.ndarray
    cov: np.ndarray
    log_evidence: float


def laplace_glm(X: np.ndarray, y: np.ndarray, prior_mean: np.ndarray, prior_cov: np.ndarray, *,
                offset: np.ndarray | None = None, max_iter: int = 200, tol: float = 1e-12) -> GLMLaplace:
    """Laplace approximation of a Poisson log-linear model, log mu = offset + X beta, beta ~ N(m, Sigma).

    The same computation as ``mle.laplace_fit`` with a full prior covariance instead of independent SDs.
    """
    from scipy.special import gammaln

    X = np.asarray(X, float)
    y = np.asarray(y, float)
    m0 = np.asarray(prior_mean, float)
    off = np.zeros(len(y)) if offset is None else np.asarray(offset, float)
    prec = np.linalg.inv(prior_cov)
    beta = m0.copy()
    for _ in range(max_iter):
        mu = np.exp(off + X @ beta)
        grad = X.T @ (y - mu) - prec @ (beta - m0)
        H = (X * mu[:, None]).T @ X + prec
        step = np.linalg.solve(H, grad)
        beta = beta + step
        if np.max(np.abs(step)) < tol * (1.0 + np.max(np.abs(beta))):
            break
    eta = off + X @ beta
    mu = np.exp(eta)
    H = (X * mu[:, None]).T @ X + prec
    loglik = float(np.sum(y * eta - mu - gammaln(y + 1.0)))
    _, logdet = np.linalg.slogdet(H)
    ev = loglik + gaussian_logpdf(beta, m0, prior_cov) + 0.5 * len(beta) * LOG_2PI - 0.5 * logdet
    return GLMLaplace(beta, np.linalg.inv(H), float(ev))


# --------------------------------------------------------------------------- Laplace on the model's log density
LogpGrad = Callable[[np.ndarray], tuple[float, np.ndarray]]


@dataclass(frozen=True)
class Laplace:
    log_ml: float
    mode: np.ndarray
    cov: np.ndarray              # inverse of -Hessian at the mode
    logp_mode: float
    grad_norm: float             # max |gradient| at the mode
    converged: bool
    n_newton: int


def fd_hessian(grad: Callable[[np.ndarray], np.ndarray], x: np.ndarray, rel_step: float = 1e-5) -> np.ndarray:
    """Hessian by central differences of an analytic gradient, symmetrised."""
    x = np.asarray(x, float)
    d = len(x)
    H = np.empty((d, d))
    for j in range(d):
        h = rel_step * max(1.0, abs(x[j]))
        e = np.zeros(d)
        e[j] = h
        H[:, j] = (grad(x + e) - grad(x - e)) / (2.0 * h)
    return 0.5 * (H + H.T)


def laplace(logp_grad: LogpGrad, x0: np.ndarray, *, gtol: float = 1e-6, max_newton: int = 30) -> Laplace:
    """Laplace approximation of log of the integral of exp(logp) over R^d.

    ``logp_grad(x)`` returns (log density, gradient).  The mode is found by L-BFGS from ``x0`` and
    polished by damped Newton steps on the finite-difference Hessian.  ``converged`` is False when the
    gradient at the end exceeds ``gtol`` or the Hessian is not negative definite there.
    """
    from scipy.optimize import minimize

    def neg(x):
        lp, g = logp_grad(np.asarray(x, float))
        if not np.isfinite(lp):
            return 1e300, np.zeros_like(x)
        return -float(lp), -np.asarray(g, float)

    def neg_grad(x):
        return neg(x)[1]

    res = minimize(neg, np.asarray(x0, float), jac=True, method="L-BFGS-B",
                   options={"maxiter": 50_000, "maxcor": 50, "ftol": 1e-15, "gtol": 1e-10})
    x = res.x
    f, g = neg(x)
    n = 0
    for n in range(1, max_newton + 1):
        H = fd_hessian(neg_grad, x)
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        t = 1.0
        while t > 1e-6:
            fx, gx = neg(x - t * step)
            if fx <= f + 1e-12:
                break
            t *= 0.5
        x, f, g = x - t * step, fx, gx
        if np.max(np.abs(g)) < 1e-9 or np.max(np.abs(t * step)) < 1e-12:
            break
    H = fd_hessian(neg_grad, x)
    try:
        C = np.linalg.cholesky(H)
        pd = True
        logdet = 2.0 * np.log(np.diag(C)).sum()
        cov = np.linalg.inv(H)
    except np.linalg.LinAlgError:
        pd = False
        logdet = float("nan")
        cov = np.full_like(H, np.nan)
    gn = float(np.max(np.abs(g)))
    log_ml = -f + 0.5 * len(x) * LOG_2PI - 0.5 * logdet
    return Laplace(float(log_ml), x, cov, float(-f), gn, bool(pd and gn < gtol), n)


# --------------------------------------------------------------------------- importance sampling
@dataclass(frozen=True)
class Importance:
    log_ml: float
    khat: float                  # Pareto k-hat of the importance weights
    ess: float                   # effective sample size of the weights
    n: int
    df: float
    reliable: bool               # khat <= KHAT_MAX


def _gpdfit(x: np.ndarray) -> tuple[float, float]:
    """Generalised Pareto fit (Zhang & Stephens 2009, with the weak prior on k used by PSIS); x sorted ascending."""
    n = len(x)
    m_est = 30 + int(n ** 0.5)
    b = 1.0 - np.sqrt(m_est / (np.arange(1, m_est + 1, dtype=float) - 0.5))
    b /= 3.0 * x[int(n / 4 + 0.5) - 1]
    b += 1.0 / x[-1]
    k = np.log1p(-b[:, None] * x).mean(axis=1)
    ls = n * (np.log(-(b / k)) - k - 1.0)
    w = 1.0 / np.exp(ls - ls[:, None]).sum(axis=1)
    keep = w >= 10 * np.finfo(float).eps
    w, b = w[keep], b[keep]
    w /= w.sum()
    b_post = float(np.sum(b * w))
    k_post = float(np.log1p(-b_post * x).mean())
    sigma = -k_post / b_post
    return (n * k_post + 10 * 0.5) / (n + 10), sigma


def pareto_khat(log_w: np.ndarray) -> float:
    """Pareto k-hat of importance weights given on the log scale (the PSIS diagnostic)."""
    lw = np.sort(np.asarray(log_w, float)[np.isfinite(log_w)])
    n = len(lw)
    M = int(min(0.2 * n, 3.0 * math.sqrt(n)))
    if M < 5:
        return float("nan")
    top = lw[-1]
    x = np.exp(lw[-M:] - top) - math.exp(lw[-M - 1] - top)
    if not np.all(np.isfinite(x)) or x[-1] <= 0:
        return float("inf")
    x = np.maximum(x, np.finfo(float).tiny)
    return float(_gpdfit(x)[0])


def importance(logp: Callable[[np.ndarray], float], mean: np.ndarray, cov: np.ndarray, *, n: int = 4000,
               df: float = 10.0, rng: np.random.Generator) -> Importance:
    """Importance-sampling estimate of log of the integral of exp(logp), from a multivariate t proposal."""
    from scipy.special import logsumexp
    from scipy.stats import multivariate_t

    mean = np.asarray(mean, float)
    cov = 0.5 * (np.asarray(cov, float) + np.asarray(cov, float).T)
    q = multivariate_t(loc=mean, shape=cov, df=df, seed=rng)
    x = np.atleast_2d(q.rvs(size=n))
    lq = q.logpdf(x)
    lp = np.array([logp(xi) for xi in x], float)
    lw = np.where(np.isfinite(lp), lp - lq, -np.inf)
    log_ml = float(logsumexp(lw) - math.log(n))
    ess = float(np.exp(2.0 * logsumexp(lw) - logsumexp(2.0 * lw)))
    k = pareto_khat(lw)
    return Importance(log_ml, k, ess, n, df, bool(np.isfinite(k) and k <= KHAT_MAX))


# --------------------------------------------------------------------------- Savage-Dickey, nested models
@dataclass(frozen=True)
class SavageDickey:
    log_bf: float                # log p(y | sub-model) - log p(y | full model)
    log_post_density: float      # log p(theta_1 = 0 | y, full model)
    log_prior_density: float     # log p(theta_1 = 0 | full model)
    khat: float                  # Pareto k-hat of the estimator's terms
    rel_mcse: float              # Monte Carlo standard error of the density, relative to it
    n: int


def savage_dickey(logp: Callable[[np.ndarray], float], draws: np.ndarray, drop: Sequence[int],
                  log_prior_density: float, *, logp_draws: np.ndarray | None = None) -> SavageDickey:
    """Bayes factor of a nested sub-model by the Savage-Dickey density ratio.

    The sub-model is the full model with the coordinates ``drop`` of the unconstrained vector set to zero.
    When those coordinates have a prior independent of the others (as the pairwise terms do), the Bayes
    factor is p(theta_1 = 0 | y) / p(theta_1 = 0), both under the full model (Dickey 1971; Verdinelli &
    Wasserman 1995).  The posterior density at zero is estimated from the full model's posterior draws by
    importance-weighted marginal density estimation (Chen 1994):

        p(theta_1* | y) = E[ w(theta_1 | theta_2) p(y, theta_1*, theta_2) / p(y, theta_1, theta_2) ],

    unbiased for any normalised conditional density w; here w is the Gaussian conditional of theta_1 given
    theta_2 implied by the draws' mean and covariance.  ``logp`` is the full model's joint log density
    (unconstrained, with Jacobians); ``draws`` its posterior draws, shape (n, dim).
    """
    from scipy.special import logsumexp

    x = np.asarray(draws, float)
    n, d = x.shape
    drop = np.asarray(sorted(drop), int)
    keep = np.setdiff1d(np.arange(d), drop)
    mu = x.mean(axis=0)
    C = np.cov(x.T)
    C11, C12, C22 = C[np.ix_(drop, drop)], C[np.ix_(drop, keep)], C[np.ix_(keep, keep)]
    B = np.linalg.solve(C22, C12.T).T                             # regression of theta_1 on theta_2
    S = C11 - B @ C12.T
    S = 0.5 * (S + S.T)
    m = mu[drop][None, :] + (x[:, keep] - mu[keep][None, :]) @ B.T
    L = np.linalg.cholesky(S)
    z = np.linalg.solve(L, (x[:, drop] - m).T).T
    log_w = -0.5 * np.sum(z**2, axis=1) - np.log(np.diag(L)).sum() - 0.5 * len(drop) * LOG_2PI
    lp = np.asarray(logp_draws, float) if logp_draws is not None else np.array([logp(xi) for xi in x])
    xs = x.copy()
    xs[:, drop] = 0.0
    lp_star = np.array([logp(xi) for xi in xs])
    terms = log_w + lp_star - lp
    terms = np.where(np.isfinite(terms), terms, -np.inf)
    log_dens = float(logsumexp(terms) - math.log(n))
    w = np.exp(terms - terms.max())
    rel = float(np.std(w, ddof=1) / math.sqrt(n) / np.mean(w)) if np.mean(w) > 0 else float("inf")
    return SavageDickey(log_dens - log_prior_density, log_dens, float(log_prior_density), pareto_khat(terms), rel, n)


@dataclass(frozen=True)
class NestedBridge:
    log_bf: float                # bridge estimate of log p(y | sub-model) - log p(y | full model)
    log_bf_forward: float        # the one-sided Savage-Dickey estimate from the full model's draws (as savage_dickey)
    log_bf_reverse: float        # the one-sided estimate from the sub-model's draws
    khat_forward: float
    khat_reverse: float
    n_iter: int
    converged: bool


def _conditional_gaussian(x: np.ndarray, drop: np.ndarray, keep: np.ndarray):
    """Gaussian conditional of x[:, drop] given x[:, keep], from the draws' mean and covariance."""
    mu = x.mean(axis=0)
    C = np.cov(x.T)
    C12, C22 = C[np.ix_(drop, keep)], C[np.ix_(keep, keep)]
    B = np.linalg.solve(C22, C12.T).T
    S = C[np.ix_(drop, drop)] - B @ C12.T
    L = np.linalg.cholesky(0.5 * (S + S.T))

    def mean(x2):
        return mu[drop][None, :] + (x2 - mu[keep][None, :]) @ B.T

    def logpdf(x1, x2):
        z = np.linalg.solve(L, (x1 - mean(x2)).T).T
        return -0.5 * np.sum(z**2, axis=1) - np.log(np.diag(L)).sum() - 0.5 * len(drop) * LOG_2PI

    def sample(x2, rng):
        return mean(x2) + rng.standard_normal((len(x2), len(drop))) @ L.T

    return logpdf, sample


def nested_bridge(logp: Callable[[np.ndarray], float], full_draws: np.ndarray, sub_draws: np.ndarray,
                  drop: Sequence[int], log_prior_density: float, *, rng: np.random.Generator,
                  logp_full_draws: np.ndarray | None = None, warp: str = "full", max_iter: int = 1000,
                  tol: float = 1e-10) -> NestedBridge:
    """Bayes factor of a nested sub-model by bridge sampling between the two posteriors (Meng & Wong 1996).

    The sub-model is the full model with the coordinates ``drop`` at zero, whose prior is independent of the
    rest (so its joint density is the full model's at zero divided by ``log_prior_density``).  Extended by
    w(theta_1 | theta_2), the Gaussian conditional implied by the full model's draws, the sub-model lives on the
    full model's space with its own normaliser.  ``warp`` moves the extended sub-model by an affine map,
    Jacobian included, towards the full posterior (Meng & Schilling 2002), so the two densities overlap even when
    dropping the terms shifts the others: "mean" (warp-I, a shift), "diag" (shift and per-coordinate scale) or
    "full" (warp-II, mean and covariance); "none" bridges the densities as they are.  The full warp needs both
    covariances, which are noisy in high dimension with autocorrelated draws.  The optimal bridge combines

    * the full model's posterior draws ``full_draws``, and
    * the sub-model's posterior draws ``sub_draws`` in the full model's coordinates (their ``drop`` entries are
      ignored and drawn from w), mapped by the same affine map.

    ``log_bf_forward`` is the one-sided Savage-Dickey estimate from the full draws alone (``savage_dickey``) and
    ``log_bf_reverse`` the one-sided estimate from the sub-model's draws alone, both unwarped, with the Pareto
    k-hat of their weights.  ``logp`` is the full model's joint log density (unconstrained, with Jacobians).
    """
    from scipy.special import logsumexp

    x1 = np.asarray(full_draws, float)
    n1, d = x1.shape
    drop = np.asarray(sorted(drop), int)
    keep = np.setdiff1d(np.arange(d), drop)
    logw, sample = _conditional_gaussian(x1, drop, keep)
    y = np.array(sub_draws, float)
    y[:, drop] = sample(y[:, keep], rng)                            # draws of the extended sub-model
    n2 = len(y)

    def log_q_sub(x):
        """log of the extended sub-model's unnormalised density (normaliser p(y | sub-model))."""
        z = x.copy()
        z[:, drop] = 0.0
        lp0 = np.array([logp(zi) for zi in z])
        return lp0 - log_prior_density + logw(x[:, drop], x[:, keep])

    def log_q_full(x, given=None):
        return np.asarray(given, float) if given is not None else np.array([logp(xi) for xi in x])

    lq_full_x1 = log_q_full(x1, logp_full_draws)
    lq_sub_y = log_q_sub(y)
    clean = lambda a: np.where(np.isfinite(a), a, -np.inf)
    l_fwd = clean(log_q_sub(x1) - lq_full_x1)                      # unwarped, on the full draws
    l_rev = clean(lq_sub_y - log_q_full(y))                         # unwarped, on the sub-model's draws
    forward = float(logsumexp(l_fwd) - math.log(n1))
    reverse = float(-(logsumexp(-l_rev) - math.log(n2)))
    if warp not in ("none", "mean", "diag", "full"):
        raise ValueError(f"unknown warp {warp!r}")
    if warp == "none":
        l_full, l_sub = l_fwd, l_rev
    else:
        mf, ms = x1.mean(axis=0), y.mean(axis=0)
        if warp == "mean":
            A, log_det = np.eye(d), 0.0
        elif warp == "diag":
            sc = y.std(axis=0, ddof=1) / x1.std(axis=0, ddof=1)
            A, log_det = np.diag(sc), float(np.log(sc).sum())
        else:
            Lf, Ls = np.linalg.cholesky(np.cov(x1.T)), np.linalg.cholesky(np.cov(y.T))
            A = Ls @ np.linalg.inv(Lf)
            log_det = float(np.log(np.abs(np.diag(Ls))).sum() - np.log(np.abs(np.diag(Lf))).sum())
        Tx1 = ms + (x1 - mf) @ A.T                                  # T maps the full posterior onto the sub-model
        y_back = mf + np.linalg.solve(A, (y - ms).T).T               # T^-1 of the sub-model's draws
        l_full = clean(log_q_sub(Tx1) + log_det - lq_full_x1)        # warped sub over full, at the full draws
        l_sub = clean(lq_sub_y + log_det - log_q_full(y_back))       # the same ratio at the warped sub draws
    s_sub, s_full = n2 / (n1 + n2), n1 / (n1 + n2)
    log_r = float(logsumexp(l_full) - math.log(n1))
    it, ok = 0, False
    for it in range(1, max_iter + 1):
        num = logsumexp(l_full - np.logaddexp(math.log(s_sub) + l_full, math.log(s_full) + log_r)) - math.log(n1)
        den = logsumexp(-np.logaddexp(math.log(s_sub) + l_sub, math.log(s_full) + log_r)) - math.log(n2)
        new = float(num - den)
        if abs(new - log_r) < tol:
            log_r, ok = new, True
            break
        log_r = new
    return NestedBridge(log_r, forward, reverse, pareto_khat(l_fwd), pareto_khat(-l_rev), it, ok)


# --------------------------------------------------------------------------- PyMC helpers
def pymc_logp_grad(model) -> tuple[LogpGrad, np.ndarray, list[str]]:
    """(logp_grad, initial point, value-variable names) for a PyMC model, raveled in its own order.

    Uses ``Model.logp_dlogp_function`` (log density with every transform's Jacobian).
    """
    from pymc.blocking import DictToArrayBijection

    fn = model.logp_dlogp_function(ravel_inputs=True)
    fn.set_extra_values({})
    ip = model.initial_point()
    names = [v.name for v in model.continuous_value_vars]
    x0 = DictToArrayBijection.map({k: ip[k] for k in names}).data

    def logp_grad(x):
        lp, g = fn(np.asarray(x, float))
        return float(lp), np.asarray(g, float)

    return logp_grad, x0, names
