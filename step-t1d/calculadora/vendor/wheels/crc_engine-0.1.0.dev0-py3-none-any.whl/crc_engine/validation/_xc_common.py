"""Shared helpers of Phase 4 checks 3, 4 and 6: simulated tables, NUTS fits, R calls, output and provenance.

Everything here works on simulated data or on the old app's published reference tables; nothing reads the
study's export, cohort, review files or outputs.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import subprocess
import tempfile
import time
import warnings
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

import numpy as np

from .. import design as study_design
from ..models import THREE_WAY, StructuredDesign, structured_design
from ..modelspace import ModelSpec
from ..tables import CaptureTable

#: CPU budget of the validation runs on the shared machine.
MAX_CORES = 3
#: Pilot output folder (git-ignored: ``pipeline/out/``).
PILOT_DATE = "2026-11-02"
LISTS = ("A", "B", "C")
COVARIATES = ("age_band", "period", "sex")
#: The plan's periods for the main window (analysis plan, "Model space"; ``step_pipeline.config.PERIODS``).
PERIODS = {"2015-2019": (2015, 2019), "2020-2024": (2020, 2024)}
#: E1's strata in the main window: sex x the three childhood age bands x 2015-2024.
E1_LEVELS = {"sex": ("F", "M"), "age_band": tuple(study_design.bands(study_design.E1_MAX_AGE)),
             "year": tuple(range(2015, 2025))}


def repo_root() -> Path:
    """The STEP-T1D repository (the folder holding ``docs/build-plan.md``)."""
    env = os.environ.get("STEP_T1D_ROOT")
    if env:
        return Path(env)
    for p in Path(__file__).resolve().parents:
        if (p / "docs" / "build-plan.md").exists():
            return p
    raise FileNotFoundError("cannot find the repository root; set STEP_T1D_ROOT")


def pilot_dir(check: str) -> Path:
    return repo_root() / "pipeline" / "out" / "validation" / f"pilot-{PILOT_DATE}" / check


def quiet():
    """Silence PyMC's progress logging and the usual warnings during batch runs."""
    for name in ("pymc", "pymc.sampling", "pymc.smc", "pytensor", "nutpie"):
        logging.getLogger(name).setLevel(logging.ERROR)
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)
    warnings.filterwarnings("ignore", category=RuntimeWarning)


def in_fresh_process(fn, /, *args, **kwargs):
    """``fn(*args, **kwargs)`` in a new spawned process, quiet as ``quiet`` makes it; returns its result.

    A process keeps every model it compiles, about 80 MB each, until it exits: the cross-check's 103 fits in one
    process reached 8.9 GB in the first full run (decision 88). ``fn`` and its arguments must pickle."""
    import multiprocessing as mp
    from concurrent.futures import ProcessPoolExecutor

    with ProcessPoolExecutor(max_workers=1, mp_context=mp.get_context("spawn"), initializer=quiet) as ex:
        return ex.submit(fn, *args, **kwargs).result()


# --------------------------------------------------------------------------- seeds and timing
def seeds(root: int, n: int) -> list[int]:
    """``n`` independent integer seeds from one root seed (J14: SeedSequence streams)."""
    return [int(s.generate_state(1)[0]) for s in np.random.SeedSequence(root).spawn(n)]


@dataclass
class Clock:
    seconds: float = 0.0


@contextmanager
def timed():
    c = Clock()
    t0 = time.perf_counter()
    try:
        yield c
    finally:
        c.seconds = time.perf_counter() - t0


# --------------------------------------------------------------------------- samplers
@dataclass(frozen=True)
class Sampler:
    """NUTS settings (the plan's are ``diagnostics.DEFAULT_SAMPLER``); ``cores`` at most ``MAX_CORES``."""

    chains: int = 4
    draws: int = 2000
    tune: int = 2000
    target_accept: float = 0.9
    cores: int = MAX_CORES

    def __post_init__(self):
        if self.cores > MAX_CORES:
            raise ValueError(f"at most {MAX_CORES} cores on the shared machine")

    def as_dict(self) -> dict:
        return {"chains": self.chains, "draws": self.draws, "tune": self.tune, "target_accept": self.target_accept,
                "cores": self.cores}


def nuts(model, sampler: Sampler, seed: int):
    """``pm.sample`` with ``sampler``'s settings; returns the DataTree."""
    import pymc as pm

    with model:
        return pm.sample(draws=sampler.draws, tune=sampler.tune, chains=sampler.chains, cores=sampler.cores,
                         target_accept=sampler.target_accept, random_seed=seed, progressbar=False,
                         compute_convergence_checks=False)


def nuts_sampler_name(idata) -> str:
    attrs = dict(getattr(idata["posterior"], "attrs", {}))
    return str(attrs.get("sampling_library") or attrs.get("inference_library") or "pymc")


def gate_summary(idata, N_draws: np.ndarray) -> dict:
    """The plan's convergence gates (``diagnostics.check_gates``), as plain data."""
    from ..diagnostics import check_gates

    g = check_gates(idata, N_draws=N_draws)
    return {"passed": g.passed, "failures": g.failures,
            "metrics": {k: (v if isinstance(v, (str, type(None))) else float(v)) for k, v in g.metrics.items()}}


# --------------------------------------------------------------------------- simulated tables
def zero_sum(a: np.ndarray, axes) -> np.ndarray:
    """Centre ``a`` along every axis in ``axes`` (repeated centring gives the multi-axis zero-sum projection)."""
    out = np.asarray(a, float)
    for ax in np.atleast_1d(axes):
        out = out - out.mean(axis=int(ax), keepdims=True)
    return out


def e1_table(levels: Mapping[str, tuple] | None = None) -> CaptureTable:
    """An empty capture table with the E1 strata (or ``levels``): the shape of the study, no data."""
    return CaptureTable.empty(LISTS, levels or E1_LEVELS)


def count_truth(levels: Mapping[str, tuple], rng: np.random.Generator, *, log_level: float,
                sex_sd: float = 0.05, age_sd: float = 0.15, year_step_sd: float = 0.05,
                interaction_sd: float = 0.05) -> dict[str, np.ndarray]:
    """True count-part parameters: zero-sum effects, a centred random walk for the year, small interactions.

    ``log_level`` is alpha, the log count part's mean over the stratum-years
    (the log hidden count with the proposed priors' target "hidden").
    """
    from ..models import random_walk

    Ls, La, T = (len(levels[v]) for v in ("sex", "age_band", "year"))
    return {
        "alpha": np.array(log_level),
        "delta_sex": zero_sum(rng.normal(0, sex_sd, Ls), 0),
        "eta_age": zero_sum(rng.normal(0, age_sd, La), 0),
        "gamma": random_walk(rng.normal(0, year_step_sd, T - 1)),
        "delta_eta": zero_sum(rng.normal(0, interaction_sd, (Ls, La)), (0, 1)),
        "delta_gamma": zero_sum(rng.normal(0, interaction_sd, (Ls, T)), (0, 1)),
        "eta_gamma": zero_sum(rng.normal(0, interaction_sd, (La, T)), (0, 1)),
        THREE_WAY: zero_sum(rng.normal(0, interaction_sd, (Ls, La, T)), (0, 1, 2)),
    }


def capture_theta(d: StructuredDesign, beta: Mapping[str, float], pairs: Mapping[str, float] | None = None,
                  list_cov: Mapping[str, Mapping[str, tuple]] | None = None) -> np.ndarray:
    """The capture vector ``theta_capture`` of design ``d`` from readable true values.

    ``beta``: list -> main effect; ``pairs``: "AB" -> lambda; ``list_cov``:
    covariate -> list -> one value per level (centred here, then written in
    the design's effects coding, which drops the last level).

    An AM1 design's list x year columns (decision 122) take ``list_cov["year"]``: AM1's deviations, one per year,
    which must already sum to zero over each of the design's year groups (each period's years when the model has
    list x period, all the years otherwise).  They are taken as given: centring them would turn a vector that breaks
    AM1's constraint into another truth without a word.
    """
    pairs, list_cov = pairs or {}, list_cov or {}
    theta = np.zeros(len(d.capture_columns))
    for i, col in enumerate(d.capture_columns):
        kind, rest = col.split(":", 1)
        if kind == "list" and "×" not in rest:
            theta[i] = beta[rest]
        elif kind == "pair":
            theta[i] = pairs.get(rest, 0.0)
        elif kind == "list":
            lst, cov = rest.split("×", 1)
            var, lev = cov[:-1].split("[", 1)
            vals = (_am1_deviations(d, list_cov[var][lst], lst) if var == "year"
                    else zero_sum(np.asarray(list_cov[var][lst], float), 0))
            theta[i] = vals[list(d.levels[var]).index(_level(d.levels[var], lev))]
        else:
            raise KeyError(col)
    return theta


def _am1_deviations(d: StructuredDesign, values, lst: str) -> np.ndarray:
    """List ``lst``'s AM1 deviations over the design's years, refused unless they sum to zero over each year group."""
    v = np.asarray(values, float)
    years = d.levels["year"]
    if v.shape != (len(years),):
        raise ValueError(f"AM1's list x year deviations of list {lst} need one value per year ({len(years)})")
    for g in d.year_groups or (tuple(range(len(years))),):
        total = float(v[list(g)].sum())
        if abs(total) > 1e-9:
            raise ValueError(f"AM1's list x year deviations of list {lst} must sum to zero over each of its year "
                             f"groups (each period's years with list x period, all the years without it); over "
                             f"{[years[t] for t in g]} they sum to {total:.3g}")
    return v


def _level(levels: tuple, label: str):
    for x in levels:
        if str(x) == label:
            return x
    raise KeyError(label)


def simulate_table(table: CaptureTable, spec: ModelSpec, params: Mapping[str, np.ndarray],
                   rng: np.random.Generator, *, periods=PERIODS, target: str = "hidden",
                   exposure: np.ndarray | None = None) -> tuple[CaptureTable, int, StructuredDesign]:
    """Simulated counts from known parameters with the model's own linear predictor.

    Returns the table, the true N (observed plus hidden, as drawn) and the design used.
    """
    from ..models import simulate_counts

    d = structured_design(table, spec, periods=periods, target=target, exposure=exposure)
    obs, hidden = simulate_counts(params, d, rng)
    return table.with_counts(obs), int(obs.sum() + hidden.sum()), d


# --------------------------------------------------------------------------- R
def r_available() -> bool:
    return shutil.which("Rscript") is not None and (repo_root() / "tools" / "R-lib" / "Rcapture").exists()


def run_r(script: str, payload: Mapping, *, timeout: float = 600.0) -> dict:
    """Run an R script with the project's library (``R_LIBS=tools/R-lib``), JSON in, JSON out.

    The script reads the path in ``Sys.getenv("XC_IN")`` and writes its result
    to ``Sys.getenv("XC_OUT")`` with jsonlite.
    """
    if not r_available():
        raise RuntimeError("Rscript or tools/R-lib/Rcapture is missing")
    with tempfile.TemporaryDirectory(prefix="xc_r_") as tmp:
        tmp = Path(tmp)
        (tmp / "in.json").write_text(json.dumps(payload, default=_json_default))
        (tmp / "script.R").write_text(script)
        env = {**os.environ, "R_LIBS": str(repo_root() / "tools" / "R-lib"), "XC_IN": str(tmp / "in.json"),
               "XC_OUT": str(tmp / "out.json"), "OMP_NUM_THREADS": "1"}
        proc = subprocess.run(["Rscript", "--vanilla", str(tmp / "script.R")], env=env, capture_output=True,
                              text=True, timeout=timeout, cwd=repo_root())
        if proc.returncode != 0:
            raise RuntimeError(f"R failed ({proc.returncode}): {proc.stderr[-2000:]}")
        return json.loads((tmp / "out.json").read_text())


def r_versions() -> dict:
    if not r_available():
        return {}
    script = ('library(jsonlite); library(Rcapture)\n'
              'write_json(list(r=R.version.string, rcapture=as.character(packageVersion("Rcapture"))), '
              'Sys.getenv("XC_OUT"), auto_unbox=TRUE)\n')
    return run_r(script, {})


# --------------------------------------------------------------------------- output
def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"not JSON serialisable: {type(o).__name__}")


def _finite(o):
    """Replace non-finite floats by None so the JSON stays standard."""
    if isinstance(o, float):
        return o if np.isfinite(o) else None
    if isinstance(o, dict):
        return {k: _finite(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_finite(v) for v in o]
    return o


def write_json(path: Path, obj) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(_finite(json.loads(json.dumps(obj, default=_json_default))), indent=2, allow_nan=False)
    path.write_text(text + "\n")
    return path


def git_state() -> dict:
    root = repo_root()
    try:
        sha = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, text=True,
                             check=True).stdout.strip()
        dirty = bool(subprocess.run(["git", "status", "--porcelain", "--untracked-files=no"], cwd=root,
                                    capture_output=True, text=True, check=True).stdout.strip())
    except (OSError, subprocess.CalledProcessError):
        return {"sha": None, "dirty": None}
    return {"sha": sha, "dirty_tracked_files": dirty}


def source_hashes() -> dict:
    """SHA-256 of the engine and validation sources, so a run is traceable even before they are committed."""
    import hashlib

    pkg = Path(__file__).resolve().parents[1]
    files = sorted(pkg.glob("*.py")) + sorted((pkg / "validation").glob("*.py"))
    return {str(f.relative_to(pkg.parent)): hashlib.sha256(f.read_bytes()).hexdigest()[:16] for f in files}


def provenance(**extra) -> dict:
    import scipy
    import pymc
    import pytensor

    out = {"generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "git": git_state(), "source_sha256": source_hashes(), "python": platform.python_version(),
           "versions": {"numpy": np.__version__, "scipy": scipy.__version__, "pymc": pymc.__version__,
                        "pytensor": pytensor.__version__},
           "cpu_budget": MAX_CORES, "data": "simulated or the old app's published reference tables only"}
    try:
        import statsmodels
        out["versions"]["statsmodels"] = statsmodels.__version__
    except ImportError:
        pass
    try:
        import nutpie
        out["versions"]["nutpie"] = nutpie.__version__
    except ImportError:
        pass
    out.update(extra)
    return out
