"""Repeated NUTS fits of one model structure on many simulated datasets (Phase 4 checks 1 and 2).

The refit builds one PyMC model per dataset.  A validation run fits the same model structure to hundreds
of simulated datasets, and nutpie's compile (roughly 40-100 s for an E1-sized model) dwarfs its sampling
(a few seconds).  So each structure is built once with ``models.build_structured_model``, its observed
counts are moved into a shared variable (``pymc.model.fgraph``), and nutpie compiles it once; every
dataset then swaps its counts in (``CompiledPyMCModel.with_data``).  Nothing else in the model changes:
priors, design and exposure are the builder's own.  A test checks that the swapped model's log density
equals a freshly built model's, point by point, after the swap.

``fit_many`` is the worker run in a separate process: it compiles one structure and fits a list of
datasets, returning for each the draws of N (``models.posterior_N``), the draws of a few parameters, the
convergence metrics of ``diagnostics.check_gates``, the timings and, if asked, the Laplace and
importance-sampling estimates of the marginal likelihood (``_core_evidence``).  Every fit has its own
seed, so any single fit can be repeated alone.
"""

from __future__ import annotations

import os
import time
import warnings
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Mapping, Sequence

import numpy as np

from ..amendments import AM1_SIGMA, AM2_KAPPA

#: Short chains for the validation fits (the refit uses 4 x 2 000 + 2 000 tuning, ``diagnostics.DEFAULT_SAMPLER``).
SHORT_SAMPLER = {"chains": 2, "tune": 500, "draws": 500, "target_accept": 0.9}
#: Draws of these variables are returned when the model has them (scalars and small vectors only).  The last two are
#: the amendments' new parameters (decision 122): AM1's scales sigma_l and AM2's dispersion kappa, which
#: ``models.posterior_N`` also reads to draw an AM2 model's hidden counts.  A model without them stores what it did.
DEFAULT_KEEP = ("alpha", "delta_sex", "eta_age", "beta", "lambda", "list_x_age_band", "list_x_period",
                "list_x_sex", "gamma_sigma", "tau", "tau3", AM1_SIGMA, AM2_KAPPA)
#: Variables the compiled model stores besides the unconstrained draws: the kept ones and the hidden means.
STORED = DEFAULT_KEEP + ("hidden_mu",)
DATA_NAME = "y_counts"


def limit_threads(n: int = 1) -> None:
    """Pin BLAS, OpenMP and numba to ``n`` threads (call before numpy is imported in a worker)."""
    for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS",
              "VECLIB_MAXIMUM_THREADS"):
        os.environ[k] = str(n)


def resolve_priors(name: str):
    """A prior set by name: "recalibrated" (``PHASE3_RECALIBRATED["E1"]``) or "proposed" (``PHASE3_PROPOSED``)."""
    from .. import priors

    sets = {"recalibrated": priors.PHASE3_RECALIBRATED["E1"], "proposed": priors.PHASE3_PROPOSED}
    if name not in sets:
        raise KeyError(f"unknown prior set {name!r}; use one of {sorted(sets)}")
    return sets[name]


def observed_vector(counts: np.ndarray) -> np.ndarray:
    """Counts (strata x 7 histories) in the order of the model's observed cells (stratum-major)."""
    return np.ascontiguousarray(np.asarray(counts, dtype=np.int64).reshape(-1))


def swap_observed(model, name: str = "y", data_name: str = DATA_NAME):
    """A copy of ``model`` whose observed data for ``name`` sit in a shared variable called ``data_name``.

    Dimensions are frozen (static shapes compile faster); the data are not, so they can be swapped.
    Returns (model, shared variable).
    """
    import pytensor
    from pymc.model.fgraph import fgraph_from_model, model_from_fgraph, model_named
    from pymc.model.transform.optimization import freeze_dims_and_data

    fg, memo = fgraph_from_model(model)
    const = memo[model[name]].owner.inputs[1]
    shared = pytensor.shared(np.asarray(const.data).copy(), name=data_name)
    fg.replace(const, model_named(shared, data_name), import_missing=True)
    new = freeze_dims_and_data(model_from_fgraph(fg, mutate_fgraph=True), data=[])
    data = next(v for v in new.data_vars if v.name == data_name)
    return new, data


@dataclass
class Compiled:
    """One model structure, compiled once by nutpie, ready for any dataset of the same shape."""

    spec: object                  # ModelSpec
    prior_name: str
    noncentred: bool
    sm: object                    # StructuredModel built by models.build_structured_model on the template counts
    model: object                 # the same model with its counts in a shared variable
    data: object                  # that shared variable
    nut: object                   # nutpie CompiledPyMCModel
    names: list[str]              # unconstrained value variables, in nutpie's joined order
    sizes: list[int]
    compile_seconds: float        # build, swap and nutpie compile
    jit_seconds: float = 0.0      # first call of the Python-callable log density (numba JIT), if warmed

    @property
    def dim(self) -> int:
        return int(sum(self.sizes))

    def set_counts(self, counts: np.ndarray):
        """Put ``counts`` in the shared variable and return the StructuredModel describing them.

        The returned model's ``design.y`` holds the counts, so ``models.posterior_N`` adds the right n.
        """
        y = observed_vector(counts)
        self.data.set_value(y)
        d = self.sm.design
        full = np.array(d.y, float)
        full[~d.hidden] = y
        return replace(self.sm, design=replace(d, y=full))

    def logp_grad(self, x: np.ndarray) -> tuple[float, np.ndarray]:
        """Joint log density (with Jacobians) and gradient at an unconstrained point, for the current counts."""
        lp, g = self.nut.logp_func(np.ascontiguousarray(x, dtype=float))
        return float(lp), np.asarray(g, float)

    def logp(self, x: np.ndarray) -> float:
        return self.logp_grad(x)[0]


def compile_structure(table, spec, prior_name: str, *, exposure: np.ndarray | None = None,
                      periods: Mapping[str, tuple[int, int]] | None = None, noncentred: bool = True,
                      stored: Sequence[str] = STORED, warm_logp: bool = False) -> Compiled:
    """Build ``spec`` on ``table`` with the named prior set, move its counts to a shared variable, compile.

    ``warm_logp`` also makes the first call of the log-density function used by the evidence estimates,
    so its one-off JIT compile is timed here (``jit_seconds``) rather than in the first fit.
    """
    import nutpie

    from ..models import build_structured_model

    t0 = time.perf_counter()
    pri = resolve_priors(prior_name)
    sm = build_structured_model(table, spec, pri, periods=periods,
                                exposure=exposure if pri.count_target == "total" else None, noncentred=noncentred)
    model, data = swap_observed(sm.model)
    have = set(model.named_vars)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        nut = nutpie.compile_pymc_model(model, var_names=[v for v in stored if v in have])
    names = [model.rvs_to_values[rv].name for rv in model.free_RVs]
    ip = model.initial_point()
    sizes = [int(np.size(ip[n])) for n in names]
    if int(sum(sizes)) != nut.n_dim:
        raise RuntimeError("the unconstrained layout does not match nutpie's")
    c = Compiled(spec, prior_name, noncentred, sm, model, data, nut, names, sizes, time.perf_counter() - t0)
    if warm_logp:
        t1 = time.perf_counter()
        c.logp_grad(np.zeros(c.dim))
        c.jit_seconds = time.perf_counter() - t1
    return c


@dataclass
class Fit:
    idata: object
    sm: object                    # StructuredModel holding this dataset's counts
    unconstrained: np.ndarray     # (chains * draws, dim) draws in nutpie's joined order
    seconds: float


def sample(c: Compiled, counts: np.ndarray, *, seed: int, chains: int, tune: int, draws: int,
           target_accept: float) -> Fit:
    """NUTS (nutpie, one thread) on ``counts`` with the compiled structure."""
    import nutpie

    sm = c.set_counts(counts)
    t0 = time.perf_counter()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        idata = nutpie.sample(c.nut.with_data(**{DATA_NAME: observed_vector(counts)}), draws=draws, tune=tune,
                              chains=chains, cores=1, seed=int(seed), progress_bar=False, save_warmup=False,
                              target_accept=target_accept, store_unconstrained=True)
    secs = time.perf_counter() - t0
    return Fit(idata, sm, unconstrained_draws(c, idata), secs)


def unconstrained_draws(c: Compiled, idata) -> np.ndarray:
    """Draws in nutpie's joined unconstrained order, shape (chains * draws, dim).

    nutpie keeps transformed value variables (``tau_log__``, ``..._zerosum__``) in the
    ``unconstrained_posterior`` group and untransformed ones (``alpha``, ``beta``, ``gamma_z``) in
    ``posterior``.
    """
    groups = [idata["unconstrained_posterior"], idata["posterior"]]
    parts = []
    for name, size in zip(c.names, c.sizes):
        g = next(g for g in groups if name in g.data_vars)
        a = np.asarray(g[name].values, float)
        parts.append(a.reshape(a.shape[0] * a.shape[1], size))
    return np.concatenate(parts, axis=1)


def _gate_metrics(idata, N: np.ndarray, unconstrained: np.ndarray, chains: int) -> dict:
    from arviz_base import from_dict
    import arviz_stats as azs

    from ..diagnostics import check_gates

    g = check_gates(idata, N_draws=N)
    m = {k: (float(v) if isinstance(v, (int, float, np.floating, np.integer)) and v is not None else v)
         for k, v in g.metrics.items()}
    u = unconstrained.reshape(chains, -1, unconstrained.shape[-1])
    t = from_dict({"posterior": {"u": u}})
    m["rhat_unconstrained_max"] = float(np.nanmax(azs.rhat(t)["u"].values))
    m["ess_bulk_unconstrained_min"] = float(np.nanmin(azs.ess(t, method="bulk")["u"].values))
    m["gates_passed"] = bool(g.passed)
    m["gate_failures"] = list(g.failures)
    return m


def unconstrained_file(key, label: str) -> str:
    """File name of one fit's unconstrained draws (float32 .npy), from its dataset key and dependence label."""
    return f"u_{label}_{key[0]}_r{int(key[1]):03d}.npy"


def pair_label(pairs) -> str:
    """'AB+BC' for a set of pairs, 'indep' for none (the dependence part of ``ModelSpec.name``)."""
    from ._core_sim import LISTS

    order = sorted(pairs, key=lambda p: (LISTS.index(p[0]), LISTS.index(p[1])))
    return "+".join(a + b for a, b in order) or "indep"


def savage_dickey_subsets(c: Compiled, draws: np.ndarray) -> dict[str, dict]:
    """log Bayes factor of every sub-model that drops some of ``c``'s pairwise terms, against ``c`` itself.

    Uses ``_core_evidence.savage_dickey`` on the draws of ``c`` (counts already set).  Keys are the
    sub-models' dependence labels ('indep', 'AB', ...).  The pairs have independent Normal priors, so the
    Savage-Dickey ratio is exact up to Monte Carlo error.
    """
    import itertools
    import math

    from ._core_evidence import savage_dickey

    spec = c.spec
    if not spec.pairs:
        return {}
    start = int(sum(c.sizes[: c.names.index("lambda")]))
    order = sorted(spec.pairs, key=lambda p: (spec.lists.index(p[0]), spec.lists.index(p[1])))
    mu, sd = c.sm.priors.pairs.mu, c.sm.priors.pairs.sigma
    log_prior_one = -0.5 * math.log(2.0 * math.pi * sd**2) - 0.5 * (mu / sd) ** 2      # log N(0; mu, sd)
    lp = np.array([c.logp(x) for x in draws])
    out = {}
    for r in range(1, len(order) + 1):
        for drop in itertools.combinations(range(len(order)), r):
            log_prior = float(len(drop) * log_prior_one)
            res = savage_dickey(c.logp, draws, [start + j for j in drop], log_prior, logp_draws=lp)
            label = pair_label([p for j, p in enumerate(order) if j not in drop])
            out[label] = {"log_bf": res.log_bf, "khat": res.khat, "rel_mcse": res.rel_mcse}
    return out


def layout(c: Compiled) -> dict:
    """The unconstrained layout of a compiled structure: value variables, sizes and the order of its pairs."""
    order = sorted(c.spec.pairs, key=lambda p: (c.spec.lists.index(p[0]), c.spec.lists.index(p[1])))
    return {"names": list(c.names), "sizes": list(c.sizes), "pairs": [a + b for a, b in order]}


def to_full_coordinates(full: Compiled, sub_layout: Mapping, draws: np.ndarray) -> tuple[np.ndarray, list[int]]:
    """Map a sub-model's unconstrained draws to the full model's coordinates.

    Every value variable has the same name, transform and size in both models (they differ only in their
    pairs); the pairs the sub-model lacks are left at zero and their indices returned (the ``drop`` set).
    """
    off, o = {}, 0
    for n, k in zip(full.names, full.sizes):
        off[n] = (o, k)
        o += k
    lam = {p: off["lambda"][0] + j for j, p in enumerate(layout(full)["pairs"])}
    out = np.zeros((len(draws), full.dim))
    o = 0
    for n, k in zip(sub_layout["names"], sub_layout["sizes"]):
        if n == "lambda":
            for j, p in enumerate(sub_layout["pairs"]):
                out[:, lam[p]] = draws[:, o + j]
        else:
            fo, fk = off[n]
            if fk != k:
                raise ValueError(f"{n} has size {k} in the sub-model and {fk} in the full model")
            out[:, fo:fo + k] = draws[:, o:o + k]
        o += k
    drop = sorted(lam[p] for p in lam if p not in sub_layout["pairs"])
    return out, drop


def bridge_subsets(c: Compiled, draws: np.ndarray, subs: Mapping[str, tuple[Mapping, np.ndarray]], *,
                   rng: np.random.Generator, warp: str = "full") -> dict[str, dict]:
    """log Bayes factor of each sub-model against ``c`` by ``_core_evidence.nested_bridge`` (counts already set).

    ``subs`` maps a sub-model's label to (its layout, its posterior draws on the same dataset).  The default warp
    (warp-II: mean and covariance) was the closest to SMC on a probe dataset over four MCMC seeds.
    """
    import math

    from ._core_evidence import nested_bridge

    mu, sd = c.sm.priors.pairs.mu, c.sm.priors.pairs.sigma
    log_prior_one = -0.5 * math.log(2.0 * math.pi * sd**2) - 0.5 * (mu / sd) ** 2      # log N(0; mu, sd)
    lp = np.array([c.logp(x) for x in draws])
    out = {}
    for label, (lay, sub_draws) in subs.items():
        y, drop = to_full_coordinates(c, lay, np.asarray(sub_draws, float))
        b = nested_bridge(c.logp, draws, y, drop, len(drop) * log_prior_one, rng=rng, logp_full_draws=lp, warp=warp)
        out[label] = {"log_bf": b.log_bf, "log_bf_forward": b.log_bf_forward, "log_bf_reverse": b.log_bf_reverse,
                      "khat_forward": b.khat_forward, "khat_reverse": b.khat_reverse, "n_iter": b.n_iter,
                      "converged": b.converged}
    return out


def fit_many(job: Mapping) -> dict:
    """Worker: compile one structure, fit every dataset in ``job["datasets"]``; returns plain data.

    job keys: table_levels (levels of sex, age_band, year), exposure, periods, spec, prior_name, noncentred,
    sampler (chains, tune, draws, target_accept), evidence (bool), importance_draws, keep (variable names),
    datasets: list of {"key": ..., "counts": (S, 7) ints, "seed": int}.
    """
    limit_threads(1)
    warnings.filterwarnings("ignore")
    from ..models import posterior_N
    from ..tables import CaptureTable
    from ._core_evidence import importance, laplace

    t_job = time.perf_counter()
    table = CaptureTable.empty(job["lists"], job["table_levels"])
    c = compile_structure(table, job["spec"], job["prior_name"], exposure=job.get("exposure"),
                          periods=job.get("periods"), noncentred=job.get("noncentred", True),
                          warm_logp=bool(job.get("evidence", False)))
    smp = dict(SHORT_SAMPLER, **job.get("sampler", {}))
    keep = tuple(job.get("keep", DEFAULT_KEEP))
    out = []
    for ds in job["datasets"]:
        ss = np.random.SeedSequence(int(ds["seed"]))
        s_nuts, s_N, s_is = (int(x.generate_state(1)[0]) for x in ss.spawn(3))
        rec = {"key": ds["key"], "seed": int(ds["seed"]), "n": int(np.asarray(ds["counts"]).sum())}
        t0 = time.perf_counter()
        fit = sample(c, ds["counts"], seed=s_nuts, **smp)
        rec["seconds_sample"] = fit.seconds
        _, N = posterior_N(fit.sm, fit.idata, np.random.default_rng(s_N))
        rec["N"] = np.asarray(N, np.int64).reshape(-1)
        post = fit.idata["posterior"]
        rec["params"] = {k: np.asarray(post[k].values, float).reshape(-1, *post[k].shape[2:])
                         for k in keep if k in post.data_vars}
        t1 = time.perf_counter()
        rec["gates"] = _gate_metrics(fit.idata, N, fit.unconstrained, smp["chains"])
        rec["seconds_gates"] = time.perf_counter() - t1
        if job.get("save_unconstrained"):
            np.save(Path(job["save_unconstrained"]) / unconstrained_file(rec["key"], pair_label(c.spec.pairs)),
                    fit.unconstrained.astype(np.float32))
        if job.get("evidence", False):
            c.set_counts(ds["counts"])
            x0 = fit.unconstrained.mean(axis=0)
            t2 = time.perf_counter()
            rec["savage_dickey"] = savage_dickey_subsets(c, fit.unconstrained)
            if job.get("bridge_from"):
                subs = {lab: (info["layout"], np.load(Path(info["dir"]) / unconstrained_file(rec["key"], lab)))
                        for lab, info in job["bridge_from"].items()}
                rec["bridge"] = bridge_subsets(c, fit.unconstrained, subs, rng=np.random.default_rng(s_is + 1))
            t3 = time.perf_counter()
            lap = laplace(c.logp_grad, x0)
            rec["laplace"] = {"log_ml": lap.log_ml, "converged": lap.converged, "grad_norm": lap.grad_norm,
                              "logp_mode": lap.logp_mode, "n_newton": lap.n_newton}
            t4 = time.perf_counter()
            rec["seconds_savage_dickey"], rec["seconds_laplace"] = t3 - t2, t4 - t3
            if int(job.get("importance_draws", 0)) > 0:
                imp = importance(c.logp, x0, np.cov(fit.unconstrained.T), n=int(job["importance_draws"]),
                                 df=float(job.get("importance_df", 10.0)), rng=np.random.default_rng(s_is))
                rec["importance"] = {"log_ml": imp.log_ml, "khat": imp.khat, "ess": imp.ess, "n": imp.n,
                                     "df": imp.df, "reliable": imp.reliable}
                rec["seconds_importance"] = time.perf_counter() - t4
        rec["seconds_total"] = time.perf_counter() - t0
        out.append(rec)
    return {"spec": job["spec"].name, "label": pair_label(job["spec"].pairs), "layout": layout(c),
            "prior_name": job["prior_name"],
            "noncentred": c.noncentred,
            "compile_seconds": c.compile_seconds, "jit_seconds": c.jit_seconds, "dim": c.dim, "results": out,
            "job_seconds": time.perf_counter() - t_job, "pid": os.getpid()}
