"""Phase 4, check 6: the old CRC app's reference tables, refitted by crc-engine.

**In plain words.** The old calculator shipped four test tables with answers computed by the R package it
used (Rcapture).  The new engine fits the same tables with its own Bayesian models and must land close to
those answers; the simple two-list estimate must match exactly.

**Technically.** ``legacy/capture-recapture/validation_results.json`` (R 4.6.0, Rcapture 1.4.4,
2026-05-16) holds a two-list Chapman case and three log-linear tables (three, four and three lists).  The
log-linear tables are fitted under the matching crc-engine models, independence = Rcapture's Mt and equal
capture = M0 (``ModelSpec.independence`` and ``ModelSpec.classical_m0``), with the Phase 1 builder
``models.build_model`` (one stratum, so the structured count part does not apply), the proposed priors
(the intercept, the log hidden count, Normal(log 10, 2.5)) and the plan's NUTS settings; N = n + M with
M ~ Poisson(hidden mean) per draw.

How the references were made, and the conventions that differ (read from the legacy files and reproduced
here with Rcapture 1.4.4 from ``tools/R-lib``):

* N-hat is Rcapture's Poisson log-linear estimate, n + exp(intercept) (``closedp.t`` on the frequency
  table, equivalently on one row per person); its Rcapture profile-likelihood point estimate differs.
* The intervals in the file are Wald intervals, N-hat +/- 1.96 SE, computed by the old app, not Rcapture's;
  they can fall below the number observed (audit T2).  crc-engine reports Chao's log-normal interval for
  Chapman and posterior intervals for the log-linear models, so intervals are reported, never compared.
* The old app's validation page (``validate-models.html``) passes each history once, without its
  frequency, to ``closedp.t``; the reference file was evidently made with the frequencies, so that page
  compared a different fit with the file.  ``rcapture_rerun`` shows both.
* ``n_individuals`` means the simulated population (500) in the Chapman case and the observed count in
  the log-linear cases; the observed count in the Chapman case is n1 + n2 - m.
* The file's ``best_model`` (by BIC) includes Rcapture's behavioural models Mb and Mbh, which depend on
  the order of the lists (audit T1) and have no counterpart in crc-engine; they are not compared.

Pass rule (build plan, Phase 4): posterior medians within 3% of Rcapture's estimates; the Chapman estimate
exact (equal to the file's 10 printed decimals).
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from ..chapman import chapman, wald_interval
from ..mle import fit_design
from ..models import build_model, theta_draws
from ..modelspace import ModelSpec, design_matrix
from ..ppc import hidden_and_total
from ..priors import PHASE3_PROPOSED
from ..tables import CaptureTable
from . import _xc_common as xc

MEDIAN_TOLERANCE = 0.03
#: The reference file prints 10 decimals; "exact" means equal at that precision.
EXACT_ABS = 0.5e-10
TABLES = ("loglinear_3source", "loglinear_4source", "loglinear_3source_high_overlap")
MODELS = {"Mt": ModelSpec.independence, "M0": ModelSpec.classical_m0}
ROOT_SEED = 20261106


def reference_path() -> Path:
    return xc.repo_root() / "legacy" / "capture-recapture" / "validation_results.json"


def load_reference() -> dict:
    return json.loads(reference_path().read_text())


def reference_table(ref: dict, name: str) -> CaptureTable:
    t = ref["tests"][name]
    return CaptureTable.from_frequencies(pd.DataFrame(t["capture_history"]), t["sources"], count="freq")


def reference_models(ref: dict, name: str) -> dict[str, dict]:
    return {m["model"]: m for m in ref["tests"][name]["all_models"]}


# ----------------------------------------------------------------------------------- Chapman
def chapman_check(ref: dict) -> dict:
    c = ref["tests"]["chapman_2source"]
    r = chapman(c["source1_captures"], c["source2_captures"], c["overlap"])
    want = c["chapman"]
    lo, hi = r.N - 1.96 * r.se, r.N + 1.96 * r.se                # the old app's formula, z = 1.96
    return {
        "n1": r.n1, "n2": r.n2, "m": r.m, "observed": r.observed, "n_individuals_field": c["n_individuals"],
        "N": r.N, "N_reference": want["Nhat"], "N_abs_diff": abs(r.N - want["Nhat"]),
        "exact": bool(abs(r.N - want["Nhat"]) <= EXACT_ABS),
        "se": r.se, "se_reference": want["se"], "se_exact": bool(abs(r.se - want["se"]) <= EXACT_ABS),
        "wald_z196": [lo, hi], "wald_reference": [want["ci_low"], want["ci_high"]],
        "wald_z196_matches_reference": bool(abs(lo - want["ci_low"]) < 1e-6 and abs(hi - want["ci_high"]) < 1e-6),
        "wald_engine_exact_quantile": list(wald_interval(r.N, r.se)),
        "chao_interval_engine": [r.lower, r.upper],
        "note": ("the file's interval is the old app's Wald N +/- 1.96 SE; chapman.wald_interval uses the exact "
                 "normal quantile (1.95996), and crc-engine reports Chao's log-normal interval, bounded below by n"),
    }


# --------------------------------------------------------------------------------- Rcapture
R_RERUN = r"""
suppressPackageStartupMessages({library(jsonlite); library(Rcapture)})
inp <- fromJSON(Sys.getenv("XC_IN"), simplifyVector = FALSE)
one <- function(fit) {
  r <- fit$results
  list(models = rownames(r), abundance = unname(r[, "abundance"]), stderr = unname(r[, "stderr"]),
       AIC = unname(r[, "AIC"]), BIC = unname(r[, "BIC"]))
}
res <- lapply(inp$tables, function(t) {
  H <- matrix(unlist(t$histories), ncol = t$K, byrow = TRUE)
  colnames(H) <- unlist(t$sources)
  freq <- unlist(t$freq)
  with_freq <- one(suppressWarnings(closedp.t(cbind(H, freq), dfreq = TRUE)))
  expanded <- one(suppressWarnings(closedp.t(H[rep(seq_len(nrow(H)), freq), , drop = FALSE])))
  page <- tryCatch(one(suppressWarnings(closedp.t(as.data.frame(H)))),
                   error = function(e) list(error = conditionMessage(e)))
  list(name = t$name, with_freq = with_freq, expanded = expanded, page_call = page)
})
write_json(list(tables = res), Sys.getenv("XC_OUT"), auto_unbox = TRUE, digits = NA)
"""


def rcapture_rerun(ref: dict) -> dict:
    """Rcapture 1.4.4 on each table three ways: frequencies, one row per person, and the old page's call."""
    payload = []
    for name in TABLES:
        t = ref["tests"][name]
        rows = t["capture_history"]
        payload.append({"name": name, "K": len(t["sources"]), "sources": t["sources"],
                        "histories": [[r[s] for s in t["sources"]] for r in rows], "freq": [r["freq"] for r in rows]})
    got = {t["name"]: t for t in xc.run_r(R_RERUN, {"tables": payload})["tables"]}
    out = {}
    for name in TABLES:
        refm = reference_models(ref, name)
        g = got[name]

        def compare(fit):
            if "error" in fit:
                return {"error": fit["error"]}
            rel = {m: abs(a / refm[m]["Nhat"] - 1) for m, a in zip(fit["models"], fit["abundance"]) if m in refm}
            se = {m: abs(s / refm[m]["se"] - 1) for m, s in zip(fit["models"], fit["stderr"]) if m in refm}
            return {"max_rel_N": max(rel.values()), "max_rel_se": max(se.values()),
                    "N": dict(zip(fit["models"], fit["abundance"]))}

        wald = max(max(abs(m["Nhat"] - 1.96 * m["se"] - m["ci_low"]), abs(m["Nhat"] + 1.96 * m["se"] - m["ci_high"]))
                   for m in refm.values())
        out[name] = {"frequency_table": compare(g["with_freq"]), "one_row_per_person": compare(g["expanded"]),
                     "old_page_call_without_frequencies": compare(g["page_call"]),
                     "reference_intervals_are_wald_max_abs_diff": wald}
    return out


# --------------------------------------------------------------------------------- Bayesian fits
def bayes_fit(table: CaptureTable, spec: ModelSpec, sampler: xc.Sampler, seed: int) -> dict:
    with xc.timed() as t_build:
        model, design = build_model(table, spec, PHASE3_PROPOSED)
    with xc.timed() as t_fit:
        idata = xc.nuts(model, sampler, seed)
    _, N = hidden_and_total(design.X_hidden, theta_draws(idata), table.n_observed, np.random.default_rng(seed + 1))
    q = np.quantile(N, [0.025, 0.5, 0.975])
    mle = fit_design(design_matrix(spec, table))
    return {"median": float(q[1]), "lower": float(q[0]), "upper": float(q[2]), "mean": float(N.mean()),
            "N_mle_engine": mle.N, "gates": xc.gate_summary(idata, N), "sampler": xc.nuts_sampler_name(idata),
            "seconds_build": t_build.seconds, "seconds_fit": t_fit.seconds}


def run(out_dir=None, *, sampler: xc.Sampler = xc.Sampler(), seed: int = ROOT_SEED, with_r: bool = True) -> dict:
    """Run check 6 and write ``results.json`` and ``fits.csv`` to ``out_dir`` (if given)."""
    xc.quiet()
    ref = load_reference()
    result = {"check": "6: CRC app references", "reference": str(reference_path().relative_to(xc.repo_root())),
              "reference_generated": {k: ref[k] for k in ("generated_at", "r_version", "rcapture_version")},
              "rule": {"median_within": MEDIAN_TOLERANCE, "chapman_exact_abs": EXACT_ABS},
              "sampler": sampler.as_dict(), "root_seed": seed, "priors": PHASE3_PROPOSED.name}
    with xc.timed() as t_all:
        result["chapman"] = chapman_check(ref)
        if with_r and xc.r_available():
            result["rcapture_rerun"] = rcapture_rerun(ref)
        fits = []
        fit_seeds = iter(xc.seeds(seed, 64))
        for name in TABLES:
            table = reference_table(ref, name)
            refm = reference_models(ref, name)
            for label, make in MODELS.items():
                b = bayes_fit(table, make(table.lists), sampler, next(fit_seeds))
                rel = b["median"] / refm[label]["Nhat"] - 1
                fits.append({"table": name, "model": label, "lists": len(table.lists), "n_observed": table.n_observed,
                             "N_rcapture": refm[label]["Nhat"], "se_rcapture": refm[label]["se"],
                             "wald_rcapture": [refm[label]["ci_low"], refm[label]["ci_high"]],
                             **{k: v for k, v in b.items() if k != "gates"}, "rel_median_vs_rcapture": rel,
                             "pass": bool(abs(rel) <= MEDIAN_TOLERANCE), "gates_passed": b["gates"]["passed"],
                             "gate_failures": b["gates"]["failures"], "gate_metrics": b["gates"]["metrics"]})
        result["fits"] = fits
    result["passed"] = bool(result["chapman"]["exact"] and all(f["pass"] for f in fits))
    result["seconds_total"] = t_all.seconds
    result["provenance"] = xc.provenance(r=xc.r_versions() if with_r and xc.r_available() else None)
    if out_dir is not None:
        xc.write_json(Path(out_dir) / "results.json", result)
        pd.DataFrame([{k: v for k, v in f.items() if k not in ("gate_failures", "gate_metrics", "wald_rcapture")}
                      for f in fits]
                     ).to_csv(Path(out_dir) / "fits.csv", index=False)
    return result


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--out", default=str(xc.pilot_dir("check6-app-references")))
    p.add_argument("--draws", type=int, default=2000)
    p.add_argument("--tune", type=int, default=2000)
    p.add_argument("--chains", type=int, default=4)
    p.add_argument("--cores", type=int, default=xc.MAX_CORES)
    p.add_argument("--seed", type=int, default=ROOT_SEED)
    p.add_argument("--no-r", action="store_true")
    a = p.parse_args(argv)
    res = run(a.out, sampler=xc.Sampler(a.chains, a.draws, a.tune, cores=a.cores), seed=a.seed, with_r=not a.no_r)
    print(f"check 6 {'PASSED' if res['passed'] else 'FAILED'}; {res['seconds_total']:.0f} s; written to {a.out}")


if __name__ == "__main__":
    main()
