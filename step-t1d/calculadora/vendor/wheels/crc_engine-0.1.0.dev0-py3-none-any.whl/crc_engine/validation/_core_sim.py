"""Simulated study shape and data-generating scenarios for Phase 4 checks 1 (recovery) and 2 (SBC).

Everything here is simulated.  The strata mirror the shape of the E1 cohort (2 sexes x 3 age bands x
10 years of diagnosis, 2015-2024: 60 stratum-years, 420 observed cells), but no export, cohort, review
file or study output is read.  Person-years are synthetic, in the range the analysis plan prints for the
DANE population (about 100 000 to 140 000 per E1 stratum-year), so the recalibrated prior set, whose
count part is a log incidence rate, can be fitted.

A scenario fixes the truth: expected people per stratum-year, Lambda[s] = PY[s] x rate[s], and the
probability of each of the 8 capture histories, so the expected cell counts are mu[s, h] = Lambda[s] x
pi[s, h].  A replicate draws every cell, the hidden one included, as an independent Poisson count (a
Poisson number of people per stratum-year, each assigned a history), so the realised N = n + hidden is
known.  In a scenario inside the model space, pi is exactly a member of the fitted family:

    pi[s, h] = exp(cap[s, h]) / sum_h' exp(cap[s, h']),   cap[s, 0] = 0,
    cap[s, h] = sum_j h_j (beta_j + beta_j,age(s) + beta_j,period(s) + beta_j,sex(s)) + sum_{j<k} h_j h_k lambda_jk

and ``Truth.params`` gives the same truth in the PyMC model's own parametrization (target "total");
a test checks that ``models.linear_predictor`` reproduces the cell means from it.  Misspecified
scenarios add what the model space cannot represent: an A:B:C term, people who differ in how easily any
list finds them (a latent class), or capture that moves from year to year within a period.

The amendments of the model space (decision 122) move that line.  AM1's list x year term takes capture that moves
from year to year, so ``list-by-year`` is inside AM1's space; AM2's NB1 counts take a truth whose every cell is NB1
(``Scenario.nb1_kappa``).  ``Scenario.in_space_under`` says which truths each space holds, and
``Truth.params_under`` writes a truth in an amended model's parametrization.  The scenarios added for the amendments'
check 1 (decisions 122 and 123) are in ``AMENDMENT_SCENARIOS``, apart from ``SCENARIOS``, so the frozen check's
runs, defaults and estimates are as they were; ``find_scenario`` looks in both.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field, replace
from typing import Mapping, Sequence

import numpy as np

from .. import design
from ..amendments import AM1, AM2_KAPPA, AMENDMENTS
from ..modelspace import ModelSpec
from ..models import THREE_WAY
from ..ppc import nb1_draws
from ..tables import CaptureTable, histories

LISTS = ("A", "B", "C")
PAIRS = tuple(a + b for a, b in itertools.combinations(LISTS, 2))       # AB, AC, BC
SEXES = ("F", "M")
AGE_BANDS = tuple(design.bands(design.E1_MAX_AGE))                      # the E1 bands, read from the study design
YEARS = tuple(range(2015, 2025))
PERIODS = {"2015-2019": (2015, 2019), "2020-2024": (2020, 2024)}
COVARIATES = ("age_band", "period", "sex")
#: Capture histories in the engine's order (first list most significant bit), the hidden one first.
HISTORIES = histories(len(LISTS), include_unobserved=True)


def study_table() -> CaptureTable:
    """An empty table with the E1 strata: sex x age band x year (60 stratum-years)."""
    return CaptureTable.empty(LISTS, {"sex": SEXES, "age_band": AGE_BANDS, "year": YEARS})


def stratum_index(table: CaptureTable) -> dict[str, np.ndarray]:
    """Level index of sex, age band, period and year for every stratum, in the table's row order."""
    st = table.strata
    year = np.array([int(y) for y in st["year"]])
    period = np.array([next(i for i, (lo, hi) in enumerate(PERIODS.values()) if lo <= y <= hi) for y in year])
    return {"sex": np.array([SEXES.index(x) for x in st["sex"]]),
            "age_band": np.array([AGE_BANDS.index(x) for x in st["age_band"]]),
            "year": np.array([YEARS.index(y) for y in year]), "period": period}


def synthetic_person_years(table: CaptureTable) -> np.ndarray:
    """Made-up person-years per stratum, deterministic, between about 100 000 and 140 000.

    Smooth in age band, sex and year; no population file is read.
    """
    ix = stratum_index(table)
    t = ix["year"] - (len(YEARS) - 1) / 2
    return (120_000.0 * (1.0 + 0.08 * (1 - ix["age_band"])) * (1.0 + 0.02 * (2 * ix["sex"] - 1))
            * (1.0 - 0.01 * t))


def _zero_sum_rows(rows: Sequence[Sequence[float]], L: int, what: str) -> np.ndarray:
    a = np.asarray(rows, float)
    if a.shape != (len(LISTS), L):
        raise ValueError(f"{what} needs one row of {L} effects per list")
    if not np.allclose(a.sum(axis=1), 0.0):
        raise ValueError(f"{what}: each list's effects must sum to zero (sum-to-zero coding)")
    return a


@dataclass(frozen=True)
class Scenario:
    """A data-generating truth.  Effects are on the log scale; odds ratios are given as ratios."""

    name: str
    description: str
    N: float                                       # expected people over the 60 stratum-years
    completeness: float                            # expected share recorded by at least one list, whole window
    pairs: Mapping[str, float] = field(default_factory=dict)          # "AB" -> odds ratio of being on both lists
    covariates: tuple[str, ...] = ("age_band", "period")              # list x covariate terms of the truth
    list_offsets: tuple[float, float, float] = (-0.6, 0.3, 0.0)       # relative capture log-odds of A, B, C
    list_age: tuple = ((0.4, 0.0, -0.4), (-0.2, 0.0, 0.2), (0.0, 0.2, -0.2))   # list x age band, zero-sum per list
    list_period: tuple = ((0.3, -0.3), (-0.1, 0.1), (0.0, 0.0))                  # list x period, zero-sum per list
    list_sex: tuple = ((0.0, 0.0), (0.0, 0.0), (0.0, 0.0))                       # list x sex, zero-sum per list
    rate_age: tuple[float, float, float] = (-0.35, 0.0, 0.35)          # log rate by age band
    rate_sex: tuple[float, float] = (-0.05, 0.05)                      # log rate by sex (F, M)
    trend: float = 0.03                                                # log rate change per year
    noise_sd: float = 0.10                                             # fixed stratum-year deviations of the log rate
    # ---- outside the model space
    three_way: float = 1.0                         # A:B:C factor on the odds (1 = none)
    latent: tuple[float, float] | None = None      # (share of people, shift of their capture log-odds on every list)
    list_year: Mapping[str, Mapping[int, float]] = field(default_factory=dict)  # list -> year -> extra log-odds
    seed: int = 0                                  # seed of the fixed stratum-year deviations
    # ---- inside AM2's space only (decision 122): every cell, the hidden one included, NB1(mu, kappa); None: Poisson
    nb1_kappa: float | None = None

    def __post_init__(self):
        if not 0.0 < self.completeness < 1.0 or self.N <= 0:
            raise ValueError("completeness must be in (0, 1) and N positive")
        if set(self.pairs) - set(PAIRS):
            raise ValueError(f"pairs must be among {PAIRS}")
        if any(v <= 0 for v in self.pairs.values()) or self.three_way <= 0:
            raise ValueError("odds ratios must be positive")
        if set(self.covariates) - set(COVARIATES):
            raise ValueError(f"covariates must be among {COVARIATES}")
        _zero_sum_rows(self.list_age, len(AGE_BANDS), "list_age")
        _zero_sum_rows(self.list_period, len(PERIODS), "list_period")
        _zero_sum_rows(self.list_sex, len(SEXES), "list_sex")
        for cov, rows in (("age_band", self.list_age), ("period", self.list_period), ("sex", self.list_sex)):
            if cov not in self.covariates and np.any(np.asarray(rows, float) != 0):
                raise ValueError(f"list x {cov} effects are set but {cov!r} is not among the covariates")
        if self.latent is not None and not 0.0 < self.latent[0] < 1.0:
            raise ValueError("the latent share must be in (0, 1)")
        if set(self.list_year) - set(LISTS) or any(set(v) - set(YEARS) for v in self.list_year.values()):
            raise ValueError("list_year maps a list to {year: effect} within the study years")
        if self.nb1_kappa is not None and not (math.isfinite(self.nb1_kappa) and self.nb1_kappa > 0):
            raise ValueError("nb1_kappa, the NB1 dispersion of every cell, must be finite and positive (None: Poisson)")

    @property
    def _moves_by_year(self) -> bool:
        return any(v != 0 for d in self.list_year.values() for v in d.values())

    @property
    def in_space(self) -> bool:
        """True when the generating model is one of the fitted models."""
        return (self.three_way == 1.0 and self.latent is None and not self._moves_by_year
                and self.nb1_kappa is None)

    def in_space_under(self, amendment: str | None) -> bool:
        """True when the generating model is one of the fitted models with ``amendment`` applied (decision 122).

        None is the frozen space (``in_space``).  AM1 adds a list x year term, which takes any list x year effect, and
        its scales at zero give the frozen model; AM2 makes the counts NB1, which takes an NB1 truth, and its limit
        kappa -> 0 is the frozen Poisson model.  So a frozen in-space truth is inside both amended spaces,
        ``list-by-year`` is inside AM1's and an NB1 truth inside AM2's.
        """
        if amendment is None:
            return self.in_space
        if amendment not in AMENDMENTS:
            raise ValueError(f"unknown amendment {amendment!r}; the amendments are {sorted(AMENDMENTS)}")
        if self.three_way != 1.0 or self.latent is not None:
            return False
        if amendment == AM1.id:
            return self.nb1_kappa is None
        return not self._moves_by_year

    @property
    def spec(self) -> ModelSpec:
        """The fitted model with the truth's dependence structure and covariate setting."""
        return ModelSpec(LISTS, frozenset((p[0], p[1]) for p in self.pairs), tuple(self.covariates))

    def as_dict(self) -> dict:
        return {"name": self.name, "description": self.description, "N": self.N, "completeness": self.completeness,
                "pairs": dict(self.pairs), "covariates": list(self.covariates), "list_offsets": list(self.list_offsets),
                "list_age": [list(r) for r in self.list_age], "list_period": [list(r) for r in self.list_period],
                "list_sex": [list(r) for r in self.list_sex], "rate_age": list(self.rate_age),
                "rate_sex": list(self.rate_sex), "trend": self.trend, "noise_sd": self.noise_sd,
                "three_way": self.three_way, "latent": None if self.latent is None else list(self.latent),
                "list_year": {k: {str(y): v for y, v in d.items()} for k, d in self.list_year.items()},
                **({} if self.nb1_kappa is None else {"nb1_kappa": self.nb1_kappa}),
                "seed": self.seed, "in_space": self.in_space}


@dataclass(frozen=True)
class Truth:
    """The expected cell counts of a scenario on the study table."""

    scenario: Scenario
    table: CaptureTable
    exposure: np.ndarray            # (S,) person-years
    expected_total: np.ndarray      # (S,) Lambda: expected people, recorded or not
    probs: np.ndarray               # (S, 8) history probabilities, hidden history first
    shift: float                    # common capture log-odds shift that sets the completeness
    log_rate: np.ndarray            # (S,) log Lambda - log PY

    @property
    def mu(self) -> np.ndarray:
        """Expected count of every cell, shape (S, 8), hidden cell first."""
        return self.expected_total[:, None] * self.probs

    @property
    def expected_completeness(self) -> float:
        return float(1.0 - self.mu[:, 0].sum() / self.expected_total.sum())

    @property
    def spec(self) -> ModelSpec:
        return self.scenario.spec

    def list_log_odds(self) -> np.ndarray:
        """Capture log-odds of each list per stratum, without dependence terms, shape (S, 3)."""
        return _list_log_odds(self.scenario, stratum_index(self.table), self.shift)

    @property
    def params(self) -> dict[str, np.ndarray]:
        """The truth in the PyMC model's parametrization (count target "total"); in-space scenarios only.

        theta_capture follows the columns of ``modelspace.design_matrix`` for ``self.spec``: list effects,
        each list x covariate block in the spec's order (effects coding: the first L-1 levels, list-major),
        then the pairs.
        """
        sc = self.scenario
        if not sc.in_space:
            raise ValueError(f"scenario {sc.name!r} is outside the model space: it has no parameters there")
        return {**decompose_count_part(self.log_rate.reshape(len(SEXES), len(AGE_BANDS), len(YEARS))),
                "theta_capture": capture_theta(sc, self.shift)}

    def params_under(self, amendment: str | None) -> dict[str, np.ndarray]:
        """The truth in the parametrization of the scenario's model with ``amendment`` applied (decision 122); only for
        a scenario inside that space (``Scenario.in_space_under``).

        None gives ``params``.  "AM1": theta_capture follows the columns of AM1(spec)'s design, the term's deviations
        last (``am1_capture_theta``), and reproduces every cell mean.  "AM2": ``params``' terms, plus the dispersion
        ``nb1_kappa`` of an NB1 scenario; a Poisson truth is AM2's limit kappa -> 0 and has none.
        """
        if amendment is None:
            return self.params
        sc = self.scenario
        if not sc.in_space_under(amendment):
            raise ValueError(f"scenario {sc.name!r} is outside the model space with {amendment}: it has no "
                             "parameters there")
        out = decompose_count_part(self.log_rate.reshape(len(SEXES), len(AGE_BANDS), len(YEARS)))
        if amendment == AM1.id:
            return {**out, "theta_capture": am1_capture_theta(sc, self.shift)}
        out["theta_capture"] = capture_theta(sc, self.shift)
        if sc.nb1_kappa is not None:
            out[AM2_KAPPA] = np.asarray(float(sc.nb1_kappa))
        return out


def _list_log_odds(sc: Scenario, ix: Mapping[str, np.ndarray], shift: float) -> np.ndarray:
    b = np.asarray(sc.list_offsets, float)[None, :] + shift
    b = b + np.asarray(sc.list_age, float).T[ix["age_band"]]
    b = b + np.asarray(sc.list_period, float).T[ix["period"]]
    b = b + np.asarray(sc.list_sex, float).T[ix["sex"]]
    for j, l in enumerate(LISTS):
        for y, v in sc.list_year.get(l, {}).items():
            b[ix["year"] == YEARS.index(y), j] += v
    return b


def _history_probs(sc: Scenario, b: np.ndarray) -> np.ndarray:
    """(S, 8) history probabilities from the list log-odds b (S, 3), the pairs and the misspecifications."""
    H = HISTORIES.astype(float)
    dep = np.zeros(len(H))
    for p, odds in sc.pairs.items():
        j, k = LISTS.index(p[0]), LISTS.index(p[1])
        dep += H[:, j] * H[:, k] * math.log(odds)
    dep += H.prod(axis=1) * math.log(sc.three_way)

    def softmax(cap):
        cap = cap - cap.max(axis=1, keepdims=True)
        e = np.exp(cap)
        return e / e.sum(axis=1, keepdims=True)

    probs = softmax(b @ H.T + dep[None, :])
    if sc.latent is not None:
        share, delta = sc.latent
        probs = (1.0 - share) * probs + share * softmax((b + delta) @ H.T + dep[None, :])
    return probs


def make_truth(sc: Scenario, table: CaptureTable | None = None, exposure: np.ndarray | None = None) -> Truth:
    """Expected people and history probabilities of ``sc`` on the study table (deterministic)."""
    from scipy.optimize import brentq

    table = table if table is not None else study_table()
    exposure = np.asarray(exposure if exposure is not None else synthetic_person_years(table), float)
    ix = stratum_index(table)
    rng = np.random.default_rng([sc.seed, 20261102])
    t = ix["year"] - (len(YEARS) - 1) / 2
    rel = (np.asarray(sc.rate_age)[ix["age_band"]] + np.asarray(sc.rate_sex)[ix["sex"]] + sc.trend * t
           + rng.normal(0.0, sc.noise_sd, size=table.S))
    scale = sc.N / float(np.sum(exposure * np.exp(rel)))
    log_rate = rel + math.log(scale)
    Lam = exposure * np.exp(log_rate)

    def completeness(shift: float) -> float:
        p = _history_probs(sc, _list_log_odds(sc, ix, shift))
        return 1.0 - float((Lam * p[:, 0]).sum() / Lam.sum())

    shift = brentq(lambda c: completeness(c) - sc.completeness, -20.0, 20.0, xtol=1e-12)
    probs = _history_probs(sc, _list_log_odds(sc, ix, shift))
    return Truth(sc, table, exposure, Lam, probs, float(shift), log_rate)


def decompose_count_part(c: np.ndarray) -> dict[str, np.ndarray]:
    """Write a (sex, age band, year) array as the model's count-part terms (zero-sum ANOVA decomposition).

    alpha + delta[sex] + eta[age] + gamma[year] + (delta eta) + (delta gamma) + (eta gamma) + (delta eta gamma)
    reproduces ``c`` exactly; gamma is centred (a centred random walk can take any centred values).
    """
    c = np.asarray(c, float)
    m = c.mean()
    s = c.mean(axis=(1, 2)) - m
    a = c.mean(axis=(0, 2)) - m
    y = c.mean(axis=(0, 1)) - m
    sa = c.mean(axis=2) - m - s[:, None] - a[None, :]
    sy = c.mean(axis=1) - m - s[:, None] - y[None, :]
    ay = c.mean(axis=0) - m - a[:, None] - y[None, :]
    say = (c - m - s[:, None, None] - a[None, :, None] - y[None, None, :] - sa[:, :, None] - sy[:, None, :]
           - ay[None, :, :])
    return {"alpha": np.asarray(m), "delta_sex": s, "eta_age": a, "gamma": y, "delta_eta": sa,
            "delta_gamma": sy, "eta_gamma": ay, THREE_WAY: say}


def capture_theta(sc: Scenario, shift: float) -> np.ndarray:
    """The truth's capture coefficients in the design-matrix column order of ``sc.spec``."""
    parts = [np.asarray(sc.list_offsets, float) + shift]
    rows = {"age_band": sc.list_age, "period": sc.list_period, "sex": sc.list_sex}
    for cov in sc.spec.list_covariates:
        a = np.asarray(rows[cov], float)
        parts.append(a[:, :-1].ravel())               # effects coding: the last level is minus the sum
    order = sorted(sc.spec.pairs, key=lambda p: (LISTS.index(p[0]), LISTS.index(p[1])))
    if order:
        parts.append(np.array([math.log(sc.pairs[a + b]) for a, b in order]))
    return np.concatenate(parts)


def am1_capture_theta(sc: Scenario, shift: float) -> np.ndarray:
    """The truth's capture coefficients in the column order of AM1(``sc.spec``)'s design (decision 122): the blocks of
    ``capture_theta``, then the list x year deviations u of the first nine years, list-major (effects coding).

    AM1's deviations sum to zero over each period's years when the model has list x period, and over all the years
    otherwise.  So each list's year effects are split into those deviations and their means, the period means with
    list x period and the overall mean without it; the means move into the list x period effects and the list effects,
    and every cell keeps its log-odds.  A scenario without year effects gets u = 0, the frozen model.
    """
    spec = sc.spec
    v = np.zeros((len(LISTS), len(YEARS)))
    for j, l in enumerate(LISTS):
        for y, e in sc.list_year.get(l, {}).items():
            v[j, YEARS.index(y)] += e
    offsets = np.asarray(sc.list_offsets, float) + shift
    rows = {"age_band": np.asarray(sc.list_age, float), "period": np.asarray(sc.list_period, float),
            "sex": np.asarray(sc.list_sex, float)}
    if "period" in spec.list_covariates:
        period = np.array([next(i for i, (lo, hi) in enumerate(PERIODS.values()) if lo <= y <= hi) for y in YEARS])
        means = np.column_stack([v[:, period == p].mean(axis=1) for p in range(len(PERIODS))])    # lists x periods
        overall = means.mean(axis=1)
        rows["period"] = rows["period"] + (means - overall[:, None])
        u = v - means[:, period]
    else:
        overall = v.mean(axis=1)
        u = v - overall[:, None]
    parts = [offsets + overall] + [rows[c][:, :-1].ravel() for c in spec.list_covariates]
    order = sorted(spec.pairs, key=lambda p: (LISTS.index(p[0]), LISTS.index(p[1])))
    if order:
        parts.append(np.array([math.log(sc.pairs[a + b]) for a, b in order]))
    parts.append(u[:, :-1].ravel())
    return np.concatenate(parts)


@dataclass(frozen=True)
class SimData:
    """One simulated dataset."""

    counts: np.ndarray       # (S, 7) observed histories, the engine's order
    hidden: np.ndarray       # (S,) people no list recorded

    @property
    def n(self) -> int:
        return int(self.counts.sum())

    @property
    def N(self) -> int:
        return int(self.counts.sum() + self.hidden.sum())


def simulate(truth: Truth, rng: np.random.Generator) -> SimData:
    """Draw every cell as an independent Poisson count (the hidden cell included).

    A scenario with ``nb1_kappa`` (AM2's, decision 122) draws every cell, the hidden one included, from NB1(mu, kappa)
    instead, with the engine's ``ppc.nb1_draws``: the observed cells, then the hidden ones, as the Poisson draw does.
    """
    mu = truth.mu
    kappa = truth.scenario.nb1_kappa
    if kappa is None:
        return SimData(rng.poisson(mu[:, 1:]).astype(np.int64), rng.poisson(mu[:, 0]).astype(np.int64))
    counts = nb1_draws(mu[:, 1:].reshape(-1), kappa, rng).reshape(mu.shape[0], -1)
    return SimData(counts.astype(np.int64), nb1_draws(mu[:, 0], kappa, rng).astype(np.int64))


def _odds(*pairs: tuple[str, float]) -> dict[str, float]:
    return dict(pairs)


#: The recovery scenarios.  In-space ones span N 300-3 000, completeness 40-95% and odds ratios 0.3-5,
#: all with list x age band and list x period heterogeneity; the misspecified ones are reported as found.
SCENARIOS: dict[str, Scenario] = {s.name: s for s in (
    Scenario("cohort-like", "N 1 200, completeness 70%, AB odds ratio 3 and BC 0.5, list x age band and period",
             N=1200, completeness=0.70, pairs=_odds(("AB", 3.0), ("BC", 0.5)), seed=1),
    Scenario("sparse-low", "N 300, completeness 45%, AC odds ratio 0.3: about 2 recorded people per stratum-year",
             N=300, completeness=0.45, pairs=_odds(("AC", 0.3)), seed=2),
    Scenario("large-complete", "N 3 000, completeness 95%, all three pairs (odds ratios 5, 0.3, 1.5)",
             N=3000, completeness=0.95, pairs=_odds(("AB", 5.0), ("AC", 0.3), ("BC", 1.5)), seed=3),
    Scenario("independent-mid", "N 800, completeness 60%, independent lists", N=800, completeness=0.60, seed=4),
    Scenario("latent-hard-to-reach", "misspecified: 30% of people have capture odds e^-1.5 times lower on every "
             "list (latent class); otherwise independent; N 1 200, completeness 70%",
             N=1200, completeness=0.70, latent=(0.30, -1.5), seed=5),
    Scenario("list-by-year", "misspecified: list A's capture odds x e^0.8 in 2018 and x e^-0.6 in 2022-2024 beyond "
             "its period effect; otherwise cohort-like", N=1200, completeness=0.70,
             pairs=_odds(("AB", 3.0), ("BC", 0.5)), list_year={"A": {2018: 0.8, 2022: -0.6, 2023: -0.6, 2024: -0.6}},
             seed=6),
    Scenario("three-way", "misspecified: an A:B:C odds factor of 2 on top of the cohort-like pairs",
             N=1200, completeness=0.70, pairs=_odds(("AB", 3.0), ("BC", 0.5)), three_way=2.0, seed=7),
)}

#: The scenarios added for the amendments' check 1 (decision 122, step 3; decision 123), kept apart from ``SCENARIOS``:
#: decision 91's dense variant of sparse-low (its name, summary and seed, so the results compare), and AM2's new
#: scenario, cohort-like with every cell NB1 at kappa = 1.  AM1's new scenario is ``list-by-year``, already above.
AMENDMENT_SCENARIOS: dict[str, Scenario] = {s.name: s for s in (
    replace(SCENARIOS["sparse-low"], name="sparse-low-at-study-density", N=1350,
            description="sparse-low's completeness 45% and AC odds ratio 0.3 at N 1 350: about 10 recorded people per "
                        "stratum-year, the density of the study's E1 table"),
    replace(SCENARIOS["cohort-like"], name="cohort-like-nb1", nb1_kappa=1.0,
            description="cohort-like with every cell, the hidden one included, NB1(mu, kappa = 1): variance twice the "
                        "mean (AM2's new scenario, decision 122)"),
)}


def find_scenario(name: str) -> Scenario:
    """A scenario by name, from ``SCENARIOS`` or ``AMENDMENT_SCENARIOS``."""
    if name in SCENARIOS:
        return SCENARIOS[name]
    if name in AMENDMENT_SCENARIOS:
        return AMENDMENT_SCENARIOS[name]
    raise KeyError(f"unknown scenario {name!r}; the scenarios are {sorted(SCENARIOS) + sorted(AMENDMENT_SCENARIOS)}")
