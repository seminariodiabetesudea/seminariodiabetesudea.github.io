"""Phase 4 validation: the six checks the build plan requires before any refit number is trusted.

Each check lives in its own module and has a pytest test marked ``validation`` that reruns it with fewer
replicates.  Everything here runs on simulated or published data only; nothing reads the study's export,
cohort or review files.
"""
