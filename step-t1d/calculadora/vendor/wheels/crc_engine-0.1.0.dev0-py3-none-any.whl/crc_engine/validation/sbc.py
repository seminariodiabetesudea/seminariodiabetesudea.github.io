"""Phase 4, check 2: simulation-based calibration (Talts, Betancourt, Simpson, Vehtari & Gelman 2018).

For three models of the space:

* ``independence``: independent lists, no list x covariate term;
* ``all-pairs``: all three pairwise dependence terms, no list x covariate term;
* ``richest``: all three pairs with list x age band, list x period and list x sex (the richest
  heterogeneity model, which is also the richest model of the space);

the check draws datasets from the model's own prior predictive distribution (``pymc.draw`` on the very PyMC
model the refit builds, ``models.build_structured_model``, on the E1 strata with synthetic person-years),
refits each dataset with the same model and short NUTS chains (``_core_fit``), and ranks each true value
among L posterior draws thinned evenly from the chains.  If prior, likelihood and sampler agree, every rank is
uniform on {0, ..., L}; a chi-square test on B equal bins checks it, and the pass rule is p > 0.01 for N and
for every key parameter.  N = n + hidden is discrete, so its ties are broken at random.  Every fit counts,
whatever its diagnostics: dropping failed fits would bias the ranks.

The prior set is a parameter (``--prior recalibrated`` or ``proposed``); the pilot uses the recalibrated set
because checkpoint C3 has not chosen yet.

**The amendments** (decision 122, ``docs/amendments/decision-122/``).  ``--amendment AM1`` or ``AM2`` applies
the amendment to each of the three models (``sbc_models``), with the same pass rule.  The ranked parameters
gain the new scales sigma_A, sigma_B and sigma_C (AM1) or the dispersion kappa (AM2).  Each dataset is the
amended model's own prior predictive draw: its counts come from the amended model's ``pymc.draw``, and its
hidden counts are Poisson with the hidden means, which carry AM1's term, or NB1 with the dataset's own kappa
(AM2, ``ppc.nb1_draws``).  The summary, the configuration and the checkpoints' identity record the amendment.

Run: ``python -m crc_engine.validation.sbc --out <folder> [--datasets 20] [--models ...] [--amendment AM1]``.
"""

from __future__ import annotations

import argparse
import itertools
import math
import time
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Mapping, Sequence

import numpy as np

from ..amendments import AM1, AM1_SIGMA, AM2, AM2_KAPPA, AMENDMENTS
from ..modelspace import ModelSpec
from ._core_fit import SHORT_SAMPLER, fit_many, resolve_priors
from ._core_sim import (AGE_BANDS, COVARIATES, LISTS, PERIODS, SEXES, YEARS, study_table,
                        synthetic_person_years)
from .recovery import environment, run_pool, seed_for, write_json

ALL_PAIRS = frozenset(itertools.combinations(LISTS, 2))
SBC_MODELS: dict[str, ModelSpec] = {
    "independence": ModelSpec(LISTS),
    "all-pairs": ModelSpec(LISTS, ALL_PAIRS),
    "richest": ModelSpec(LISTS, ALL_PAIRS, COVARIATES),
}
#: Thinned posterior draws per fit: ranks take L + 1 = 100 values.
THIN_TO = 99
P_MIN = 0.01
FULL_DATASETS = 200
MAX_BINS = 20


def sbc_models(amendment: str | None = None) -> dict[str, ModelSpec]:
    """The three models, each with ``amendment`` (decision 122) when one is given."""
    if amendment is None:
        return dict(SBC_MODELS)
    if amendment not in AMENDMENTS:
        raise ValueError(f"unknown amendment {amendment!r}; the amendments are {sorted(AMENDMENTS)}")
    return {name: replace(spec, amendment=amendment) for name, spec in SBC_MODELS.items()}


def key_parameters(spec: ModelSpec) -> list[tuple[str, str, tuple[int, ...]]]:
    """(label, PyMC variable, index) of the parameters ranked besides N; an amended model's new parameters last."""
    out = [("alpha", "alpha", ())]
    out += [(f"beta[{l}]", "beta", (j,)) for j, l in enumerate(spec.lists)]
    pairs = sorted(spec.pairs, key=lambda p: (spec.lists.index(p[0]), spec.lists.index(p[1])))
    out += [(f"lambda[{a}{b}]", "lambda", (i,)) for i, (a, b) in enumerate(pairs)]
    first = {"age_band": AGE_BANDS[0], "period": next(iter(PERIODS)), "sex": SEXES[0]}
    out += [(f"list_x_{c}[{spec.lists[0]},{first[c]}]", f"list_x_{c}", (0, 0)) for c in spec.list_covariates]
    out += [(v, v, ()) for v in ("gamma_sigma", "tau", "tau3")]
    if spec.amendment == AM1.id:              # decision 122: AM1's scale sigma_l of each list
        out += [(f"{AM1_SIGMA}[{l}]", AM1_SIGMA, (j,)) for j, l in enumerate(spec.lists)]
    elif spec.amendment == AM2.id:            # AM2's dispersion kappa
        out += [(AM2_KAPPA, AM2_KAPPA, ())]
    return out


def prior_datasets(spec: ModelSpec, prior_name: str, n: int, seed: int, *, table=None,
                   exposure: np.ndarray | None = None) -> dict:
    """``n`` draws of (parameters, observed counts, hidden means and counts, N) from the model's prior predictive.

    The counts and the hidden means are one ``pymc.draw`` of the model, an amended one included.  The hidden counts
    are Poisson with the hidden means (an AM1 model's carry its term), or for an AM2 model NB1 with each dataset's
    own kappa (decision 122).
    """
    import warnings

    import pymc as pm

    from ..models import build_structured_model
    from ..ppc import nb1_draws

    table = table if table is not None else study_table()
    exposure = exposure if exposure is not None else synthetic_person_years(table)
    pri = resolve_priors(prior_name)
    sm = build_structured_model(table, spec, pri, periods=PERIODS,
                                exposure=exposure if pri.count_target == "total" else None, noncentred=True)
    names = list(dict.fromkeys(v for _, v, _ in key_parameters(spec)))
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        vals = pm.draw([sm.model[v] for v in names] + [sm.model["y"], sm.model["hidden_mu"]], draws=n,
                       random_seed=seed)
    params = {k: np.asarray(v) for k, v in zip(names, vals[:-2])}
    counts = np.asarray(vals[-2], np.int64).reshape(n, table.S, -1)
    hidden_mu = np.asarray(vals[-1], float)
    rng = np.random.default_rng(seed_for(seed, "hidden"))
    hidden = nb1_draws(hidden_mu, params[AM2_KAPPA], rng) if spec.amendment == AM2.id else rng.poisson(hidden_mu)
    return {"params": params, "counts": counts, "hidden": hidden.astype(np.int64), "hidden_mu": hidden_mu,
            "N": counts.sum(axis=(1, 2)) + hidden.sum(axis=1), "n": counts.sum(axis=(1, 2))}


def thin(draws: np.ndarray, L: int = THIN_TO) -> np.ndarray:
    """L draws evenly spaced over the (chain-concatenated) draws."""
    d = np.asarray(draws)
    idx = np.round(np.linspace(0, len(d) - 1, L)).astype(int)
    return d[idx]


def rank_of(true: float, draws: np.ndarray, rng: np.random.Generator) -> int:
    """Number of draws below the true value, ties broken uniformly at random."""
    d = np.asarray(draws, float)
    below = int(np.sum(d < true))
    ties = int(np.sum(d == true))
    return below + (int(rng.integers(0, ties + 1)) if ties else 0)


def choose_bins(n: int, L: int = THIN_TO, max_bins: int = MAX_BINS, min_expected: float = 5.0) -> int:
    """The largest number of equal bins (a divisor of L + 1, at most ``max_bins``) with at least
    ``min_expected`` ranks expected per bin."""
    divs = [b for b in range(2, max_bins + 1) if (L + 1) % b == 0 and n / b >= min_expected]
    return max(divs) if divs else 2


def uniformity(ranks: Sequence[int], L: int = THIN_TO, bins: int | None = None, *, mc: int = 20_000,
               rng: np.random.Generator | None = None) -> dict:
    """Chi-square test of uniform ranks on {0..L} over equal bins; also a Monte Carlo p-value of the statistic."""
    from scipy.stats import chi2

    r = np.asarray(ranks, int)
    n = len(r)
    B = bins or choose_bins(n, L)
    counts = np.bincount(r * B // (L + 1), minlength=B)
    E = n / B
    stat = float(((counts - E) ** 2 / E).sum())
    rng = rng or np.random.default_rng(0)
    sim = rng.integers(0, L + 1, size=(mc, n)) * B // (L + 1)
    sc = np.stack([np.bincount(row, minlength=B) for row in sim])
    sim_stat = ((sc - E) ** 2 / E).sum(axis=1)
    return {"n": n, "bins": B, "counts": counts.tolist(), "chi2": stat, "df": B - 1,
            "p": float(chi2.sf(stat, B - 1)), "p_mc": float((np.sum(sim_stat >= stat - 1e-12) + 1) / (mc + 1))}


def run_sbc(out_dir: str | Path, *, models: Sequence[str] = tuple(SBC_MODELS), datasets: int = 20,
            prior_name: str = "recalibrated", root_seed: int = 20261102, workers: int = 4,
            sampler: Mapping | None = None, chunk: int | None = None, noncentred: bool = True,
            amendment: str | None = None, log: Callable = print) -> dict:
    """Run check 2 and write its machine-readable results to ``out_dir``; returns the summary.

    ``amendment`` (decision 122) applies that amendment to every model; the summary, the configuration and the
    checkpoints' identity record it.  Without one, all three are as before."""
    t_start = time.perf_counter()
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    sampler = dict(SHORT_SAMPLER, **(sampler or {}))
    specs = sbc_models(amendment)
    table = study_table()
    exposure = synthetic_person_years(table)
    sims, jobs = {}, []
    step = chunk or max(1, math.ceil(datasets / 2))
    for name in models:
        spec = specs[name]
        sims[name] = prior_datasets(spec, prior_name, datasets, seed_for(root_seed, "sbc-prior", name),
                                    table=table, exposure=exposure)
        ds = [{"key": [name, i], "counts": sims[name]["counts"][i], "seed": seed_for(root_seed, "sbc-fit", name, i)}
              for i in range(datasets)]
        keep = list(dict.fromkeys(v for _, v, _ in key_parameters(spec)))
        for i in range(0, datasets, step):
            jobs.append({"lists": LISTS, "table_levels": {"sex": SEXES, "age_band": AGE_BANDS, "year": YEARS},
                         "exposure": exposure, "periods": PERIODS, "prior_name": prior_name, "noncentred": noncentred,
                         "sampler": sampler, "spec": spec, "evidence": False, "keep": keep,
                         "datasets": ds[i:i + step], "model_name": name})
    log(f"sbc: {len(models)} models x {datasets} datasets = {len(models) * datasets} fits in {len(jobs)} jobs "
        f"on {workers} workers ({prior_name} priors{'' if amendment is None else ', amendment ' + amendment})")
    identity = {"models": list(models), "datasets": datasets, "prior": prior_name, "seed": root_seed,
                "sampler": sampler, "chunk": chunk, "noncentred": noncentred}
    if chunk is None:
        identity["workers"] = workers
    if amendment is not None:       # so an amended run never resumes a base run's checkpoints, nor the reverse
        identity["amendment"] = amendment
    results = run_pool(jobs, fit_many, workers, log, checkpoint=out / "checkpoints", identity=identity)  # decision 87

    rank_rows, fit_rows, compile_by_model = [], [], {}
    for job, res in zip(jobs, results):
        name = job["model_name"]
        spec = specs[name]
        compile_by_model.setdefault(name, []).append(res["compile_seconds"])
        for rec in res["results"]:
            i = int(rec["key"][1])
            rng = np.random.default_rng(seed_for(root_seed, "sbc-ties", name, i))
            truth = sims[name]
            rank_rows.append({"model": name, "dataset": i, "parameter": "N", "true": float(truth["N"][i]),
                              "rank": rank_of(truth["N"][i], thin(rec["N"]), rng),
                              "posterior_median": float(np.median(rec["N"]))})
            for label, var, idx in key_parameters(spec):
                tv = float(np.asarray(truth["params"][var][i])[idx])
                dr = rec["params"][var][(slice(None),) + idx]
                rank_rows.append({"model": name, "dataset": i, "parameter": label, "true": tv,
                                  "rank": rank_of(tv, thin(dr), rng), "posterior_median": float(np.median(dr))})
            g = rec["gates"]
            fit_rows.append({"model": name, "dataset": i, "seed": rec["seed"], "n": int(truth["n"][i]),
                             "N_true": int(truth["N"][i]), "N_median": float(np.median(rec["N"])),
                             **{k: g.get(k) for k in ("rhat_max", "ess_bulk_min", "ess_tail_min", "rhat_N",
                                                      "ess_bulk_N", "ess_tail_N", "divergences", "ebfmi_min",
                                                      "treedepth_frac", "rhat_unconstrained_max",
                                                      "ess_bulk_unconstrained_min", "gates_passed")},
                             "seconds_sample": rec["seconds_sample"], "seconds_gates": rec["seconds_gates"],
                             "seconds_total": rec["seconds_total"], "compile_seconds": res["compile_seconds"]})

    import pandas as pd

    ranks = pd.DataFrame(rank_rows).sort_values(["model", "parameter", "dataset"])
    ranks.to_csv(out / "ranks.csv", index=False)
    fits = pd.DataFrame(fit_rows).sort_values(["model", "dataset"])
    fits.to_csv(out / "fits.csv", index=False)

    tests = {}
    for name in models:
        tests[name] = {}
        for param, grp in ranks[ranks.model == name].groupby("parameter", sort=False):
            u = uniformity(grp["rank"].to_numpy(), rng=np.random.default_rng(seed_for(root_seed, "mc", name, param)))
            u["passed"] = bool(u["p"] > P_MIN)
            tests[name][param] = u
    n_tests = sum(len(v) for v in tests.values())
    per_fit = fits.groupby("model")["seconds_total"].mean().to_dict()
    comp = {k: float(np.mean(v)) for k, v in compile_by_model.items()}
    est_core_h = sum(FULL_DATASETS * per_fit[m] for m in models) / 3600.0
    summary = {
        "check": "Phase 4 check 2: simulation-based calibration (Talts et al. 2018)",
        "started": started, "finished": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "prior_set": prior_name, "priors": resolve_priors(prior_name).name,
        **({} if amendment is None else {"amendment": amendment}), "root_seed": root_seed,
        "datasets_per_model": datasets, "thinned_draws": THIN_TO, "pass_rule": f"chi-square p > {P_MIN} for every "
        "parameter", "models": {m: specs[m].name for m in models},
        "tests": tests,
        "passed": {m: all(t["passed"] for t in tests[m].values()) for m in models},
        "failures": [f"{m}: {p} (p = {t['p']:.4g})" for m in models for p, t in tests[m].items() if not t["passed"]],
        "tests_run": n_tests,
        "expected_false_failures_at_p_min": n_tests * P_MIN,
        "diagnostics": {m: {"divergent_fits": int((fits[fits.model == m]["divergences"] > 0).sum()),
                            "fits": int((fits.model == m).sum()),
                            "rhat_max_over_fits": float(fits[fits.model == m]["rhat_max"].max()),
                            "ess_bulk_min_over_fits": float(fits[fits.model == m]["ess_bulk_min"].min()),
                            "ebfmi_min_over_fits": float(fits[fits.model == m]["ebfmi_min"].min())}
                        for m in models},
        "timing": {"seconds_per_fit_mean": per_fit, "compile_seconds_mean": comp,
                   "wall_seconds": time.perf_counter() - t_start, "workers": workers,
                   "full_run_estimate": {"datasets_per_model": FULL_DATASETS, "core_hours": est_core_h,
                                         **{f"wall_hours_{w}_workers": (est_core_h * 3600.0 / w
                                                                        + max(comp.values())) / 3600.0
                                            for w in (4, 10)}}},
    }
    config = {"models": {m: specs[m].name for m in models}, "datasets": datasets, "prior_set": prior_name,
              **({} if amendment is None else {"amendment": amendment,
                                               "amendment_prior": AMENDMENTS[amendment].prior_dict()}),
              "sampler": sampler, "noncentred": noncentred, "thin_to": THIN_TO, "root_seed": root_seed, "workers": workers,
              "chunk": step, "person_years": "synthetic (_core_sim.synthetic_person_years)",
              "prior_draws": {m: {"N_median": float(np.median(sims[m]["N"])),
                                  "N_range": [int(sims[m]["N"].min()), int(sims[m]["N"].max())],
                                  "n_median": float(np.median(sims[m]["n"]))} for m in models},
              "environment": environment()}
    write_json(out / "config.json", config)
    write_json(out / "summary.json", summary)
    log(f"sbc: wrote {out}")
    return summary


def main(argv: Sequence[str] | None = None) -> None:
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("--out", required=True)
    p.add_argument("--models", nargs="+", default=list(SBC_MODELS), choices=list(SBC_MODELS))
    p.add_argument("--datasets", type=int, default=20)
    p.add_argument("--prior", default="recalibrated", choices=["recalibrated", "proposed"])
    p.add_argument("--seed", type=int, default=20261102)
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--chunk", type=int, default=None)
    p.add_argument("--centred", action="store_true", help="the plan's first attempt (centred pooled terms)")
    p.add_argument("--chains", type=int, default=SHORT_SAMPLER["chains"])
    p.add_argument("--tune", type=int, default=SHORT_SAMPLER["tune"])
    p.add_argument("--draws", type=int, default=SHORT_SAMPLER["draws"])
    p.add_argument("--amendment", choices=sorted(AMENDMENTS), default=None,
                   help="apply this amendment of decision 122 to every model (docs/amendments/decision-122/)")
    a = p.parse_args(argv)
    run_sbc(a.out, models=a.models, datasets=a.datasets, prior_name=a.prior, root_seed=a.seed, workers=a.workers,
            chunk=a.chunk, noncentred=not a.centred, sampler={"chains": a.chains, "tune": a.tune, "draws": a.draws},
            amendment=a.amendment, log=lambda m: print(m, flush=True))


if __name__ == "__main__":
    main()
