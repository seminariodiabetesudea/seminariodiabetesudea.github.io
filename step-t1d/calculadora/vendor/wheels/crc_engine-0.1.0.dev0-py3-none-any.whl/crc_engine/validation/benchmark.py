"""Phase 4, check 5: reproduce a published Bayesian model-averaging capture-recapture analysis.

The benchmark
-------------
Spina bifida in upstate New York, births 1969-1974 (Hook et al. 1980): 626 people found on three lists, birth
certificates (B), death certificates (D) and records of a medical rehabilitation program (R), analysed by
Madigan & York (Biometrika 84:19-31, 1997) with Bayesian model averaging over decomposable graphical models.
The article is paywalled.  The figures come from the authors' technical report of July 1992 (UW Statistics
TR 234), the version Biometrika received on 1 July 1992; its covariate analysis gives the same N (731, 689 to
794) that Overstall & King (2014) quote from the article.  ``data/madigan_york_spina_bifida.json`` holds the data,
the priors and every published figure used here, each with its table and page.

How it is reproduced
--------------------
* **The published analysis** (TR 234, Table 4, and Table 5's bold row): the 8 decomposable models for three lists;
  a hyper-Dirichlet prior with delta = 1 per cell of the full table; the "historical" prior on N,
  lambda ~ Gamma(a = 13.14, scale b = 55.17) and N ~ Poisson(lambda); a uniform model prior.
* **In PyMC, with the published priors exactly** (``_bm_hyperdirichlet.build_pymc_model``).  Multinomial cells
  with a Poisson N are independent Poisson cells, so each model is a Gamma prior on lambda, Dirichlet priors on the
  clique tables and Poisson likelihoods for the 7 observed cells.  Its marginal likelihood is Madigan & York's
  P(D | M = m), constants included.
* **The analysis plan's machinery, run five times** (``BMA_SETTINGS.repeats``, independent seeds).  Each run
  fits every model by NUTS with the plan's sampler settings, retries on divergences and convergence gates
  (``crc_engine.diagnostics``), then estimates its marginal likelihood by bridge sampling from the NUTS draws
  and, as the plan's second opinion, by importance sampling from the same draws (``crc_engine.marginal``;
  decision 78).  The posterior of N in each model is the Poisson mixture over the NUTS draws of the hidden
  cell's mean (Rao-Blackwellised), and the averaged posterior is the mixture weighted by the bridge-sampling
  weights (uniform model prior, ``crc_engine.bma``), pooled over the runs: the plan's route.  The runs give the
  Monte Carlo error.  SMC, the first draft's method, also runs on every model as a diagnostic, in two routes:
  SMC weights with the NUTS posteriors ("smc_weights"), and SMC's own particles ("smc_particles"), which with
  4 x 2 000 particles miss the heavy upper tail of the saturated model.
* **A reference without Monte Carlo error** (``_bm_hyperdirichlet.exact_posterior``): the prior is conjugate, so
  summing the closed form over N gives every published figure exactly.  ``confirm_published`` checks Tables 4,
  5, 7 and 8 against it, which confirms the data and the priors before any sampler runs; the comparison then
  separates misprints in the report (published vs exact) from sampler error (exact vs PyMC).
* **The study's own models on the same table** (context, outside the pass rule): crc_engine's 8 dependence
  structures with the proposed Normal priors (``PHASE3_PROPOSED``), built by ``models.build_model`` from
  ``modelspace.design_matrix`` and run through the same machinery.  The no-three-way all-pairs model replaces the
  saturated one, and the priors sit on log-linear coefficients, so this run shows how far the study's choices move
  N on a published table.

Pass rule (build plan, Phase 4): the published N and model probabilities are reproduced within Monte Carlo
error, or each difference is explained.  A figure is reproduced when PyMC's value lies within t * MCSE of the
values that print as the published one (half a rounding unit either side; (k - 1, k] for a percentile k, through
the continuous percentile of ``n_summary``), with MCSE the standard error of the pooled estimate over the
independent runs and t the 97.5% Student quantile with runs - 1 degrees of freedom.  A miss counts as explained
only when it is a listed misprint (``KNOWN_DISCREPANCIES``) and PyMC agrees with the exact value within the same
Monte Carlo error.

Run the pilot with ``python -m crc_engine.validation.benchmark --out DIR``.
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import platform
import time
import warnings
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Callable, Mapping, Sequence

import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import logsumexp

from .. import bma
from ..bma import BMA_SETTINGS
from ..marginal import SMC_CHAINS, SMC_DRAWS
from ..tables import CaptureTable, histories
from . import _bm_hyperdirichlet as hd

DATA_DIR = Path(__file__).with_name("data")
BENCHMARK = "madigan_york_spina_bifida"
#: Madigan & York's a priori choice (TR 234, Table 5, bold row): historical prior on N, delta = 1.
PUBLISHED_PRIOR, PUBLISHED_DELTA = "historical", 1.0
#: Phase 4, check 4: a marginal likelihood is accurate when within this many log units of the reference.
LOG_ML_ACCURACY = 0.2
#: The analysis plan's route (bridge-sampling weights, NUTS posteriors of N; decision 78) and two diagnostic
#: ones: the first draft's SMC weights with the NUTS posteriors, and SMC's own particles.
PLAN_ROUTE, SMC_WEIGHTS_ROUTE, SMC_ROUTE = "plan", "smc_weights", "smc_particles"

#: Published figures that the exact computation does not reproduce, and why.  ``confirm_published`` must find
#: exactly these; any other miss means the data, the priors or the code are wrong.
_LAST_DIGIT = ("one unit off in the last printed digit; the printed value is the exact value truncated rather than "
               "rounded, while the report rounds everywhere else.")
KNOWN_DISCREPANCIES: dict[str, str] = {
    "table4|[BD][DR]|prob": (
        "Table 4 prints 0.301; the exact value is 0.3095 (0.30947).  Table 5's bold row, the same analysis, prints "
        "0.31, and with 0.301 Table 4's four probabilities sum to 0.991 although the other four models hold about "
        "1e-9 together: a misprint."),
    "table5|lower_historical,delta=0.5|[BD][DR]": "printed 0.26, exact 0.2654: " + _LAST_DIGIT,
    "table5|jeffreys,delta=2|[BDR]": "printed 0.06, exact 0.0662: " + _LAST_DIGIT,
    "table8|1969|[DR][B]": "printed 3.21, exact 3.2186: " + _LAST_DIGIT,
    "table5|negligible|max": (
        "the caption says the unlisted models have probabilities below 1e-10; the exact values are 3e-10 to 1.5e-9 "
        "(largest for [BD][BR]).  No figure in the report depends on it."),
    "table8|1969|All Models": (
        "Table 8's last row is called the Bayes factor of the average over models (p. 22), but it equals the sum of "
        "the eight Bayes factors: the exact average (uniform model prior) is log 8 = 2.08 lower."),
    "table8|1969-1973|All Models": (
        "as for the 1969 column: the printed value is the sum of the Bayes factors, log 8 above their average."),
}


# =============================================================================== data
def load_benchmark(name: str = BENCHMARK) -> dict:
    """The benchmark's data, priors and published figures (see the JSON's citation block)."""
    with open(DATA_DIR / f"{name}.json", encoding="utf-8") as f:
        return json.load(f)


def history_keys(K: int) -> list[str]:
    """Observed histories as bit strings, in crc_engine's order (first list most significant)."""
    return ["".join(str(int(b)) for b in h) for h in histories(K)]


def cells_vector(cells: Mapping[str, int], K: int) -> np.ndarray:
    keys = history_keys(K)
    if set(cells) != set(keys):
        raise ValueError(f"the cells must be exactly {keys}")
    return np.array([int(cells[k]) for k in keys], dtype=np.int64)


def benchmark_table(data: Mapping, cells_key: str = "cells") -> CaptureTable:
    """A one-stratum CaptureTable of the benchmark's lists and cells."""
    lists = tuple(data["list_order"])
    counts = cells_vector(data[cells_key], len(lists))[None, :]
    return CaptureTable(lists, pd.DataFrame(index=[0]), counts, {})


def n_prior(data: Mapping, name: str):
    """A prior on N from the benchmark's ``method.n_priors``."""
    spec = data["method"]["n_priors"][name]
    if name == "historical":
        return hd.NegativeBinomialPrior(float(spec["a"]), float(spec["b"]), name)
    if name in ("lower_historical", "upper_historical"):
        mean = spec["mean_rate_per_10000"] / 1e4 * data["live_births"]
        return hd.NegativeBinomialPrior.from_mean_sd(mean, float(spec["sd"]), name)
    if name == "jeffreys":
        return hd.JeffreysPrior()
    if name == "rissanen":
        return hd.RissanenPrior()
    raise KeyError(name)


# ===================================================== step 1: the published figures, exactly
def _row(table, row, quantity, published, exact, unit) -> dict:
    match = bool(abs(exact - published) <= unit / 2 + 1e-9)
    return {"key": f"{table}|{row}|{quantity}", "table": table, "row": row, "quantity": quantity,
            "published": published, "exact": exact, "unit": unit, "match": match}


def confirm_published(data: Mapping | None = None) -> list[dict]:
    """Every published figure in Tables 4, 5, 7 and 8 against the exact computation, one row each.

    Tables 4 and 5 use Madigan & York's consistent hyper-Dirichlet; Tables 7 and 8 use "Smith's priors", read
    as a uniform Dirichlet on every clique table with the Jeffreys prior on N.  ``match`` is True when the exact
    value rounds to the published one.
    """
    data = data or load_benchmark()
    lists = tuple(data["list_order"])
    models = hd.decomposable_models(lists)
    labels = [m.label for m in models]
    y = cells_vector(data["cells"], len(lists))
    pub = data["published"]
    rows: list[dict] = []
    cache: dict = {}

    def exact(prior_name, delta, cells=y, convention="consistent"):
        key = (prior_name, delta, tuple(cells), convention)
        if key not in cache:
            cache[key] = hd.exact_posterior(cells, models, delta, n_prior(data, prior_name), convention=convention)
        return cache[key]

    # Table 4: the published analysis, every model with probability above 0.01
    t4 = pub["table4"]
    ex = exact(t4["prior"], float(t4["delta"]))
    u = t4["rounding"]
    for lab, vals in t4["models"].items():
        i = labels.index(lab)
        s = hd.n_summary(ex.grid, ex.pmf[i])
        rows.append(_row("table4", lab, "prob", vals["prob"], float(ex.weights[i]), u["prob"]))
        rows += [_row("table4", lab, q, vals[q], s[q], u["N"]) for q in ("N_hat", "mode", "q025", "q975")]
    s = hd.n_summary(ex.grid, ex.bma_pmf)
    rows += [_row("table4", "model averaging", q, v, s[q], u["N"]) for q, v in t4["model_averaging"].items()]

    # Table 5: sensitivity to the prior on N and to delta
    t5 = pub["table5"]
    cols, u = t5["columns"], t5["rounding"]
    worst = 0.0
    for r in t5["rows"]:
        ex = exact(r["prior"], float(r["delta"]))
        s = hd.n_summary(ex.grid, ex.bma_pmf)
        name = f"{r['prior']},delta={r['delta']:g}"
        for c, v in zip(cols, r["values"]):
            if v is None:
                continue
            if c.startswith("["):
                rows.append(_row("table5", name, c, v, float(ex.weights[labels.index(c)]), u["prob"]))
            else:
                rows.append(_row("table5", name, c, v, s[c], u["N"]))
        listed = {labels.index(c) for c in cols if c.startswith("[")}
        worst = max(worst, max(float(w) for i, w in enumerate(ex.weights) if i not in listed))
    rows.append({"key": "table5|negligible|max", "table": "table5", "row": "negligible", "quantity": "max",
                 "published": t5["negligible_below"], "exact": worst, "unit": 0.0,
                 "match": bool(worst < t5["negligible_below"])})

    # Table 7: the 1969 data under Smith's priors (5th and 95th percentiles)
    t7 = pub["table7"]
    y69 = cells_vector(data["cells_1969"], len(lists))
    ex = exact("jeffreys", 1.0, y69, "per_clique")
    for row, pmf in (("independence", ex.pmf[labels.index("[B][D][R]")]), ("all_models", ex.bma_pmf)):
        s = hd.n_summary(ex.grid, pmf, probs=(0.05, 0.95))
        rows += [_row("table7", row, q, v, s[q], t7["rounding"]["N"]) for q, v in t7[row].items()]

    # Table 8: log Bayes factors against independence under Smith's priors
    t8 = pub["table8"]
    for col, cells in (("1969", y69), ("1969-1973", y)):
        ex = exact("jeffreys", 1.0, cells, "per_clique")
        base = ex.log_ml[labels.index("[B][D][R]")]
        vals = t8["data_1969" if col == "1969" else "data_1969_1973"]
        for lab, v in vals.items():
            e = (logsumexp(ex.log_ml) - math.log(len(models)) if lab == "All Models"
                 else ex.log_ml[labels.index(lab)]) - base
            rows.append(_row("table8", col, lab, v, float(e), t8["rounding"]))
    return rows


def published_mismatches(rows: Sequence[dict]) -> dict[str, dict]:
    return {r["key"]: r for r in rows if not r["match"]}


# ====================================================================== settings
@dataclass(frozen=True)
class RunSettings:
    """Sampler settings.  The defaults are the analysis plan's: 5 independent runs, NUTS as in
    ``diagnostics.DEFAULT_SAMPLER`` with its retries on divergences, bridge sampling and importance sampling from
    the NUTS draws; SMC (diagnostic) with the first draft's 4 chains of 2 000 draws; at most 3 cores."""

    draws: int = SMC_DRAWS            # SMC, diagnostic
    chains: int = SMC_CHAINS
    repeats: int = BMA_SETTINGS.repeats
    cores: int = 3
    seed: int = 20261102
    nuts: bool = True                 # the plan's posterior: NUTS on every model in every run
    nuts_chains: int = 4
    nuts_draws: int = 2000
    nuts_tune: int = 2000
    target_accept: float = 0.9
    bridge: bool = True               # the plan's marginal likelihoods (bridge and importance sampling), from NUTS
    study_models: bool = True         # also fit crc_engine's 8 structures with the proposed priors (context)
    study_repeats: int = BMA_SETTINGS.repeats


def _seed(ss: np.random.SeedSequence) -> int:
    return int(ss.generate_state(1)[0])


def _t975(R: int) -> float:
    return float(stats.t.ppf(0.975, R - 1)) if R > 1 else float("inf")


def _quiet():
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    for name in ("pymc", "pymc.sampling", "pytensor", "nutpie"):
        logging.getLogger(name).setLevel(logging.ERROR)


SUMMARY_KEYS = ("N_hat", "mode", "mode_c", "q025", "q025_c", "q975", "q975_c", "median", "mean")


# ============================================= shared: the plan's machinery over independent runs
@dataclass(frozen=True)
class Candidate:
    """A model to fit: a builder of its PyMC model and a reader of the hidden cell's mean from a fit."""

    label: str
    build: Callable[[], object]
    hidden: Callable[[object], np.ndarray]          # DataTree -> hidden-cell means, shape (chains, draws)


def _sample_nuts(model, settings: RunSettings, ss: np.random.SeedSequence):
    """NUTS with the plan's settings; on divergences, again at the next target_accept (diagnostics)."""
    import pymc as pm

    from ..diagnostics import RETRY_TARGET_ACCEPT

    targets = [settings.target_accept] + [t for t in RETRY_TARGET_ACCEPT if t > settings.target_accept]
    attempts = []
    for ta, s in zip(targets, ss.spawn(len(targets))):
        idata = pm.sample(model=model, chains=settings.nuts_chains, draws=settings.nuts_draws, tune=settings.nuts_tune,
                          target_accept=ta, cores=settings.cores, random_seed=_seed(s), progressbar=False,
                          compute_convergence_checks=False)
        div = int(np.asarray(idata["sample_stats"]["diverging"].values).sum())
        attempts.append({"target_accept": ta, "divergences": div})
        if div == 0:
            break
    return idata, attempts


def _pool(n: int, labels: Sequence[str], prior_w: np.ndarray, log_ml_runs: list, mu_runs: list) -> dict:
    """Pool independent runs: log ML by log-mean-exp over every chain, pmfs of N averaged; MC error from the runs.

    ``log_ml_runs[r][m]`` holds the per-chain SMC log ML of model m in run r; ``mu_runs[r][m]`` the posterior draws
    of its hidden cell's mean.
    """
    R, M = len(log_ml_runs), len(labels)
    x_max = max(int(stats.poisson.isf(1e-12, np.max(mu[m]))) + 1 for mu in mu_runs for m in range(M))
    pmfs = np.empty((R, M, x_max + 1))
    for r in range(R):
        for m in range(M):
            grid, pmfs[r, m] = hd.poisson_mixture_pmf(n, mu_runs[r][m], x_max)
    per_run = []
    for r in range(R):
        lml = np.array([float(logsumexp(c) - np.log(len(c))) for c in log_ml_runs[r]])
        lw = lml + np.log(prior_w)
        w = np.exp(lw - logsumexp(lw))
        per_run.append({"log_ml": lml, "weights": w, "models": [hd.n_summary(grid, pmfs[r, m]) for m in range(M)],
                        "bma": hd.n_summary(grid, w @ pmfs[r])})
    pooled_lml = np.array([float(logsumexp(np.concatenate([run[m] for run in log_ml_runs]))
                                 - np.log(sum(len(run[m]) for run in log_ml_runs))) for m in range(M)])
    lw = pooled_lml + np.log(prior_w)
    w = np.exp(lw - logsumexp(lw))
    pmf = pmfs.mean(axis=0)
    pooled = {"log_ml": pooled_lml, "weights": w, "models": [hd.n_summary(grid, pmf[m]) for m in range(M)],
              "bma": hd.n_summary(grid, w @ pmf)}

    def sd(get):
        v = np.array([get(p) for p in per_run], float)
        return float(v.std(ddof=1)) if R > 1 else float("nan")

    mc = {"log_ml": [sd(lambda p, m=m: p["log_ml"][m]) for m in range(M)],
          "weights": [sd(lambda p, m=m: p["weights"][m]) for m in range(M)],
          "models": [{k: sd(lambda p, m=m, k=k: p["models"][m][k]) for k in SUMMARY_KEYS} for m in range(M)],
          "bma": {k: sd(lambda p, k=k: p["bma"][k]) for k in SUMMARY_KEYS}}
    return {"grid": grid, "pmf": pmf, "pooled": pooled, "per_run": per_run, "mc_sd_between_runs": mc, "runs": R}


def run_candidates(cands: Sequence[Candidate], n: int, prior_w: np.ndarray, settings: RunSettings,
                   ss: np.random.SeedSequence, repeats: int) -> dict:
    """``repeats`` independent runs of the plan's machinery on every candidate: NUTS, bridge sampling and
    importance sampling; SMC beside them as a diagnostic."""
    from ..diagnostics import check_gates
    from ..marginal import (bridge_log_marginal_likelihood, importance_log_marginal_likelihood,
                            smc_log_marginal_likelihood)

    smc_ss, nuts_ss = ss.spawn(2)
    runs = []
    timing = {"smc_seconds": [], "nuts_seconds": [], "bridge_seconds": [], "importance_seconds": []}
    for rs, rn in zip(smc_ss.spawn(repeats), nuts_ss.spawn(repeats)):
        run = {"per_chain": [], "stages": [], "smc_mu": [], "nuts_mu": [], "fits": []}
        t_smc, t_nuts, t_br, t_imp = [], [], [], []
        for c, ms, mn in zip(cands, rs.spawn(len(cands)), rn.spawn(len(cands))):
            model = c.build()
            t0 = time.perf_counter()
            res = smc_log_marginal_likelihood(model, draws=settings.draws, chains=settings.chains,
                                              random_seed=_seed(ms), cores=settings.cores)
            t_smc.append(time.perf_counter() - t0)
            run["per_chain"].append(np.asarray(res.per_chain, float))
            run["stages"].append(np.asarray(res.stages).tolist())
            run["smc_mu"].append(np.asarray(c.hidden(res.idata), float).ravel())
            if not settings.nuts:
                continue
            s_fit, s_br, s_pois, s_imp = mn.spawn(4)        # spawn keys: the first three as before
            t0 = time.perf_counter()
            idata, attempts = _sample_nuts(model, settings, s_fit)
            t_nuts.append(time.perf_counter() - t0)
            mu = np.asarray(c.hidden(idata), float)
            N_draws = n + np.random.default_rng(_seed(s_pois)).poisson(mu)
            gates = check_gates(idata, N_draws=N_draws, var_names=[rv.name for rv in model.free_RVs])
            fit = {"label": c.label, "attempts": attempts, "gates_passed": gates.passed,
                   "gate_failures": gates.failures, "gate_metrics": gates.metrics}
            if settings.bridge:
                t0 = time.perf_counter()
                br = bridge_log_marginal_likelihood(model, idata, random_seed=_seed(s_br))
                t_br.append(time.perf_counter() - t0)
                fit.update({"bridge_log_ml": br.log_ml, "bridge_cv": br.cv, "bridge_converged": br.converged})
                t0 = time.perf_counter()
                imp = importance_log_marginal_likelihood(model, idata, random_seed=_seed(s_imp))
                t_imp.append(time.perf_counter() - t0)
                fit.update({"importance_log_ml": imp.log_ml, "importance_se": imp.se, "importance_khat": imp.khat,
                            "importance_reliable": imp.reliable})
            run["nuts_mu"].append(mu.ravel())
            run["fits"].append(fit)
        timing["smc_seconds"].append(t_smc)
        timing["nuts_seconds"].append(t_nuts)
        timing["bridge_seconds"].append(t_br)
        timing["importance_seconds"].append(t_imp)
        runs.append(run)
    log_ml_runs = [r["per_chain"] for r in runs]
    labels = [c.label for c in cands]
    routes = {SMC_ROUTE: _pool(n, labels, prior_w, log_ml_runs, [r["smc_mu"] for r in runs])}
    if settings.nuts:
        nuts_mu = [r["nuts_mu"] for r in runs]
        routes[SMC_WEIGHTS_ROUTE] = _pool(n, labels, prior_w, log_ml_runs, nuts_mu)
        if settings.bridge:                     # the plan: bridge-sampling weights, pooled over the runs
            bridge_runs = [[np.array([f["bridge_log_ml"]]) for f in r["fits"]] for r in runs]
            routes[PLAN_ROUTE] = _pool(n, labels, prior_w, bridge_runs, nuts_mu)
    return {"labels": labels, "prior_weights": prior_w, "runs": repeats, "n_observed": n, "routes": routes,
            "smc_stages": [r["stages"] for r in runs], "nuts_fits": [r["fits"] for r in runs], "timing": timing}


# ============================================================ step 2: the published analysis
def _hidden_mu(idata) -> np.ndarray:
    return np.asarray(idata["posterior"]["hidden_mu"].values, float)


def run_published_analysis(data: Mapping | None = None, settings: RunSettings = RunSettings(), *,
                           delta: float = PUBLISHED_DELTA, prior_name: str = PUBLISHED_PRIOR) -> dict:
    """Madigan & York's analysis in PyMC, through the plan's machinery, ``settings.repeats`` times."""
    data = data or load_benchmark()
    lists = tuple(data["list_order"])
    y = cells_vector(data["cells"], len(lists))
    prior = n_prior(data, prior_name)
    models = hd.decomposable_models(lists)
    prior_w = bma.model_prior([m.spec for m in models])          # uniform, as Madigan & York
    cands = [Candidate(m.label, (lambda m=m: hd.build_pymc_model(y, m, delta, prior)), _hidden_mu) for m in models]
    out = run_candidates(cands, int(y.sum()), prior_w, settings, np.random.SeedSequence(settings.seed),
                         settings.repeats)
    out.update({"benchmark": data["name"], "prior": prior_name,
                "prior_parameters": asdict(prior) if isinstance(prior, hd.NegativeBinomialPrior) else {},
                "delta": delta, "exact": hd.exact_posterior(y, models, delta, prior, model_prior=prior_w),
                "specs": [replace(m.spec, label=None).name for m in models]})     # crc_engine's names, e.g. BD+DR
    return out


# ================================================ context: the study's own models on this table
def run_study_models(data: Mapping | None = None, settings: RunSettings = RunSettings()) -> dict:
    """crc_engine's 8 dependence structures with the proposed priors (``PHASE3_PROPOSED``) on the benchmark table."""
    from ..mle import fit_design
    from ..models import build_model
    from ..modelspace import design_matrix, model_space
    from ..priors import PHASE3_PROPOSED as P

    data = data or load_benchmark()
    table = benchmark_table(data)
    specs = model_space(table.lists)
    cands = []
    for spec in specs:
        Xh = design_matrix(spec, table).X_hidden

        def hidden(idata, Xh=Xh):
            return np.exp(np.asarray(idata["posterior"]["theta"].values, float) @ Xh.T)[..., 0]

        cands.append(Candidate(spec.name, (lambda spec=spec: build_model(table, spec, P)[0]), hidden))
    out = run_candidates(cands, table.n_observed, bma.model_prior(specs), settings,
                         np.random.SeedSequence([settings.seed, 1]), settings.study_repeats)
    mle = []
    for spec in specs:
        f = fit_design(design_matrix(spec, table))
        mle.append({"N": f.N, "interval": f.N_interval(), "boundary": f.boundary})
    out.update({"priors": P.name, "mle": mle,
                "prior_values": {"list_effects": asdict(P.list_effects), "pairs": asdict(P.pairs),
                                 "count_intercept": asdict(P.count_intercept)}})
    return out


# ====================================================================== step 3: compare
def _consistent_interval(q: str, published: float, unit: float) -> tuple[float, float]:
    """The values of the continuous quantity that print as ``published``.

    A percentile k is the smallest N whose CDF reaches it, so its continuous version lies in (k - 1, k]; a mode m
    in [m - 1/2, m + 1/2]; anything else rounded to ``unit`` in [v - unit/2, v + unit/2].
    """
    if q in ("q025", "q975", "q05", "q95"):
        return published - 1.0, published
    return published - unit / 2, published + unit / 2


def compare(data: Mapping, result: Mapping, route: str = PLAN_ROUTE) -> list[dict]:
    """Published vs exact vs PyMC for Table 4 and Table 5's bold row, with the pass-rule tolerances.

    The mode and the percentiles are compared through their continuous versions (``n_summary``), so that their
    Monte Carlo error is measured even when every run rounds to the same integer.  A figure is reproduced when
    PyMC's value is within t * MCSE of the interval of values that print as the published one; PyMC agrees with
    the exact computation when the two continuous values are within t * MCSE.
    """
    labels = result["labels"]
    R = result["runs"]
    t = _t975(R)
    rt = result["routes"][route]
    pooled, mc, exact = rt["pooled"], rt["mc_sd_between_runs"], result["exact"]
    ex_models = [hd.n_summary(exact.grid, p) for p in exact.pmf]
    ex_bma = hd.n_summary(exact.grid, exact.bma_pmf)
    rows = []

    def add(source, model, q, published, unit, exact_s, ours_s, mc_s):
        kc = q + "_c" if q in ("mode", "q025", "q975") else q
        ours, ours_c, ex, ex_c, sd = ours_s[q], ours_s[kc], exact_s[q], exact_s[kc], mc_s[kc]
        se = sd / math.sqrt(R) if R > 1 else float("nan")
        lo, hi = _consistent_interval(q, published, unit)
        dist = max(lo - ours_c, ours_c - hi, 0.0)
        tol = t * se
        key = f"{source}|{model}|{q}"
        exact_ok = bool(abs(ours_c - ex_c) <= tol + 1e-12)
        status = ("reproduced" if dist <= tol + 1e-12 else
                  "explained" if key in KNOWN_DISCREPANCIES and exact_ok else "not reproduced")
        rows.append({"route": route, "key": key, "source": source, "model": model, "quantity": q,
                     "published": published, "unit": unit, "published_interval": [lo, hi], "exact": ex,
                     "exact_continuous": ex_c, "pymc": ours, "pymc_continuous": ours_c, "mc_se": se, "t": t,
                     "tolerance": tol, "distance_to_published": dist, "diff_exact": ours_c - ex_c,
                     "pymc_vs_exact_ok": exact_ok, "status": status, "note": KNOWN_DISCREPANCIES.get(key, "")})

    t4 = data["published"]["table4"]
    for lab, vals in t4["models"].items():
        i = labels.index(lab)
        add("table4", lab, "prob", vals["prob"], t4["rounding"]["prob"], {"prob": float(exact.weights[i])},
            {"prob": float(pooled["weights"][i])}, {"prob": mc["weights"][i]})
        for q in ("N_hat", "mode", "q025", "q975"):
            add("table4", lab, q, vals[q], t4["rounding"]["N"], ex_models[i], pooled["models"][i], mc["models"][i])
    for q, v in t4["model_averaging"].items():
        add("table4", "model averaging", q, v, t4["rounding"]["N"], ex_bma, pooled["bma"], mc["bma"])
    t5 = data["published"]["table5"]
    bold = next(r for r in t5["rows"] if r["prior"] == result["prior"] and float(r["delta"]) == result["delta"])
    row = f"{result['prior']},delta={result['delta']:g}"
    for c, v in zip(t5["columns"], bold["values"]):
        if c.startswith("["):
            i = labels.index(c)
            add("table5", row, c, v, t5["rounding"]["prob"], {c: float(exact.weights[i])},
                {c: float(pooled["weights"][i])}, {c: mc["weights"][i]})
        else:
            add("table5", row, c, v, t5["rounding"]["N"], ex_bma, pooled["bma"], mc["bma"])
    return rows


def _fit_checks(result: Mapping, i: int) -> dict:
    """NUTS gates, bridge sampling and importance sampling of model i over the runs: the plan's agreement rule
    (importance sampling against the same run's bridge estimate) and, as a diagnostic, bridge against SMC."""
    fits = [run[i] for run in result["nuts_fits"] if run]
    if not fits:
        return {}
    out = {"nuts_runs": len(fits), "nuts_gates_passed_runs": int(sum(f["gates_passed"] for f in fits)),
           "nuts_attempts": [len(f["attempts"]) for f in fits],
           "nuts_final_divergences": [f["attempts"][-1]["divergences"] for f in fits],
           "nuts_gate_failures": [f["gate_failures"] for f in fits if not f["gates_passed"]]}
    if "bridge_log_ml" in fits[0]:
        smc_runs = [p["log_ml"][i] for p in result["routes"][SMC_ROUTE]["per_run"]]
        b = np.array([f["bridge_log_ml"] for f in fits])
        out.update({"bridge_log_ml_runs": b, "bridge_minus_smc_runs": b - np.array(smc_runs),
                    "bridge_agrees_with_smc": bool(np.all(np.abs(b - np.array(smc_runs))
                                                          <= BMA_SETTINGS.agreement_max))})       # diagnostic
    if "importance_log_ml" in fits[0]:
        b = np.array([f["bridge_log_ml"] for f in fits])
        im = np.array([f["importance_log_ml"] for f in fits])
        ok = np.array([f["importance_reliable"] for f in fits])
        out.update({"importance_log_ml_runs": im, "importance_khat_runs": [f["importance_khat"] for f in fits],
                    "importance_minus_bridge_runs": im - b, "importance_reliable_runs": int(ok.sum()),
                    "importance_agrees_with_bridge": bool(ok.all() and np.all(np.abs(im - b)
                                                                               <= BMA_SETTINGS.agreement_max))})
    return out


def model_checks(result: Mapping) -> list[dict]:
    """Every model, published or not: SMC and bridge log ML against the exact value, weights, NUTS gates, N."""
    exact = result["exact"]
    R = result["runs"]
    smc = result["routes"][SMC_ROUTE]
    out = []
    for i, lab in enumerate(result["labels"]):
        sd = smc["mc_sd_between_runs"]["log_ml"][i]
        row = {"model": lab, "spec": result["specs"][i], "exact_log_ml": float(exact.log_ml[i]),
               "smc_log_ml": float(smc["pooled"]["log_ml"][i]), "smc_sd_between_runs": sd,
               "smc_log_ml_se": sd / math.sqrt(R) if R > 1 else float("nan"),
               "smc_minus_exact": float(smc["pooled"]["log_ml"][i] - exact.log_ml[i]),
               "exact_weight": float(exact.weights[i]), "smc_weight": float(smc["pooled"]["weights"][i]),
               "plan_weight": (float(result["routes"][PLAN_ROUTE]["pooled"]["weights"][i])
                               if PLAN_ROUTE in result["routes"] else None),
               "smc_weight_sd_between_runs": smc["mc_sd_between_runs"]["weights"][i],
               "exact_N": hd.n_summary(exact.grid, exact.pmf[i]),
               "N_by_route": {k: v["pooled"]["models"][i] for k, v in result["routes"].items()}}
        row["smc_accurate"] = bool(abs(row["smc_minus_exact"]) <= LOG_ML_ACCURACY)
        f = _fit_checks(result, i)
        if "bridge_log_ml_runs" in f:
            dev = f["bridge_log_ml_runs"] - row["exact_log_ml"]
            f.update({"bridge_minus_exact_runs": dev, "bridge_accurate": bool(np.all(np.abs(dev) <= LOG_ML_ACCURACY))})
        if "importance_log_ml_runs" in f:
            dev = f["importance_log_ml_runs"] - row["exact_log_ml"]
            f.update({"importance_minus_exact_runs": dev,
                      "importance_accurate": bool(np.all(np.abs(dev) <= LOG_ML_ACCURACY))})
        row.update(f)
        out.append(row)
    return out


def study_checks(study: Mapping) -> list[dict]:
    """The study's models: weights, SMC/bridge agreement (the plan's 0.25 rule), NUTS gates, N and the MLE."""
    out = []
    for i, lab in enumerate(study["labels"]):
        smc = study["routes"][SMC_ROUTE]
        row = {"model": lab, "smc_log_ml": float(smc["pooled"]["log_ml"][i]),
               "smc_sd_between_runs": smc["mc_sd_between_runs"]["log_ml"][i],
               "weight": float(smc["pooled"]["weights"][i]),
               "weight_sd_between_runs": smc["mc_sd_between_runs"]["weights"][i],
               "N_by_route": {k: v["pooled"]["models"][i] for k, v in study["routes"].items()},
               "mle": study["mle"][i]}
        row.update(_fit_checks(study, i))
        out.append(row)
    return out


def verdict(rows: Sequence[dict], checks: Sequence[dict]) -> dict:
    """The pass rule over the comparison rows, plus the marginal-likelihood and NUTS checks of every model."""
    status = [r["status"] for r in rows]
    heavy = [c for c in checks if c["exact_weight"] >= BMA_SETTINGS.agreement_min_weight]
    return {
        "route": rows[0]["route"] if rows else None,
        "passes": all(s != "not reproduced" for s in status),
        "reproduced": status.count("reproduced"), "explained": status.count("explained"),
        "explained_keys": [r["key"] for r in rows if r["status"] == "explained"],
        "not_reproduced": [r["key"] for r in rows if r["status"] == "not reproduced"],
        "pymc_vs_exact_all_ok": all(r["pymc_vs_exact_ok"] for r in rows),
        "pymc_vs_exact_beyond_mc_error": [r["key"] for r in rows if not r["pymc_vs_exact_ok"]],
        "bridge_log_ml_within_0.2_of_exact_every_run": all(c.get("bridge_accurate", True) for c in checks),
        "importance_log_ml_within_0.2_of_exact_every_run": all(c.get("importance_accurate", True) for c in checks),
        "importance_agrees_with_bridge_every_run_where_weight_ge_1pct": all(c.get("importance_agrees_with_bridge", True)
                                                                            for c in heavy),
        "diagnostic_smc_log_ml_within_0.2_of_exact": all(c["smc_accurate"] for c in checks),
        "diagnostic_bridge_agrees_with_smc_every_run_where_weight_ge_1pct": all(c.get("bridge_agrees_with_smc", True)
                                                                                for c in heavy),
        "nuts_gates_passed_every_run_where_weight_ge_1pct": all(c.get("nuts_gates_passed_runs") == c.get("nuts_runs")
                                                                for c in heavy),
    }


# ==================================================================== output
def _jsonable(x):
    if isinstance(x, dict):
        return {str(k): _jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_jsonable(v) for v in x]
    if isinstance(x, np.ndarray):
        return _jsonable(x.tolist())
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, (np.floating, float)):
        return None if not np.isfinite(x) else float(x)
    if isinstance(x, np.bool_):
        return bool(x)
    if isinstance(x, hd.ExactPosterior):
        return {"labels": list(x.labels), "log_ml": _jsonable(x.log_ml), "weights": _jsonable(x.weights),
                "models": [hd.n_summary(x.grid, p) for p in x.pmf], "bma": hd.n_summary(x.grid, x.bma_pmf),
                "tail_mass": x.tail_mass}
    return x


def _strip(result: Mapping) -> dict:
    """The result without its large arrays (the pmfs of N), for the JSON file."""
    out = dict(result)
    out["routes"] = {k: {kk: vv for kk, vv in v.items() if kk not in ("grid", "pmf")} for k, v in result["routes"].items()}
    return out


def _versions() -> dict:
    import arviz
    import pymc
    import pytensor
    import scipy

    return {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
            "pymc": pymc.__version__, "pytensor": pytensor.__version__, "arviz": arviz.__version__}


def run_benchmark(out_dir: str | Path | None = None, settings: RunSettings = RunSettings()) -> dict:
    """Confirm the published figures, run the PyMC reproduction (and the study's models), compare, write files."""
    _quiet()
    data = load_benchmark()
    t0 = time.perf_counter()
    confirmation = confirm_published(data)
    t_confirm = time.perf_counter() - t0
    result = run_published_analysis(data, settings)
    rows = {route: compare(data, result, route) for route in result["routes"]}
    primary = PLAN_ROUTE if PLAN_ROUTE in rows else SMC_ROUTE
    checks = model_checks(result)
    payload = {"check": "Phase 4, check 5: published benchmark", "benchmark": data["name"],
               "citation": data["citation"], "settings": asdict(settings), "versions": _versions(),
               "confirmation": {"rows": confirmation, "mismatches": sorted(published_mismatches(confirmation)),
                                "known_discrepancies": KNOWN_DISCREPANCIES, "seconds": t_confirm},
               "primary_route": primary, "comparison": rows[primary],
               "verdict": verdict(rows[primary], checks),
               "verdict_by_route": {route: verdict(r, checks) for route, r in rows.items()},
               "comparison_by_route": rows, "model_checks": checks, "published_analysis": _strip(result)}
    if settings.study_models:
        study = run_study_models(data, settings)
        payload["study_models"] = {"checks": study_checks(study), **_strip(study)}
    payload["wall_seconds"] = time.perf_counter() - t0
    if out_dir is not None:
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        (out / "results.json").write_text(json.dumps(_jsonable(payload), indent=1), encoding="utf-8")
        for route, r in rows.items():
            pd.DataFrame(r).to_csv(out / ("comparison.csv" if route == primary else f"comparison_{route}.csv"),
                                   index=False)
        pd.DataFrame(confirmation).to_csv(out / "confirmation.csv", index=False)
    return payload


def main(argv: Sequence[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Phase 4, check 5: reproduce Madigan & York's BMA analysis.")
    p.add_argument("--out", required=True, help="output folder (results.json, comparison*.csv, confirmation.csv)")
    p.add_argument("--repeats", type=int, default=RunSettings.repeats)
    p.add_argument("--draws", type=int, default=RunSettings.draws)
    p.add_argument("--chains", type=int, default=RunSettings.chains)
    p.add_argument("--cores", type=int, default=RunSettings.cores)
    p.add_argument("--seed", type=int, default=RunSettings.seed)
    p.add_argument("--nuts-draws", type=int, default=RunSettings.nuts_draws)
    p.add_argument("--nuts-tune", type=int, default=RunSettings.nuts_tune)
    p.add_argument("--no-nuts", action="store_true")
    p.add_argument("--no-study", action="store_true")
    p.add_argument("--study-repeats", type=int, default=RunSettings.study_repeats)
    a = p.parse_args(argv)
    if a.cores > 3:
        raise SystemExit("at most 3 cores")
    s = RunSettings(draws=a.draws, chains=a.chains, repeats=a.repeats, cores=a.cores, seed=a.seed, nuts=not a.no_nuts,
                    nuts_draws=a.nuts_draws, nuts_tune=a.nuts_tune, bridge=not a.no_nuts,
                    study_models=not a.no_study, study_repeats=a.study_repeats)
    payload = run_benchmark(a.out, s)
    v = payload["verdict"]
    print(json.dumps(_jsonable(payload["verdict_by_route"]), indent=1))
    print(f"wall time {payload['wall_seconds']:.0f} s; files in {a.out}")
    return 0 if v["passes"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
