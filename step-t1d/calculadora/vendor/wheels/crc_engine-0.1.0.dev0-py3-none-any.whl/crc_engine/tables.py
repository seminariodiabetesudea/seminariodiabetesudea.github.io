"""Capture-history tables.

A capture-recapture analysis sees, for every stratum, how many people were
caught by each combination of lists.  With K lists there are 2^K histories;
the all-zero history (seen by no list) is never observed and is what the
models predict.

Conventions used throughout crc-engine
--------------------------------------
* Histories are ordered as ``itertools.product([0, 1], repeat=K)``: the first
  list is the most significant bit, so for three lists A, B, C the order is
  000, 001 (C only), 010 (B only), 011, 100 (A only), 101, 110, 111.
* ``CaptureTable.counts`` holds the 2^K - 1 *observed* histories (000 dropped)
  for every stratum, including zero counts.  A zero is data, not a missing
  value.
* Strata are the full cartesian product of the stratum variables' levels, in
  the order the levels are given, so an empty stratum is kept as a row of
  zeros rather than silently disappearing.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd


def histories(K: int, *, include_unobserved: bool = False) -> np.ndarray:
    """All capture histories for K lists, shape (2^K or 2^K - 1, K)."""
    if K < 2:
        raise ValueError("capture-recapture needs at least two lists")
    h = np.array(list(itertools.product((0, 1), repeat=K)), dtype=np.int8)
    return h if include_unobserved else h[1:]


def history_labels(lists: Sequence[str]) -> list[str]:
    """Readable labels for the observed histories, e.g. 'A', 'BC', 'ABC'."""
    return ["".join(l for l, bit in zip(lists, row) if bit) for row in histories(len(lists))]


@dataclass(frozen=True)
class CaptureTable:
    """Observed capture-history counts by stratum.

    Attributes
    ----------
    lists : names of the K lists; their order defines the history bits.
    strata : one row per stratum (columns = stratum variables). An unstratified
        table has a single stratum and no columns.
    counts : int array, shape (S, 2^K - 1).
    levels : the ordered levels of each stratum variable.
    """

    lists: tuple[str, ...]
    strata: pd.DataFrame
    counts: np.ndarray
    levels: Mapping[str, tuple] = field(default_factory=dict)

    def __post_init__(self):
        K = len(self.lists)
        if len(set(self.lists)) != K:
            raise ValueError("list names must be unique")
        c = np.asarray(self.counts)
        if c.ndim != 2 or c.shape[1] != 2**K - 1:
            raise ValueError(f"counts must have shape (S, {2**K - 1}); got {c.shape}")
        if c.shape[0] != len(self.strata):
            raise ValueError("one row of counts per stratum is required")
        if (c < 0).any() or not np.all(np.equal(np.mod(c, 1), 0)):
            raise ValueError("counts must be non-negative integers")
        object.__setattr__(self, "counts", c.astype(np.int64))

    # ------------------------------------------------------------------ basics
    @property
    def K(self) -> int:
        return len(self.lists)

    @property
    def S(self) -> int:
        return self.counts.shape[0]

    @property
    def strata_vars(self) -> tuple[str, ...]:
        return tuple(self.strata.columns)

    @property
    def n_observed(self) -> int:
        """Total number of distinct people seen by at least one list."""
        return int(self.counts.sum())

    @property
    def n_by_stratum(self) -> np.ndarray:
        return self.counts.sum(axis=1)

    def list_totals(self) -> dict[str, int]:
        """People seen by each list (a person on two lists counts in both)."""
        H = histories(self.K)
        return {l: int((self.counts * H[:, j]).sum()) for j, l in enumerate(self.lists)}

    def overlap(self, a: str, b: str) -> int:
        """People seen by both lists a and b."""
        H = histories(self.K)
        ia, ib = self.lists.index(a), self.lists.index(b)
        return int((self.counts * (H[:, ia] * H[:, ib])).sum())

    def to_long(self) -> pd.DataFrame:
        """One row per (stratum, observed history) with the count in ``y``."""
        H = histories(self.K)
        rows = []
        for s in range(self.S):
            base = self.strata.iloc[s].to_dict() if self.strata_vars else {}
            for k, h in enumerate(H):
                rows.append({**{l: int(b) for l, b in zip(self.lists, h)}, **base, "y": int(self.counts[s, k])})
        return pd.DataFrame(rows)

    def pooled(self) -> "CaptureTable":
        """The same table with all strata summed into one."""
        return CaptureTable(self.lists, pd.DataFrame(index=[0]), self.counts.sum(axis=0, keepdims=True), {})

    def collapse(self, keep: Sequence[str]) -> "CaptureTable":
        """Sum over every stratum variable not in ``keep``."""
        keep = list(keep)
        if not keep:
            return self.pooled()
        df = self.strata[keep].copy()
        df["_row"] = np.arange(self.S)
        levels = {v: self.levels[v] for v in keep}
        grid = pd.DataFrame(list(itertools.product(*levels.values())), columns=keep)
        out = np.zeros((len(grid), self.counts.shape[1]), dtype=np.int64)
        key = {tuple(r): i for i, r in enumerate(grid.itertuples(index=False, name=None))}
        for s, r in enumerate(df[keep].itertuples(index=False, name=None)):
            out[key[tuple(r)]] += self.counts[s]
        return CaptureTable(self.lists, grid, out, levels)

    # ------------------------------------------------------------ constructors
    @classmethod
    def from_individuals(
        cls,
        df: pd.DataFrame,
        lists: Sequence[str],
        strata: Sequence[str] = (),
        levels: Mapping[str, Iterable] | None = None,
    ) -> "CaptureTable":
        """Build the table from one row per *person* with 0/1 list columns.

        Every person must be on at least one list, every stratum value must be
        known (missing values raise), and the levels of each stratum variable
        are either given or taken from the data in sorted order.
        """
        lists = tuple(lists)
        strata = tuple(strata)
        missing = [c for c in lists + strata if c not in df.columns]
        if missing:
            raise KeyError(f"columns not found: {missing}")
        L = df[list(lists)]
        if L.isna().any().any():
            raise ValueError("list indicators may not be missing")
        Lv = L.to_numpy()
        if not np.isin(Lv, (0, 1)).all():
            raise ValueError("list indicators must be 0/1")
        if (Lv.sum(axis=1) == 0).any():
            raise ValueError("a person on no list cannot be observed; drop or fix those rows")
        if strata and df[list(strata)].isna().any().any():
            bad = [c for c in strata if df[c].isna().any()]
            raise ValueError(f"stratum variables have missing values: {bad}")
        lv: dict[str, tuple] = {}
        for v in strata:
            given = None if levels is None else levels.get(v)
            lv[v] = tuple(given) if given is not None else tuple(sorted(df[v].unique()))
            unknown = set(df[v].unique()) - set(lv[v])
            if unknown:
                raise ValueError(f"values of {v!r} outside its declared levels: {sorted(map(str, unknown))}")
        grid = pd.DataFrame(list(itertools.product(*lv.values())), columns=list(strata)) if strata else pd.DataFrame(index=[0])
        K = len(lists)
        weights = 2 ** np.arange(K - 1, -1, -1)
        hist_index = Lv.astype(np.int64) @ weights - 1          # 0 .. 2^K - 2
        if strata:
            key = {tuple(r): i for i, r in enumerate(grid.itertuples(index=False, name=None))}
            s_index = np.array([key[tuple(r)] for r in df[list(strata)].itertuples(index=False, name=None)])
        else:
            s_index = np.zeros(len(df), dtype=np.int64)
        counts = np.zeros((len(grid), 2**K - 1), dtype=np.int64)
        np.add.at(counts, (s_index, hist_index), 1)
        return cls(lists, grid, counts, lv)

    @classmethod
    def empty(cls, lists: Sequence[str], levels: Mapping[str, Iterable]) -> "CaptureTable":
        """An all-zero table over the full grid of ``levels``: the shape of a study, no data.

        Used for prior predictive simulation and for simulated-data tests.
        """
        lv = {v: tuple(l) for v, l in levels.items()}
        grid = pd.DataFrame(list(itertools.product(*lv.values())), columns=list(lv)) if lv else pd.DataFrame(index=[0])
        return cls(tuple(lists), grid, np.zeros((len(grid), 2 ** len(lists) - 1), dtype=np.int64), lv)

    def with_counts(self, counts: np.ndarray) -> "CaptureTable":
        """The same strata and levels with other counts (for example simulated ones)."""
        return CaptureTable(self.lists, self.strata, np.asarray(counts), self.levels)

    @classmethod
    def from_frequencies(
        cls,
        df: pd.DataFrame,
        lists: Sequence[str],
        count: str = "freq",
        strata: Sequence[str] = (),
        levels: Mapping[str, Iterable] | None = None,
    ) -> "CaptureTable":
        """Build the table from a frequency table of histories (no individual data)."""
        lists = tuple(lists)
        rep = df.loc[df.index.repeat(df[count].astype(int))].drop(columns=[count])
        rep = rep[rep[list(lists)].sum(axis=1) > 0]
        return cls.from_individuals(rep.reset_index(drop=True), lists, strata, levels)
