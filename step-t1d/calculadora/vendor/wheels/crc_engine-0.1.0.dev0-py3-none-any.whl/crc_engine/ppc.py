"""Posterior predictive draws and checks, vectorised (audit items M7, M11).

The Freeman-Tukey discrepancy T(y, mu) = sum (sqrt(y) - sqrt(mu))^2 is
computed for the observed cells and for replicated cells drawn from the
posterior predictive distribution; the Bayesian p-value is P(T_rep >= T_obs).
A p-value below 0.05 or above 0.95 flags misfit.  Note that every check here
concerns the observed cells: no data can check the hidden cell.

The replicates are Poisson.  Given the draws of an AM2 model's dispersion kappa
(decision 122) they are NB1 instead, with each draw's kappa (``nb1_draws``);
the statistics and the p-values are unchanged.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

#: A posterior predictive p-value outside [FLAG_LOW, FLAG_HIGH] flags misfit.
FLAG_LOW = 0.05
FLAG_HIGH = 0.95


def linear_predictor(X: np.ndarray, beta_draws: np.ndarray) -> np.ndarray:
    """eta = beta @ X.T for draws of shape (..., P); returns (..., n_cells)."""
    return np.asarray(beta_draws, float) @ np.asarray(X, float).T


def poisson_draws(mu: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """One Poisson draw per element, in C order.

    numpy's Generator draws element by element in C order, so this gives the
    same numbers as v0.2.0's loop over (chain, draw) under the same seed, at a
    fraction of the cost.
    """
    return rng.poisson(mu)


def nb1_draws(mu: np.ndarray, kappa, rng: np.random.Generator) -> np.ndarray:
    """One NB1(mu, kappa) draw per element, in C order (AM2, decision 122): mean mu and variance mu (1 + kappa).

    NB1 is the negative binomial with size mu / kappa and success probability 1 / (1 + kappa); numpy's
    ``negative_binomial`` draws each element as a Poisson count whose mean is Gamma(mu / kappa, scale kappa).
    ``mu`` has the cells on its last axis and ``kappa`` one value per draw, shape ``mu.shape[:-1]``, which is
    broadcast over the cells.  A zero mean gives a zero count, as in ``poisson_draws``.
    """
    mu = np.asarray(mu, float)
    k = np.asarray(kappa, float)
    if k.shape != mu.shape[:-1]:
        raise ValueError(f"kappa needs one value per draw, shape {mu.shape[:-1]}; got {k.shape}")
    if not np.all(np.isfinite(k) & (k > 0)):
        raise ValueError("NB1 needs a finite dispersion kappa > 0 in every draw")
    k = k[..., None]
    size = mu / k
    zero = size == 0
    return np.where(zero, 0, rng.negative_binomial(np.where(zero, 1.0, size), 1.0 / (1.0 + k)))


def _replicates(mu: np.ndarray, kappa_draws, rng: np.random.Generator) -> np.ndarray:
    """Replicated counts for the draws of the cell means, shape (draws, cells): Poisson, or NB1 given one kappa per
    draw (``kappa_draws``, flattened in C order like the draws of the means)."""
    if kappa_draws is None:
        return poisson_draws(mu, rng)
    return nb1_draws(mu, np.asarray(kappa_draws, float).reshape(-1), rng)


def freeman_tukey(y: np.ndarray, mu: np.ndarray) -> np.ndarray:
    return np.sum((np.sqrt(y) - np.sqrt(mu)) ** 2, axis=-1)


@dataclass(frozen=True)
class PPCResult:
    T_obs: np.ndarray
    T_rep: np.ndarray
    p_value: float

    @property
    def flagged(self) -> bool:
        return self.p_value < FLAG_LOW or self.p_value > FLAG_HIGH


def ppc_freeman_tukey(X_obs: np.ndarray, y_obs: np.ndarray, beta_draws: np.ndarray,
                      rng: np.random.Generator) -> PPCResult:
    """Freeman-Tukey posterior predictive check over the observed cells.

    beta_draws : shape (D, P) or (chains, draws, P).
    """
    b = np.asarray(beta_draws, float)
    b = b.reshape(-1, b.shape[-1])
    return ppc_freeman_tukey_means(y_obs, np.exp(linear_predictor(X_obs, b)), rng)


def ppc_freeman_tukey_means(y_obs: np.ndarray, mu_draws: np.ndarray, rng: np.random.Generator, *,
                            kappa_draws: np.ndarray | None = None) -> PPCResult:
    """Freeman-Tukey check from posterior draws of the observed cells' means, shape (..., cells).

    Any model that yields cell means can use it (the structured Phase 3 models do).  With ``kappa_draws``, an AM2
    model's dispersion (decision 122) with shape ``mu_draws.shape[:-1]``, the replicates are NB1 with each draw's
    kappa.
    """
    mu = np.asarray(mu_draws, float)
    mu = mu.reshape(-1, mu.shape[-1])
    y_rep = _replicates(mu, kappa_draws, rng)
    T_obs = freeman_tukey(np.asarray(y_obs, float)[None, :], mu)
    T_rep = freeman_tukey(y_rep, mu)
    return PPCResult(T_obs, T_rep, float(np.mean(T_rep >= T_obs)))


def hidden_and_total(X_hidden: np.ndarray, beta_draws: np.ndarray, n_observed: int,
                     rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    """Draw the hidden counts M ~ Poisson(mu_0) per stratum and N = n + sum M.

    beta_draws of shape (chains, draws, P) give M of shape (chains, draws, S)
    and N of shape (chains, draws).
    """
    mu0 = np.exp(linear_predictor(X_hidden, beta_draws))
    M = poisson_draws(mu0, rng)
    return M, n_observed + M.sum(axis=-1)


# ================================================== list totals and pairwise overlaps (analysis plan, fit checks)
def margin_weights(K: int) -> tuple[np.ndarray, list[str]]:
    """(observed histories, statistics) matrix that turns a stratum's observed cells into its list totals and
    pairwise overlaps, and the statistics' labels ('A', 'B', 'C', 'AB', 'AC', 'BC' for three lists, by position)."""
    import itertools

    from .tables import histories

    H = histories(K).astype(float)
    pairs = list(itertools.combinations(range(K), 2))
    W = np.concatenate([H, np.stack([H[:, i] * H[:, j] for i, j in pairs], axis=1)], axis=1)
    letters = [chr(ord("A") + k) for k in range(K)]
    return W, letters + [letters[i] + letters[j] for i, j in pairs]


def group_margins(cells: np.ndarray, W: np.ndarray, groups: np.ndarray, n_groups: int) -> np.ndarray:
    """List totals and pairwise overlaps summed over the strata of each group.

    ``cells`` (..., strata, observed histories) holds counts; ``groups`` (strata,) each stratum's group index.
    Returns (..., n_groups, statistics).
    """
    per_stratum = np.asarray(cells, float) @ W
    G = np.zeros((groups.size, n_groups))
    G[np.arange(groups.size), groups] = 1.0
    return np.einsum("...sk,sg->...gk", per_stratum, G)


def ppc_margins(y_obs: np.ndarray, mu_draws: np.ndarray, W: np.ndarray, groups: np.ndarray, n_groups: int,
                rng: np.random.Generator, *, kappa_draws: np.ndarray | None = None) -> dict:
    """Posterior predictive check of the list totals and pairwise overlaps by group (e.g. period x age band).

    ``y_obs`` (strata x observed histories,) and ``mu_draws`` (draws, same) in the design's cell order.  Each
    statistic gets the mid-p value P(T_rep > T_obs) + P(T_rep = T_obs) / 2, which treats ties fairly for counts;
    it is extreme below ``FLAG_LOW`` or above ``FLAG_HIGH``, the Freeman-Tukey check's bounds.  These statistics
    are reported beside that check; with dozens of them some are extreme by chance, so they set no flag of their
    own (J13).  With ``kappa_draws`` (one per draw of ``mu_draws``; an AM2 model's dispersion, decision 122) the
    replicates are NB1 with each draw's kappa.
    """
    mu = np.asarray(mu_draws, float).reshape(-1, np.asarray(y_obs).size)
    n_hist = W.shape[0]
    S = mu.shape[1] // n_hist
    T_obs = group_margins(np.asarray(y_obs, float).reshape(S, n_hist), W, groups, n_groups)
    T_rep = group_margins(_replicates(mu, kappa_draws, rng).reshape(-1, S, n_hist), W, groups, n_groups)
    p = np.mean(T_rep > T_obs, axis=0) + 0.5 * np.mean(T_rep == T_obs, axis=0)
    return {"T_obs": T_obs, "T_rep_mean": T_rep.mean(axis=0), "p_value": p,
            "extreme": (p < FLAG_LOW) | (p > FLAG_HIGH)}
