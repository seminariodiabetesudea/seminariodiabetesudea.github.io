"""Bayesian model averaging: the settings of the analysis plan and the model prior.

``BMA_SETTINGS`` holds the numbers for the marginal likelihoods (bridge
sampling from each NUTS fit, checked by importance sampling from the same fit;
decision 78 replaced the build plan's SMC after Phase 4's check 4), the Monte
Carlo error of the weights and Occam's window.  ``docs/analysis-plan.md`` is
rendered from these objects, so the plan and the refit read the same numbers.
They are a proposal until the plan is frozen at checkpoint C3.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from .modelspace import ModelSpec


@dataclass(frozen=True)
class BMASettings:
    repeats: int = 5                       # independent runs (fresh NUTS fits) per model for the weights' Monte Carlo error
    weight_mc_error_max: float = 0.02      # a weight with a larger Monte Carlo error gets more draws
    importance_draws: int = 200_000        # proposal draws of the importance-sampling second opinion
    importance_df: float = 5.0             # degrees of freedom of its multivariate t proposal
    importance_scale: float = 1.2          # the proposal's covariance is the posterior draws' times this squared
    importance_khat_max: float = 0.7       # the estimate is usable when Pareto k-hat is below this
    agreement_max: float = 0.25            # |log ML by bridge sampling - log ML by importance sampling|, log units
    agreement_min_weight: float = 0.01     # the agreement rule applies to every model with this weight
    occam_factor: float = 20.0             # Occam's window: posterior odds against the best model
    complexity_penalty: float = 0.5        # S2: each switched-on term multiplies the prior odds by this
    ppc_stop_weight: float = 0.5           # judgment call: stop and report if flagged models hold this much weight
    four_list_max_pairs: int = 2           # S7 (Clid as a fourth list): dependence structures with at most 2 pairs
    four_list_pip_min: float = 0.5         # judgment call: S7 keeps the list x covariate terms with PIP >= this


BMA_SETTINGS = BMASettings()


def n_terms(spec: ModelSpec) -> int:
    """Switched-on terms of a model: each pairwise dependence term and each list x covariate term."""
    return len(spec.pairs) + len(spec.list_covariates)


def model_prior(specs: Sequence[ModelSpec], penalty: float | None = None) -> np.ndarray:
    """Prior model probabilities over ``specs``.

    Uniform when ``penalty`` is None (the main analysis); otherwise each
    switched-on term multiplies the prior odds by ``penalty`` (sensitivity S2;
    with 0.5, each extra interaction halves the prior odds).  A list x
    covariate term counts once, however many columns it adds.
    """
    k = np.array([n_terms(s) for s in specs], dtype=float)
    if penalty is None:
        w = np.ones_like(k)
    else:
        if not 0.0 < penalty <= 1.0:
            raise ValueError("the complexity penalty must be in (0, 1]")
        w = penalty ** k
    return w / w.sum()


# =========================================================================== combining the fits (Phase 5)
#: Level of the averaged posterior's equal-tailed interval: the plan's 95%.  ``step_pipeline.config`` has no
#: interval level of its own, and ``summaries.summarize`` uses the same default.
CI_LEVEL = 0.95


@dataclass(frozen=True)
class RepeatFit:
    """What ``combine`` needs from one fit of one model (one repeat)."""

    repeat: int
    bridge_log_ml: float                  # bridge sampling: sets the weights
    importance_log_ml: float              # importance sampling: the second opinion (J15)
    importance_reliable: bool             # Pareto k-hat below BMA_SETTINGS.importance_khat_max
    passed: bool = True                   # the convergence gates on the fit's last attempt
    failures: tuple[str, ...] = ()        # why the gates failed
    bridge_converged: bool = True         # the bridge iterative scheme converged
    N_draws: np.ndarray | None = None     # posterior draws of N, any shape
    ppc_p_value: float | None = None      # Freeman-Tukey posterior predictive p-value


@dataclass(frozen=True)
class ModelFits:
    """One model's repeats and its prior probability (``model_prior``)."""

    spec: ModelSpec
    prior: float
    repeats: tuple[RepeatFit, ...]

    @property
    def name(self) -> str:
        return self.spec.name


def interaction_terms(spec: ModelSpec) -> list[str]:
    """The model's switched-on interactions, as ``ModelSpec.terms`` names them: 'pair:AB', 'list×age_band', ..."""
    return [t for t in spec.terms() if t.startswith("pair:") or t.startswith("list×")]


def _log_mean_exp(x: np.ndarray) -> float:
    from scipy.special import logsumexp

    a = np.asarray(x, float).ravel()
    return float(logsumexp(a) - np.log(a.size))


def _softmax(lw: np.ndarray) -> np.ndarray:
    from scipy.special import logsumexp

    return np.exp(lw - logsumexp(lw))


@dataclass
class ModelAverageRow:
    """One model in the average (or out of it), with every number ``combine`` derived for it."""

    name: str
    terms: list[str]
    prior: float
    in_average: bool
    leave_reasons: list[str]
    repeats: list[int]
    log_ml_bridge: float                  # log-mean-exp of the repeats' bridge estimates
    log_ml_importance: float              # the same for importance sampling
    log_ml_bridge_per_repeat: list[float]
    log_ml_importance_per_repeat: list[float]
    importance_reliable_per_repeat: list[bool]
    agreement_difference: float           # |bridge - importance| of the pooled estimates
    weight: float                         # 0 out of the average; NaN when it has no bridge estimate
    weight_per_repeat: list[float]
    weight_mc_error: float                # SD of the per-repeat weights / sqrt(R)
    mc_error_flag: bool
    agreement_flag: bool
    agreement_reasons: list[str]
    in_occam_window: bool
    ppc_p_value: float | None
    ppc_flagged: bool
    n_draws: int


@dataclass
class BMAResult:
    """The model average: weights and their Monte Carlo errors, the J15 and J13 checks, Occam's window, the
    posterior inclusion probabilities and the mixture posterior of N."""

    models: list[ModelAverageRow]
    repeats: int
    occam_window: list[str]
    inclusion_probabilities: dict[str, float]
    mc_error_flags: list[str]
    agreement_flags: dict[str, list[str]]
    ppc_flagged_weight: float
    ppc_stop: bool
    N: dict | None                        # median, lower, upper, mean, level, draws, seed
    N_draws: np.ndarray | None            # the resampled mixture draws
    settings: BMASettings
    level: float
    seed: int | None

    @property
    def weights(self) -> dict[str, float]:
        return {m.name: m.weight for m in self.models}

    @property
    def in_average(self) -> list[str]:
        return [m.name for m in self.models if m.in_average]

    def row(self, name: str) -> ModelAverageRow:
        return next(m for m in self.models if m.name == name)

    def as_dict(self) -> dict:
        from dataclasses import asdict

        def clean(x):
            if isinstance(x, (float, np.floating)):
                return float(x) if np.isfinite(x) else None
            if isinstance(x, (np.integer,)):
                return int(x)
            if isinstance(x, (np.bool_,)):
                return bool(x)
            if isinstance(x, dict):
                return {k: clean(v) for k, v in x.items()}
            if isinstance(x, (list, tuple)):
                return [clean(v) for v in x]
            return x

        return clean({
            "settings": asdict(self.settings), "repeats": self.repeats, "level": self.level,
            "models": [asdict(m) for m in self.models],
            "weights": self.weights,
            "weight_mc_error_flags": list(self.mc_error_flags),
            "agreement_flags": dict(self.agreement_flags),
            "occam_window": {"factor": self.settings.occam_factor, "models": list(self.occam_window)},
            "inclusion_probabilities": dict(self.inclusion_probabilities),
            "ppc": {"flagged_models": [m.name for m in self.models if m.ppc_flagged and m.in_average],
                    "flagged_weight": self.ppc_flagged_weight, "stop_weight": self.settings.ppc_stop_weight,
                    "stop": self.ppc_stop},
            "N": self.N,
        })


def mixture_draws(pools: Sequence[np.ndarray], weights: np.ndarray, n: int, rng: np.random.Generator) -> np.ndarray:
    """``n`` draws from the mixture: a model drawn in proportion to ``weights``, then one of its pooled draws."""
    w = np.asarray(weights, float)
    if len(pools) != w.size or w.size == 0 or not np.all(np.isfinite(w)) or (w < 0).any() or w.sum() <= 0:
        raise ValueError("one non-negative finite weight per pool, not all zero")
    counts = rng.multinomial(int(n), w / w.sum())
    out = [rng.choice(np.asarray(p).ravel(), size=int(c), replace=True) for p, c in zip(pools, counts) if c > 0]
    return np.concatenate(out)


def combine(models: Sequence[ModelFits], *, settings: BMASettings = BMA_SETTINGS, seed: int | None = None,
            level: float = CI_LEVEL, n_mixture: int | None = None) -> BMAResult:
    """Average the models over their repeats (analysis plan, "Bayesian model averaging").

    * A model leaves the average when any of its repeats failed the convergence gates on its last attempt; its
      reasons are kept.  The weights are renormalised over the models left.
    * Per model, the log marginal likelihood is the log-mean-exp of its repeats' bridge-sampling estimates; the
      importance-sampling estimate is pooled the same way.  w_k is proportional to exp(log ML_k) p(M_k).
    * Monte Carlo error of each weight: the SD of the weights computed from each repeat alone, over sqrt(R).
      An error above ``settings.weight_mc_error_max`` is flagged.
    * J15: every model with weight >= ``settings.agreement_min_weight`` is flagged when its pooled bridge and
      importance estimates differ by more than ``settings.agreement_max``, when importance sampling was unreliable
      in any repeat, or when the bridge scheme did not converge; a model with no usable bridge estimate is
      flagged whatever its weight, because its weight is unknown.  Neither estimate is ever chosen over the other.
    * Occam's window: the models within ``settings.occam_factor`` of the best.  Inclusion probabilities: the
      summed weight of the models holding each pair and each list x covariate term.
    * J13: the summed weight of the models whose pooled predictive p-value is flagged; ``ppc_stop`` when it
      reaches ``settings.ppc_stop_weight``.
    * N: every model's draws pooled over its repeats, resampled in proportion to the weights (``seed``), and
      summarised by the median and the equal-tailed ``level`` interval.  ``n_mixture`` defaults to the largest
      pooled draw count among the weighted models.
    """
    from .ppc import FLAG_HIGH, FLAG_LOW
    from .summaries import summarize

    models = list(models)
    if not models:
        raise ValueError("no models to combine")
    names = [m.name for m in models]
    if len(set(names)) != len(names):
        raise ValueError("model names must be unique")
    rows: list[ModelAverageRow] = []
    for m in models:
        if not m.repeats:
            raise ValueError(f"{m.name} has no repeats")
        reps = sorted(m.repeats, key=lambda r: r.repeat)
        failed = [r for r in reps if not r.passed]
        reasons = [f"repeat {r.repeat}: {f}" for r in failed for f in (r.failures or ("failed the gates",))]
        b = np.array([r.bridge_log_ml for r in reps], float)
        i = np.array([r.importance_log_ml for r in reps], float)
        lb = _log_mean_exp(b) if np.all(np.isfinite(b)) else float("nan")
        li = _log_mean_exp(i) if np.all(np.isfinite(i)) else float("nan")
        p = [r.ppc_p_value for r in reps]
        p_pool = float(np.mean(p)) if all(v is not None and np.isfinite(v) for v in p) else None
        n_draws = int(sum(np.asarray(r.N_draws).size for r in reps if r.N_draws is not None))
        rows.append(ModelAverageRow(
            name=m.name, terms=interaction_terms(m.spec), prior=float(m.prior), in_average=not failed,
            leave_reasons=reasons, repeats=[r.repeat for r in reps], log_ml_bridge=lb, log_ml_importance=li,
            log_ml_bridge_per_repeat=b.tolist(), log_ml_importance_per_repeat=i.tolist(),
            importance_reliable_per_repeat=[bool(r.importance_reliable) for r in reps],
            agreement_difference=abs(lb - li) if np.isfinite(lb) and np.isfinite(li) else float("nan"),
            weight=0.0, weight_per_repeat=[], weight_mc_error=float("nan"), mc_error_flag=False,
            agreement_flag=False, agreement_reasons=[], in_occam_window=False, ppc_p_value=p_pool,
            ppc_flagged=p_pool is not None and (p_pool < FLAG_LOW or p_pool > FLAG_HIGH), n_draws=n_draws))

    # ---- weights over the models left, renormalised
    weighted = [k for k, r in enumerate(rows) if r.in_average and np.isfinite(r.log_ml_bridge)]
    for k, r in enumerate(rows):
        if r.in_average and k not in weighted:
            r.weight = float("nan")                      # in the average, but no usable bridge estimate
    R = 0
    if weighted:
        if any(models[k].prior <= 0 for k in weighted):
            raise ValueError("every model in the average needs a positive prior probability")
        log_prior = np.log([models[k].prior for k in weighted])
        w = _softmax(np.array([rows[k].log_ml_bridge for k in weighted]) + log_prior)
        for k, wk in zip(weighted, w):
            rows[k].weight = float(wk)
        rep_ids = {tuple(rows[k].repeats) for k in weighted}
        if len(rep_ids) != 1:
            raise ValueError("the models in the average must share the same repeats")
        R = len(rows[weighted[0]].repeats)
        per = np.array([[rows[k].log_ml_bridge_per_repeat[j] for k in weighted] for j in range(R)]) + log_prior
        W = np.array([_softmax(x) for x in per])                         # (R, models)
        for c, k in enumerate(weighted):
            rows[k].weight_per_repeat = W[:, c].tolist()
            err = float(np.std(W[:, c], ddof=1) / np.sqrt(R)) if R > 1 else float("nan")
            rows[k].weight_mc_error = err
            rows[k].mc_error_flag = not (np.isfinite(err) and err <= settings.weight_mc_error_max)

    # ---- J15: the two estimates must agree for every model with at least the minimum weight
    flags: dict[str, list[str]] = {}
    for k, r in enumerate(rows):
        if not r.in_average:
            continue
        why = []
        if not np.isfinite(r.log_ml_bridge):
            bad = [rep for rep, v in zip(r.repeats, r.log_ml_bridge_per_repeat) if not np.isfinite(v)]
            why.append(f"bridge sampling gave no estimate in repeat(s) {bad}, so the weight is unknown")
        elif r.weight >= settings.agreement_min_weight:
            if not np.isfinite(r.log_ml_importance):
                bad = [rep for rep, v in zip(r.repeats, r.log_ml_importance_per_repeat) if not np.isfinite(v)]
                why.append(f"importance sampling gave no estimate in repeat(s) {bad}")
            elif r.agreement_difference > settings.agreement_max:
                why.append(f"|bridge - importance| = {r.agreement_difference:.3f} log units > "
                           f"{settings.agreement_max:g} (bridge {r.log_ml_bridge:.3f}, "
                           f"importance {r.log_ml_importance:.3f})")
            unreliable = [rep for rep, ok in zip(r.repeats, r.importance_reliable_per_repeat) if not ok]
            if unreliable and np.isfinite(r.log_ml_importance):
                why.append(f"importance sampling unreliable (Pareto k-hat >= {settings.importance_khat_max:g}) "
                           f"in repeat(s) {unreliable}")
            unconverged = [rep.repeat for rep in sorted(models[k].repeats, key=lambda x: x.repeat)
                           if not rep.bridge_converged]
            if unconverged:
                why.append(f"the bridge scheme did not converge in repeat(s) {unconverged}")
        if why:
            r.agreement_flag, r.agreement_reasons = True, why
            flags[r.name] = why

    # ---- Occam's window, inclusion probabilities, J13
    occam: list[str] = []
    if weighted:
        best = max(rows[k].weight for k in weighted)
        for k in weighted:
            rows[k].in_occam_window = rows[k].weight >= best / settings.occam_factor
        occam = [rows[k].name for k in weighted if rows[k].in_occam_window]
    terms: list[str] = []
    for m in models:
        for t in interaction_terms(m.spec):
            if t not in terms:
                terms.append(t)
    pip = {t: float(sum(rows[k].weight for k in weighted if t in rows[k].terms)) for t in terms}
    ppc_weight = float(sum(rows[k].weight for k in weighted if rows[k].ppc_flagged))

    # ---- the mixture posterior of N
    N, N_draws = None, None
    pools_ok = weighted and all(any(r.N_draws is not None for r in models[k].repeats) for k in weighted)
    if pools_ok:
        pools = [np.concatenate([np.asarray(r.N_draws, float).ravel() for r in models[k].repeats
                                 if r.N_draws is not None]) for k in weighted]
        w = np.array([rows[k].weight for k in weighted])
        n = int(n_mixture) if n_mixture is not None else max(p.size for p in pools)
        N_draws = mixture_draws(pools, w, n, np.random.default_rng(seed))
        s = summarize(N_draws, level)
        N = {"median": s.median, "lower": s.lower, "upper": s.upper, "mean": s.mean, "level": s.level,
             "draws": int(N_draws.size), "seed": seed}
    return BMAResult(models=rows, repeats=R, occam_window=occam, inclusion_probabilities=pip,
                     mc_error_flags=[rows[k].name for k in weighted if rows[k].mc_error_flag],
                     agreement_flags=flags, ppc_flagged_weight=ppc_weight,
                     ppc_stop=bool(weighted) and ppc_weight >= settings.ppc_stop_weight, N=N, N_draws=N_draws,
                     settings=settings, level=level, seed=seed)
