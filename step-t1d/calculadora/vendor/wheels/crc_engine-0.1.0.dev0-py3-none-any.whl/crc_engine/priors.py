"""Prior specifications.

Two sets for the Phase 3 structured models, side by side for the C3 signers
(analysis plan, open question Q2):

* ``PHASE3_PROPOSED`` carries the build plan's Phase 3 table: the count part
  is the log hidden count per stratum-year.
* ``PHASE3_RECALIBRATED`` (one per estimand, E1 and E2) is built from outside
  information only: the count part is the log expected total per stratum-year,
  with a log person-years offset, so the prior on N is the same in every model.
  Every number in it that has no source in the build plan or the analysis plan
  is a judgment call to verify at C3; ``sources`` says which.

``docs/analysis-plan.md`` is rendered from these objects, so the plan and the
refit read the same numbers.  ``LEGACY_V020`` reproduces v0.2.0 for the audit
(item M4).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Mapping

import numpy as np

from . import design


@dataclass(frozen=True)
class Normal:
    mu: float = 0.0
    sigma: float = 1.0


@dataclass(frozen=True)
class HalfNormal:
    """Prior on a scale parameter (a standard deviation)."""
    sigma: float = 1.0


#: The count part's target: the log hidden count, or the log expected total with a log person-years offset.
COUNT_TARGETS = ("hidden", "total")


@dataclass(frozen=True)
class PriorSpec:
    name: str
    count_intercept: Normal          # alpha: log hidden count ("hidden") or log rate per person-year ("total")
    count_effects: Normal            # count-part main effects and their interaction, unless overridden below
    list_effects: Normal             # beta_j
    pairs: Normal                    # lambda_jk
    list_covariates: Normal          # beta_{j,c}
    kway: Normal | None = None       # Phase 1 builder only (audit M2); S9 is applied after the fit
    legacy_halfcauchy_pairs: bool = False   # v0.2.0: lambda ~ N(0, s), s ~ HalfCauchy(1)
    year_rw_scale: HalfNormal | None = None       # sigma of the random walk on year effects gamma_t
    stratum_year_scale: HalfNormal | None = None  # tau of the sex x year and age band x year terms
    three_way_scale: HalfNormal | None = None     # tau3 of the sex x age band x year term
    count_target: str = "hidden"
    sex_effect: Normal | None = None              # overrides count_effects for delta (sex)
    age_effect: Normal | None = None              # ... for eta (age band)
    sex_age_effect: Normal | None = None          # ... for (delta eta)
    sources: Mapping[str, str] = field(default_factory=dict, compare=False)

    def __post_init__(self):
        if self.count_target not in COUNT_TARGETS:
            raise ValueError(f"count_target must be one of {COUNT_TARGETS}")

    @property
    def sex(self) -> Normal:
        return self.sex_effect or self.count_effects

    @property
    def age(self) -> Normal:
        return self.age_effect or self.count_effects

    @property
    def sex_age(self) -> Normal:
        return self.sex_age_effect or self.count_effects


BUILD_PLAN = "build plan, Phase 3"
TO_VERIFY = "judgment call, to verify at C3"

PHASE3_PROPOSED = PriorSpec(
    name="phase3-proposed",
    count_intercept=Normal(math.log(10.0), 2.5),
    count_effects=Normal(0.0, 1.5),
    list_effects=Normal(0.0, 1.5),
    pairs=Normal(0.0, 1.0),
    list_covariates=Normal(0.0, 0.75),
    year_rw_scale=HalfNormal(0.3),
    stratum_year_scale=HalfNormal(0.5),
    three_way_scale=HalfNormal(0.5),
    sources={"three_way_scale": TO_VERIFY},
)


#: E1 centre (decision on the recalibrated set): childhood incidence in Bogotá,
#: under 15 years, corrected for missed cases by two-source capture-recapture.
RECALIBRATED_E1_RATE = 5.3 / 100_000.0
RECALIBRATED_E1_RATE_CI = (3.14 / 100_000.0, 7.44 / 100_000.0)     # the source's 95% interval
RECALIBRATED_E1_RATE_YEAR = 2008
RECALIBRATED_E1_SOURCE = ("Céspedes C, Montaña-Jiménez LP, Lasalvia P, Aschner P (Grupo Diamebog) 2020, "
                          "Endocrinol Diabetes Nutr 67(4):289-291, doi:10.1016/j.endinu.2019.09.002")
#: Judgment call, to verify at C3: wider than the source's interval, because the
#: Aburrá Valley may differ from Bogotá and the authors note the figure is more
#: likely an underestimate.
RECALIBRATED_E1_SD = 0.7
#: Context the plan prints beside the centre: DIAMOND (2006), Table 1, p. 862.
DIAMOND_BOGOTA_1990 = 3.8 / 100_000.0
DIAMOND_BOGOTA_YEAR = 1990
DIAMOND_SOUTH_AMERICA = (3.7 / 100_000.0, 10.3 / 100_000.0)          # centres with an ascertainment estimate
DIAMOND_SOURCE = "DIAMOND Project Group 2006, Diabet Med 23:857-866, Table 1, p. 862"
#: Young-adult / child incidence ratios where the same area reports both: mostly
#: within this band (range 0.2 to 1.25).  Taking its middle is a judgment call.
ADULT_CHILD_RATIO_BAND = (0.5, 0.9)
ADULT_CHILD_RATIO_SOURCE = ("Harding JL, Wander PL, Zhang X, et al. 2022, Diabetes Care 45(4):994-1006, "
                            "doi:10.2337/dc21-1752, Table 1, with DIAMOND 2006")
RECALIBRATED_ADULT_RATIO = sum(ADULT_CHILD_RATIO_BAND) / 2
#: Judgment call, to verify at C3: there is no Latin American rate for ages 15-34.
RECALIBRATED_E2_SD = 0.8


def recalibrated_e2_rate(e1_rate: float = RECALIBRATED_E1_RATE, ratio: float = RECALIBRATED_ADULT_RATIO,
                         adult: tuple[int, int] | None = None) -> float:
    """E2's centre: the E1 centre times ratio ** (adult bands / all bands).

    The count-part intercept is an equal-weight geometric mean over the age
    bands, so with the child bands at the E1 rate and the adult ones at ratio
    times it, the geometric mean is e1_rate * ratio ** (a / b).  The bands come
    from the study design (``crc_engine.design``).
    """
    a, b = adult if adult is not None else design.adult_bands()
    return e1_rate * ratio ** (a / b)


RECALIBRATED_RATE = {"E1": RECALIBRATED_E1_RATE, "E2": recalibrated_e2_rate()}
RECALIBRATED_RATE_SD = {"E1": RECALIBRATED_E1_SD, "E2": RECALIBRATED_E2_SD}
RECALIBRATED_RATE_SOURCE = {"E1": RECALIBRATED_E1_SOURCE,
                            "E2": f"E1 centre ({RECALIBRATED_E1_SOURCE}) x ratio ** (adult share); ratio: "
                                  f"{ADULT_CHILD_RATIO_SOURCE}"}
#: Judgment call, to verify at C3: the list-effect centre, chosen so that three
#: independent lists have a prior median completeness of about
#: RECALIBRATED_COMPLETENESS (a test checks it; the plan prints the value reached).
RECALIBRATED_COMPLETENESS = 0.5
RECALIBRATED_LIST_CENTRE = -1.8
#: Scale prior of the pooled sex x year, age band x year and sex x age band x year
#: deviations (decision 64): narrow enough that a group's expected count does not
#: swing implausibly from year to year, wide enough (97.5% point about 0.56) that
#: the data can still ask for a three-way SD of 0.3 or more.
RECALIBRATED_POOLED_SCALE = 0.25


def _recalibrated(estimand: str) -> PriorSpec:
    return PriorSpec(
        name=f"phase3-recalibrated-{estimand}",
        count_intercept=Normal(math.log(RECALIBRATED_RATE[estimand]), RECALIBRATED_RATE_SD[estimand]),
        count_effects=Normal(0.0, 0.5),
        sex_effect=Normal(0.0, 0.15),
        age_effect=Normal(0.0, 0.5),
        sex_age_effect=Normal(0.0, 0.15),
        list_effects=Normal(RECALIBRATED_LIST_CENTRE, 1.5),
        pairs=PHASE3_PROPOSED.pairs,
        list_covariates=PHASE3_PROPOSED.list_covariates,
        year_rw_scale=PHASE3_PROPOSED.year_rw_scale,
        stratum_year_scale=HalfNormal(RECALIBRATED_POOLED_SCALE),
        three_way_scale=HalfNormal(RECALIBRATED_POOLED_SCALE),
        count_target="total",
        sources={"count_intercept": RECALIBRATED_RATE_SOURCE[estimand], "count_intercept_sd": TO_VERIFY,
                 "sex_effect": TO_VERIFY, "age_effect": TO_VERIFY,
                 "sex_age_effect": TO_VERIFY, "list_effects": TO_VERIFY, "pairs": BUILD_PLAN,
                 "list_covariates": BUILD_PLAN, "year_rw_scale": BUILD_PLAN, "stratum_year_scale": TO_VERIFY,
                 "three_way_scale": TO_VERIFY},
    )


PHASE3_RECALIBRATED = {"E1": _recalibrated("E1"), "E2": _recalibrated("E2")}

#: The prior set the analysis plan froze at C3 (open question Q2, decision 99); read by ``step_pipeline.refit``.
FROZEN_PRIOR_SET = "recalibrated"

#: S1: the pairwise-dependence prior SD is replaced by each of these in turn.
S1_PAIR_SDS = (0.5, 2.0)
#: S9: SD of kappa, the A:B:C term, applied after the fit to the all-pairs models
#: (``models.posterior_N(..., s9_sd=...)``): hidden means times exp(-kappa).
S9_KWAY_SDS = (0.5, 1.0)


def with_pair_sd(spec: PriorSpec, sd: float) -> PriorSpec:
    """The S1 variant of ``spec``: the same priors with lambda ~ Normal(0, sd)."""
    return replace(spec, name=f"{spec.name}|S1 pairs sd {sd:g}", pairs=Normal(spec.pairs.mu, sd))


@dataclass(frozen=True)
class TrendPriors:
    """Weak priors for the PyMC mirror of EURODIAB's Poisson trend model (E1a).

    log E[cases] = log(person-years) + intercept + age group + sex + age group x sex
                   + slope x (year - centre year)
    The intercept is a log rate per person-year; the slope is the log of the
    annual rate ratio (annual percent change = 100 (exp(slope) - 1)).
    """
    intercept: Normal
    effects: Normal
    slope: Normal


#: Proposal (judgment call, analysis plan): an intercept centred on 10 per
#: 100 000 person-years, the count part's weak prior on group effects, and a
#: slope whose central 95% covers annual changes of about -18% to +22%.
TREND_PROPOSED = TrendPriors(
    intercept=Normal(math.log(10.0 / 100_000.0), 2.5),
    effects=Normal(0.0, 1.5),
    slope=Normal(0.0, 0.1),
)

LEGACY_V020 = PriorSpec(
    name="v0.2.0",
    count_intercept=Normal(0.0, 10.0),
    count_effects=Normal(0.0, 10.0),
    list_effects=Normal(0.0, 10.0),
    pairs=Normal(0.0, 1.0),           # scale replaced by HalfCauchy(1), see flag
    list_covariates=Normal(0.0, 10.0),
    legacy_halfcauchy_pairs=True,
)


def capture_probability_prior(list_prior: Normal, n: int, rng: np.random.Generator) -> np.ndarray:
    """Prior predictive capture probability of one list under independence.

    Under independence mu_h is proportional to exp(sum_j h_j beta_j), so a
    person's chance of being on list j is exp(beta_j) / (1 + exp(beta_j)).
    """
    b = rng.normal(list_prior.mu, list_prior.sigma, size=n)
    return 1.0 / (1.0 + np.exp(-b))


def completeness_prior(list_prior: Normal, K: int, n: int, rng: np.random.Generator) -> np.ndarray:
    """Prior predictive completeness 1 - prod_j (1 - p_j) under independence."""
    p = np.column_stack([capture_probability_prior(list_prior, n, rng) for _ in range(K)])
    return 1.0 - np.prod(1.0 - p, axis=1)
