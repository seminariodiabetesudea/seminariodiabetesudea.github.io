"""Study design the engine's priors need: age bands at diagnosis and the estimands' age limits.

The single source of these values; ``step_pipeline.config`` re-exports them, so
the cohort, the analysis plan and the recalibrated priors read the same bands.
"""

from __future__ import annotations

AGE_BANDS: dict[str, tuple[int, int]] = {"0-4": (0, 4), "5-9": (5, 9), "10-14": (10, 14), "15-24": (15, 24),
                                         "25-35": (25, 35)}
E1_MAX_AGE = 14
E2_MAX_AGE = 35


def bands(max_age: int) -> dict[str, tuple[int, int]]:
    """The age bands of an estimand whose oldest age at diagnosis is ``max_age``."""
    return {b: r for b, r in AGE_BANDS.items() if r[1] <= max_age}


def adult_bands(max_age: int = E2_MAX_AGE, adult_from: int = E1_MAX_AGE + 1) -> tuple[int, int]:
    """(adult bands, all bands) of an estimand: a band is adult when its youngest age is at least ``adult_from``."""
    bs = bands(max_age)
    return sum(1 for lo, _ in bs.values() if lo >= adult_from), len(bs)
